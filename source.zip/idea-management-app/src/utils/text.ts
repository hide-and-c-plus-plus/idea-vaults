export function provisionalTitle(text: string) {
  const line =
    text
      .split(/\n+/)
      .map((x) => x.trim())
      .find(Boolean) ?? "Untitled idea";
  return line.length > 72 ? `${line.slice(0, 69)}…` : line;
}

export function normalizeTag(value: string) {
  return value.trim().replace(/\s+/g, " ").toLowerCase();
}
