import { getDb, supportsFts5 } from "./database";

export const migrations: string[] = [
  `
  CREATE TABLE IF NOT EXISTS schema_meta (version INTEGER NOT NULL);
  INSERT INTO schema_meta(version) SELECT 0 WHERE NOT EXISTS (SELECT 1 FROM schema_meta);

  CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    parent_id TEXT NULL REFERENCES categories(id),
    icon TEXT NULL,
    color_token TEXT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    archived_at INTEGER NULL
  );

  CREATE TABLE IF NOT EXISTS ideas (
    id TEXT PRIMARY KEY,
    title TEXT NULL,
    summary TEXT NULL,
    stage TEXT NOT NULL DEFAULT 'spark',
    inbox_state TEXT NOT NULL DEFAULT 'unprocessed',
    primary_category_id TEXT NULL REFERENCES categories(id),
    horizon TEXT NULL,
    potential INTEGER NULL,
    effort INTEGER NULL,
    next_action TEXT NULL,
    done_definition TEXT NULL,
    problem TEXT NULL,
    audience TEXT NULL,
    why_now TEXT NULL,
    next_experiment TEXT NULL,
    risks TEXT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    last_touched_at INTEGER NOT NULL,
    archived_at INTEGER NULL,
    dropped_at INTEGER NULL,
    deleted_at INTEGER NULL,
    source_type TEXT NOT NULL,
    original_capture_id TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_ideas_updated ON ideas(updated_at DESC);
  CREATE INDEX IF NOT EXISTS idx_ideas_stage ON ideas(stage);
  CREATE INDEX IF NOT EXISTS idx_ideas_inbox ON ideas(inbox_state);
  CREATE INDEX IF NOT EXISTS idx_ideas_category ON ideas(primary_category_id);
  CREATE INDEX IF NOT EXISTS idx_ideas_live ON ideas(deleted_at) WHERE deleted_at IS NULL;

  CREATE TABLE IF NOT EXISTS idea_blocks (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    body_text TEXT NULL,
    attachment_id TEXT NULL,
    derived_from_block_id TEXT NULL REFERENCES idea_blocks(id),
    position INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    is_original INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_blocks_idea ON idea_blocks(idea_id, position, created_at);

  CREATE TABLE IF NOT EXISTS idea_events (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    event_type TEXT NOT NULL,
    payload_json TEXT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_events_idea ON idea_events(idea_id, created_at DESC);

  CREATE TABLE IF NOT EXISTS tags (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    normalized_name TEXT NOT NULL UNIQUE,
    color_token TEXT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS idea_tags (
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    tag_id TEXT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (idea_id, tag_id)
  );

  CREATE TABLE IF NOT EXISTS idea_links (
    id TEXT PRIMARY KEY,
    source_idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    target_idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    link_type TEXT NOT NULL,
    note TEXT NULL,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS attachments (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    block_id TEXT NULL REFERENCES idea_blocks(id) ON DELETE SET NULL,
    kind TEXT NOT NULL,
    local_uri TEXT NOT NULL,
    mime_type TEXT NULL,
    byte_size INTEGER NULL,
    duration_ms INTEGER NULL,
    sha256 TEXT NULL,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS transcripts (
    id TEXT PRIMARY KEY,
    attachment_id TEXT NOT NULL REFERENCES attachments(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    language TEXT NULL,
    provider TEXT NULL,
    segments_json TEXT NULL,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS reminders (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    scheduled_at INTEGER NOT NULL,
    kind TEXT NOT NULL DEFAULT 'idea',
    snoozed_until INTEGER NULL,
    notification_id TEXT NULL,
    completed_at INTEGER NULL
  );
  CREATE INDEX IF NOT EXISTS idx_reminders_due ON reminders(scheduled_at, completed_at);

  CREATE TABLE IF NOT EXISTS resurfacing_events (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    reason TEXT NOT NULL,
    shown_at INTEGER NOT NULL,
    action TEXT NULL,
    snoozed_until INTEGER NULL
  );

  CREATE TABLE IF NOT EXISTS feedback_notes (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    person_name TEXT NULL,
    body TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS drafts (
    id TEXT PRIMARY KEY,
    body_text TEXT NOT NULL DEFAULT '',
    mode TEXT NOT NULL DEFAULT 'text',
    attachment_uri TEXT NULL,
    metadata_json TEXT NULL,
    updated_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE VIRTUAL TABLE IF NOT EXISTS idea_fts USING fts5(
    idea_id UNINDEXED,
    title,
    summary,
    body,
    tokenize='unicode61 remove_diacritics 2'
  );
  `,
  `
  ALTER TABLE ideas ADD COLUMN is_starred INTEGER NOT NULL DEFAULT 0;
  ALTER TABLE ideas ADD COLUMN energy TEXT NOT NULL DEFAULT 'steady';
  CREATE INDEX idx_ideas_starred ON ideas(is_starred, updated_at DESC);
  CREATE TABLE projects (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, intention TEXT NOT NULL DEFAULT '',
    color TEXT NOT NULL DEFAULT '#AC9BFF', created_at INTEGER NOT NULL
  );
  CREATE TABLE project_ideas (
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    PRIMARY KEY(project_id, idea_id)
  );
  CREATE TABLE action_items (
    id TEXT PRIMARY KEY, idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    body TEXT NOT NULL, done_at INTEGER, created_at INTEGER NOT NULL
  );
  CREATE INDEX idx_actions_idea ON action_items(idea_id, created_at);
  CREATE TABLE experiments (
    id TEXT PRIMARY KEY, idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    hypothesis TEXT NOT NULL, method TEXT NOT NULL, success_signal TEXT NOT NULL,
    result TEXT NOT NULL DEFAULT '', verdict TEXT NOT NULL DEFAULT 'untested'
      CHECK(verdict IN ('untested','running','supported','challenged','inconclusive')),
    created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
  );
  CREATE INDEX idx_experiments_idea ON experiments(idea_id, created_at);
  CREATE TABLE time_capsules (
    id TEXT PRIMARY KEY, idea_id TEXT REFERENCES ideas(id) ON DELETE SET NULL,
    title TEXT NOT NULL, body TEXT NOT NULL, unlock_at INTEGER NOT NULL,
    opened_at INTEGER, created_at INTEGER NOT NULL
  );
  CREATE INDEX idx_capsules_unlock ON time_capsules(unlock_at);
  CREATE TABLE focus_sessions (
    id TEXT PRIMARY KEY, idea_id TEXT REFERENCES ideas(id) ON DELETE SET NULL,
    intention TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '',
    planned_seconds INTEGER NOT NULL CHECK(planned_seconds > 0),
    elapsed_seconds INTEGER NOT NULL DEFAULT 0,
    started_at INTEGER NOT NULL, ends_at INTEGER NOT NULL, completed_at INTEGER,
    status TEXT NOT NULL DEFAULT 'running' CHECK(status IN ('running','completed','ended'))
  );
  CREATE UNIQUE INDEX idx_single_running_focus ON focus_sessions(status) WHERE status='running';
  CREATE TABLE review_entries (
    id TEXT PRIMARY KEY, learned TEXT NOT NULL, release_note TEXT NOT NULL,
    next_week TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  CREATE TABLE saved_views (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, query TEXT NOT NULL,
    filters_json TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  `,
  `
  ALTER TABLE ideas ADD COLUMN last_seen_at INTEGER;
  ALTER TABLE ideas ADD COLUMN next_action_id TEXT REFERENCES action_items(id) ON DELETE SET NULL;
  ALTER TABLE idea_links ADD COLUMN status TEXT NOT NULL DEFAULT 'accepted';
  INSERT INTO action_items(id,idea_id,body,created_at) SELECT 'next_'||i.id,i.id,i.next_action,i.updated_at FROM ideas i WHERE TRIM(COALESCE(i.next_action,''))<>'' AND NOT EXISTS(SELECT 1 FROM action_items a WHERE a.idea_id=i.id AND a.body=i.next_action AND a.done_at IS NULL);
  UPDATE ideas SET next_action_id=(SELECT a.id FROM action_items a WHERE a.idea_id=ideas.id AND a.body=ideas.next_action AND a.done_at IS NULL ORDER BY a.created_at LIMIT 1) WHERE next_action IS NOT NULL;

  CREATE TABLE thought_contracts (
    idea_id TEXT PRIMARY KEY REFERENCES ideas(id) ON DELETE CASCADE,
    intent TEXT NOT NULL DEFAULT 'explore', mode TEXT NOT NULL DEFAULT 'explore',
    sanctuary INTEGER NOT NULL DEFAULT 0, protected_phrase TEXT NOT NULL DEFAULT '',
    revisit_when TEXT NOT NULL DEFAULT '', context TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL
  );
  CREATE TABLE thought_revisions (
    id TEXT PRIMARY KEY, idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    parent_id TEXT REFERENCES thought_revisions(id) ON DELETE SET NULL,
    label TEXT NOT NULL, snapshot_json TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  CREATE INDEX idx_revisions_idea ON thought_revisions(idea_id,created_at DESC);
  CREATE TABLE session_checkpoints (
    id TEXT PRIMARY KEY, idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    changed TEXT NOT NULL DEFAULT '', open_question TEXT NOT NULL DEFAULT '', restart TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE inquiries (
    id TEXT PRIMARY KEY, question TEXT NOT NULL, context TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'open', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
  );
  CREATE TABLE inquiry_members (
    inquiry_id TEXT NOT NULL REFERENCES inquiries(id) ON DELETE CASCADE,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    role TEXT NOT NULL DEFAULT 'material', created_at INTEGER NOT NULL,
    PRIMARY KEY(inquiry_id,idea_id)
  );
  CREATE TABLE thought_cards (
    id TEXT PRIMARY KEY, idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '',
    interpretation TEXT NOT NULL DEFAULT '', source_url TEXT NOT NULL DEFAULT '',
    source_quote TEXT NOT NULL DEFAULT '', epistemic TEXT NOT NULL DEFAULT 'unresolved',
    relation TEXT NOT NULL DEFAULT '', related_card_id TEXT REFERENCES thought_cards(id) ON DELETE SET NULL,
    status TEXT NOT NULL DEFAULT 'open', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
  );
  CREATE INDEX idx_cards_idea ON thought_cards(idea_id,kind);
  CREATE TABLE workshop_entries (
    id TEXT PRIMARY KEY, idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    recipe_id TEXT NOT NULL, title TEXT NOT NULL, fields_json TEXT NOT NULL,
    takeaway TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL
  );
  CREATE TABLE custom_recipes (
    id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL,
    steps_json TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  CREATE TABLE bridge_proposals (
    id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    target_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    source_snapshot TEXT NOT NULL, target_snapshot TEXT NOT NULL, relation TEXT NOT NULL,
    rationale TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', feedback TEXT NOT NULL DEFAULT '',
    link_id TEXT REFERENCES idea_links(id) ON DELETE SET NULL, created_at INTEGER NOT NULL,
    CHECK(source_id<>target_id)
  );
  CREATE TABLE experiment_observations (
    id TEXT PRIMARY KEY, experiment_id TEXT NOT NULL REFERENCES experiments(id) ON DELETE CASCADE,
    observation TEXT NOT NULL, interpretation TEXT NOT NULL DEFAULT '', alternatives TEXT NOT NULL DEFAULT '',
    happened_at INTEGER NOT NULL, created_at INTEGER NOT NULL
  );
  CREATE TABLE experiment_protocols (
    id TEXT PRIMARY KEY, experiment_id TEXT NOT NULL REFERENCES experiments(id) ON DELETE CASCADE,
    hypothesis TEXT NOT NULL, method TEXT NOT NULL, success_signal TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  INSERT INTO experiment_protocols SELECT 'legacy_'||id,id,hypothesis,method,success_signal,created_at FROM experiments;
  CREATE TABLE discovery_sessions (
    id TEXT PRIMARY KEY, mode TEXT NOT NULL, takeaway TEXT NOT NULL DEFAULT '',
    created_at INTEGER NOT NULL, completed_at INTEGER
  );
  CREATE TABLE discovery_items (
    session_id TEXT NOT NULL REFERENCES discovery_sessions(id) ON DELETE CASCADE,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    position INTEGER NOT NULL, reason TEXT NOT NULL, recall TEXT NOT NULL DEFAULT '',
    revealed_at INTEGER, action TEXT, PRIMARY KEY(session_id,idea_id)
  );
  CREATE TABLE audio_marks (
    id TEXT PRIMARY KEY, attachment_id TEXT NOT NULL REFERENCES attachments(id) ON DELETE CASCADE,
    offset_ms INTEGER NOT NULL, label TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  `,
];

const seedSql = `
INSERT OR IGNORE INTO categories(id,name,parent_id,color_token,sort_order) VALUES
('cat_product','Product / Business',NULL,'accent',10),
('cat_technology','Technology',NULL,'accent',20),
('cat_creative','Creative',NULL,'warning',30),
('cat_learning','Learning / Research',NULL,'success',40),
('cat_personal','Personal / Life',NULL,'success',50),
('cat_writing','Writing / Content',NULL,'warning',60),
('cat_problem','Problem / Opportunity',NULL,'danger',70),
('cat_experiment','Experiment',NULL,'accent',80),
('cat_unsorted','Random / Unsorted',NULL,'textMuted',90);
`;

export async function runMigrations() {
  const db = await getDb();
  const fullText = await supportsFts5(db);
  const row = await db
    .getFirstAsync<{ version: number }>(
      "SELECT version FROM schema_meta LIMIT 1",
    )
    .catch(() => null);
  let version = row?.version ?? 0;
  while (version < migrations.length) {
    await db.withTransactionAsync(async () => {
      const sql = fullText
        ? migrations[version]!
        : migrations[version]!.replace(
            /CREATE VIRTUAL TABLE IF NOT EXISTS idea_fts USING fts5\([\s\S]*?\);/,
            "CREATE TABLE IF NOT EXISTS idea_fts (idea_id TEXT PRIMARY KEY, title TEXT, summary TEXT, body TEXT);",
          );
      await db.execAsync(sql);
      await db.runAsync("UPDATE schema_meta SET version = ?", version + 1);
    });
    version += 1;
  }
  await db.execAsync(seedSql);
}
