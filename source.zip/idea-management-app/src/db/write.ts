import { getDb } from "./database";
import type { SQLiteDatabase } from "expo-sqlite";

// Serialize writes on the single app connection. Call internal helpers with db;
// never call another public write operation from inside this callback.
let pending: Promise<unknown> = Promise.resolve();
export function writeDb<T>(
  work: (db: SQLiteDatabase) => Promise<T>,
): Promise<T> {
  const task = pending.then(async () => {
    const db = await getDb();
    let value!: T;
    await db.withTransactionAsync(async () => {
      value = await work(db);
    });
    return value;
  });
  pending = task.catch(() => undefined);
  return task;
}
