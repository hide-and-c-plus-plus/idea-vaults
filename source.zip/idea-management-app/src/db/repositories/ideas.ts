import * as FileSystem from "expo-file-system/legacy";
import * as Notifications from "expo-notifications";
import type { SQLiteDatabase, SQLiteBindValue } from "expo-sqlite";
import { recordRevision } from "./revisions";
import { getDb, supportsFts5 } from "../database";
import { writeDb } from "../write";
import type {
  Category,
  Idea,
  IdeaBlock,
  IdeaDetail,
  IdeaStage,
} from "@/domain/types";
import { createId } from "@/utils/id";
import { normalizeTag, provisionalTitle } from "@/utils/text";
import { safeFtsQuery } from "@/domain/logic";

export const IDEA_SELECT = `SELECT i.*, c.name AS category_name,
  COALESCE((SELECT body_text FROM idea_blocks b WHERE b.idea_id=i.id AND b.type='text' ORDER BY b.position,b.created_at LIMIT 1),'') AS snippet
  FROM ideas i LEFT JOIN categories c ON c.id=i.primary_category_id`;
export async function logEvent(
  db: SQLiteDatabase,
  ideaId: string,
  type: string,
  payload: unknown = null,
) {
  await db.runAsync(
    "INSERT INTO idea_events(id,idea_id,event_type,payload_json,created_at) VALUES(?,?,?,?,?)",
    createId("evt"),
    ideaId,
    type,
    payload == null ? null : JSON.stringify(payload),
    Date.now(),
  );
}
export async function syncFts(db: SQLiteDatabase, ideaId: string) {
  const idea = await db.getFirstAsync<Idea>(
    "SELECT * FROM ideas WHERE id=?",
    ideaId,
  );
  if (!idea) return;
  const bodies = await db.getAllAsync<{ body: string }>(
    `SELECT body_text AS body FROM idea_blocks WHERE idea_id=? AND body_text IS NOT NULL
    UNION ALL SELECT t.text FROM transcripts t JOIN attachments a ON a.id=t.attachment_id WHERE a.idea_id=?
    UNION ALL SELECT tg.name FROM tags tg JOIN idea_tags it ON it.tag_id=tg.id WHERE it.idea_id=?`,
    ideaId,
    ideaId,
    ideaId,
  );
  const extras = await db.getAllAsync<{ body: string }>(
    `
    SELECT body AS body FROM action_items WHERE idea_id=?
    UNION ALL SELECT hypothesis||' '||method||' '||success_signal||' '||result FROM experiments WHERE idea_id=?
    UNION ALL SELECT o.observation||' '||o.interpretation||' '||o.alternatives FROM experiment_observations o JOIN experiments e ON e.id=o.experiment_id WHERE e.idea_id=?
    UNION ALL SELECT title||' '||body||' '||interpretation||' '||source_quote FROM thought_cards WHERE idea_id=?
    UNION ALL SELECT title||' '||fields_json||' '||takeaway FROM workshop_entries WHERE idea_id=?
    UNION ALL SELECT changed||' '||open_question||' '||restart FROM session_checkpoints WHERE idea_id=?
    UNION ALL SELECT context||' '||revisit_when||' '||protected_phrase FROM thought_contracts WHERE idea_id=?`,
    ideaId,
    ideaId,
    ideaId,
    ideaId,
    ideaId,
    ideaId,
    ideaId,
  );
  bodies.push(...extras);
  await db.runAsync("DELETE FROM idea_fts WHERE idea_id=?", ideaId);
  const structured = [
    idea.problem,
    idea.audience,
    idea.why_now,
    idea.next_experiment,
    idea.risks,
    idea.next_action,
    idea.done_definition,
  ];
  await db.runAsync(
    "INSERT INTO idea_fts(idea_id,title,summary,body) VALUES(?,?,?,?)",
    ideaId,
    idea.title ?? "",
    idea.summary ?? "",
    [...bodies.map((b) => b.body), ...structured].filter(Boolean).join("\n"),
  );
}
export interface CaptureInput {
  draftId?: string;
  text?: string;
  title?: string;
  audioUri?: string;
  audioDurationMs?: number;
  sourceType?: string;
  attachments?: {
    type: "image" | "file" | "audio";
    uri: string;
    mimeType?: string | null;
    durationMs?: number;
  }[];
  context?: string;
  marks?: { offsetMs: number; label: string }[];
  attachment?: {
    type: "image" | "file";
    uri: string;
    mimeType?: string | null;
  };
}
// Internal insert supports atomic creative branches and multi-parent collisions.
export async function insertCapture(db: SQLiteDatabase, input: CaptureInput) {
  const now = Date.now(),
    id = createId("idea"),
    original = createId("block"),
    text = input.text?.trim() ?? "";
  await db.runAsync(
    `INSERT INTO ideas(id,title,stage,inbox_state,created_at,updated_at,last_touched_at,source_type,original_capture_id)
    VALUES(?,?,'spark','unprocessed',?,?,?,?,?)`,
    id,
    input.title?.trim() ||
      (text
        ? provisionalTitle(text)
        : input.audioUri
          ? "Voice idea"
          : "Untitled idea"),
    now,
    now,
    now,
    input.sourceType ?? "text",
    original,
  );
  await db.runAsync(
    `INSERT INTO idea_blocks(id,idea_id,type,body_text,position,created_at,updated_at,is_original) VALUES(?,?,'text',?,0,?,?,1)`,
    original,
    id,
    text,
    now,
    now,
  );
  if (input.audioUri)
    await insertAttachment(db, id, {
      type: "audio",
      uri: input.audioUri,
      mimeType: "audio/mp4",
      durationMs: input.audioDurationMs,
      isOriginal: true,
    });
  if (input.attachment)
    await insertAttachment(db, id, { ...input.attachment, isOriginal: true });
  for (const attachment of input.attachments ?? [])
    await insertAttachment(db, id, { ...attachment, isOriginal: true });
  if (input.context?.trim())
    await db.runAsync(
      "INSERT INTO thought_contracts(idea_id,context,updated_at) VALUES(?,?,?)",
      id,
      input.context.trim(),
      now,
    );
  if (input.marks?.length) {
    const audio = await db.getFirstAsync<{ id: string }>(
      "SELECT id FROM attachments WHERE idea_id=? AND kind='audio' ORDER BY created_at DESC LIMIT 1",
      id,
    );
    if (audio)
      for (const mark of input.marks)
        await db.runAsync(
          "INSERT INTO audio_marks(id,attachment_id,offset_ms,label,created_at) VALUES(?,?,?,?,?)",
          createId("mark"),
          audio.id,
          mark.offsetMs,
          mark.label,
          now,
        );
  }
  await recordRevision(db, id, "Original capture");
  await logEvent(db, id, "created", { source: input.sourceType ?? "capture" });
  await syncFts(db, id);
  if (input.draftId)
    await db.runAsync("DELETE FROM drafts WHERE id=?", input.draftId);
  return id;
}
export function createIdeaFromCapture(input: CaptureInput) {
  return writeDb((db) => insertCapture(db, input));
}
export async function listIdeas(
  options: {
    stage?: IdeaStage;
    inbox?: "unprocessed" | "processed";
    limit?: number;
    offset?: number;
    includeArchived?: boolean;
  } = {},
) {
  const db = await getDb(),
    where = ["i.deleted_at IS NULL"];
  const args: SQLiteBindValue[] = [];
  if (!options.includeArchived) where.push("i.stage<>'archived'");
  if (options.stage) {
    where.push("i.stage=?");
    args.push(options.stage);
  }
  if (options.inbox) {
    where.push("i.inbox_state=?");
    args.push(options.inbox);
  }
  args.push(options.limit ?? 50, options.offset ?? 0);
  return db.getAllAsync<Idea>(
    `${IDEA_SELECT} WHERE ${where.join(" AND ")} ORDER BY i.is_starred DESC,i.updated_at DESC,i.id DESC LIMIT ? OFFSET ?`,
    ...args,
  );
}
export const listActiveIdeas = () => listIdeas({ stage: "active", limit: 5 });
export const listInboxIdeas = (limit = 100) =>
  listIdeas({ inbox: "unprocessed", limit });
export const listRecentIdeas = (limit = 5) => listIdeas({ limit });
export async function getIdea(id: string): Promise<IdeaDetail | null> {
  const db = await getDb(),
    idea = await db.getFirstAsync<Idea>(
      `${IDEA_SELECT} WHERE i.id=? AND i.deleted_at IS NULL`,
      id,
    );
  if (!idea) return null;
  const blocks = await db.getAllAsync<IdeaBlock>(
    "SELECT * FROM idea_blocks WHERE idea_id=? ORDER BY position,created_at",
    id,
  );
  const tags = await db.getAllAsync<any>(
    "SELECT t.* FROM tags t JOIN idea_tags it ON it.tag_id=t.id WHERE it.idea_id=? ORDER BY t.name",
    id,
  );
  const attachments = await db.getAllAsync<any>(
    "SELECT * FROM attachments WHERE idea_id=? ORDER BY created_at",
    id,
  );
  return { ...idea, blocks, tags, attachments };
}
export function markProcessed(id: string) {
  return writeDb(async (db) => {
    await db.runAsync(
      "UPDATE ideas SET inbox_state='processed',updated_at=?,last_touched_at=? WHERE id=?",
      Date.now(),
      Date.now(),
      id,
    );
    await logEvent(db, id, "inbox_processed");
  });
}
const editable = [
  "title",
  "summary",
  "stage",
  "primary_category_id",
  "horizon",
  "potential",
  "effort",
  "next_action",
  "done_definition",
  "problem",
  "audience",
  "why_now",
  "next_experiment",
  "risks",
  "is_starred",
  "energy",
] as const;
type Editable = (typeof editable)[number];
export function updateIdea(id: string, patch: Partial<Pick<Idea, Editable>>) {
  return writeDb(async (db) => {
    const entries = Object.entries(patch).filter(
      ([k, v]) => editable.includes(k as Editable) && v !== undefined,
    );
    if (!entries.length) return;
    await recordRevision(db, id, "Before edit");
    const now = Date.now();
    await db.runAsync(
      `UPDATE ideas SET ${entries.map(([k]) => `${k}=?`).join(",")},updated_at=?,last_touched_at=? WHERE id=? AND deleted_at IS NULL`,
      ...entries.map(([, v]) => v as SQLiteBindValue),
      now,
      now,
      id,
    );
    if (patch.stage)
      await db.runAsync(
        "UPDATE ideas SET archived_at=?,dropped_at=? WHERE id=?",
        patch.stage === "archived" ? now : null,
        patch.stage === "dropped" ? now : null,
        id,
      );
    await logEvent(
      db,
      id,
      patch.stage ? "stage_changed" : "idea_updated",
      patch.stage
        ? { stage: patch.stage }
        : { fields: entries.map(([k]) => k) },
    );
    if (patch.next_action !== undefined) {
      const current = await db.getFirstAsync<{ next_action_id: string | null }>(
        "SELECT next_action_id FROM ideas WHERE id=?",
        id,
      );
      if (patch.next_action?.trim()) {
        const actionId = current?.next_action_id ?? createId("action");
        await db.runAsync(
          "INSERT INTO action_items(id,idea_id,body,created_at) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,done_at=NULL",
          actionId,
          id,
          patch.next_action.trim(),
          now,
        );
        await db.runAsync(
          "UPDATE ideas SET next_action_id=? WHERE id=?",
          actionId,
          id,
        );
      } else if (current?.next_action_id) {
        await db.runAsync(
          "DELETE FROM action_items WHERE id=?",
          current.next_action_id,
        );
      }
    }
    await recordRevision(db, id, "Edited thought");
    await syncFts(db, id);
  });
}
export async function insertTextBlock(
  db: SQLiteDatabase,
  ideaId: string,
  text: string,
) {
  if (!text.trim()) throw new Error("Write a thought first.");
  await recordRevision(db, ideaId, "Before adding a thought");
  const now = Date.now(),
    id = createId("block");
  const position = await db.getFirstAsync<{ next: number }>(
    "SELECT COALESCE(MAX(position),-1)+1 AS next FROM idea_blocks WHERE idea_id=?",
    ideaId,
  );
  await db.runAsync(
    `INSERT INTO idea_blocks(id,idea_id,type,body_text,position,created_at,updated_at,is_original) VALUES(?,?,'text',?,?,?,?,0)`,
    id,
    ideaId,
    text.trim(),
    position?.next ?? 0,
    now,
    now,
  );
  await db.runAsync(
    "UPDATE ideas SET updated_at=?,last_touched_at=? WHERE id=?",
    now,
    now,
    ideaId,
  );
  await logEvent(db, ideaId, "block_added", { blockId: id, type: "text" });
  await syncFts(db, ideaId);
  await recordRevision(db, ideaId, "Added a thought");
}
export const addTextBlock = (id: string, text: string) =>
  writeDb((db) => insertTextBlock(db, id, text));
interface AttachmentInput {
  type: "image" | "file" | "audio";
  uri: string;
  mimeType?: string | null;
  durationMs?: number | null;
  isOriginal?: boolean;
}
async function insertAttachment(
  db: SQLiteDatabase,
  ideaId: string,
  input: AttachmentInput,
) {
  const now = Date.now(),
    blockId = createId("block"),
    attachmentId = createId("att");
  const position = await db.getFirstAsync<{ next: number }>(
    "SELECT COALESCE(MAX(position),-1)+1 AS next FROM idea_blocks WHERE idea_id=?",
    ideaId,
  );
  await db.runAsync(
    `INSERT INTO idea_blocks(id,idea_id,type,attachment_id,position,created_at,updated_at,is_original) VALUES(?,?,?,?,?,?,?,?)`,
    blockId,
    ideaId,
    input.type,
    attachmentId,
    position?.next ?? 0,
    now,
    now,
    input.isOriginal ? 1 : 0,
  );
  await db.runAsync(
    `INSERT INTO attachments(id,idea_id,block_id,kind,local_uri,mime_type,duration_ms,created_at) VALUES(?,?,?,?,?,?,?,?)`,
    attachmentId,
    ideaId,
    blockId,
    input.type,
    input.uri,
    input.mimeType ?? null,
    input.durationMs ?? null,
    now,
  );
  await db.runAsync(
    "UPDATE ideas SET updated_at=?,last_touched_at=? WHERE id=?",
    now,
    now,
    ideaId,
  );
  await logEvent(db, ideaId, "block_added", { blockId, type: input.type });
}
export const addAttachmentBlock = (id: string, input: AttachmentInput) =>
  writeDb((db) => insertAttachment(db, id, input));
export function setTags(ideaId: string, names: string[]) {
  return writeDb(async (db) => {
    const values = [...new Set(names.map(normalizeTag).filter(Boolean))].slice(
      0,
      20,
    );
    await db.runAsync("DELETE FROM idea_tags WHERE idea_id=?", ideaId);
    for (const name of values) {
      let tag = await db.getFirstAsync<{ id: string }>(
        "SELECT id FROM tags WHERE normalized_name=?",
        name,
      );
      if (!tag) {
        const id = createId("tag");
        await db.runAsync(
          "INSERT INTO tags(id,name,normalized_name,created_at) VALUES(?,?,?,?)",
          id,
          name,
          name,
          Date.now(),
        );
        tag = { id };
      }
      await db.runAsync(
        "INSERT OR IGNORE INTO idea_tags(idea_id,tag_id) VALUES(?,?)",
        ideaId,
        tag.id,
      );
    }
    await logEvent(db, ideaId, "tags_changed", { tags: values });
    await syncFts(db, ideaId);
    await recordRevision(db, ideaId, "Updated tags");
  });
}
export async function listCategories() {
  return (await getDb()).getAllAsync<Category>(
    "SELECT * FROM categories WHERE archived_at IS NULL ORDER BY sort_order,name",
  );
}
export interface SearchFilters {
  stage?: string;
  categoryId?: string;
  tag?: string;
  sourceType?: string;
  horizon?: string;
  since?: number;
  includeArchived?: boolean;
  starred?: boolean;
  energy?: string;
  projectId?: string;
  limit?: number;
  offset?: number;
}
export async function searchIdeas(query: string, filters: SearchFilters = {}) {
  const db = await getDb(),
    where = ["i.deleted_at IS NULL"];
  const args: SQLiteBindValue[] = [];
  if (!filters.includeArchived) where.push("i.stage<>'archived'");
  for (const [key, column] of [
    ["stage", "stage"],
    ["categoryId", "primary_category_id"],
    ["sourceType", "source_type"],
    ["horizon", "horizon"],
    ["energy", "energy"],
  ] as const) {
    if (filters[key]) {
      where.push(`i.${column}=?`);
      args.push(filters[key]!);
    }
  }
  if (filters.starred) where.push("i.is_starred=1");
  if (filters.tag) {
    where.push(
      "EXISTS (SELECT 1 FROM idea_tags fit JOIN tags ft ON ft.id=fit.tag_id WHERE fit.idea_id=i.id AND ft.normalized_name LIKE ?)",
    );
    args.push(`${normalizeTag(filters.tag)}%`);
  }
  if (filters.since) {
    where.push("i.created_at>=?");
    args.push(filters.since);
  }
  if (filters.projectId) {
    where.push(
      "EXISTS(SELECT 1 FROM project_ideas p WHERE p.idea_id=i.id AND p.project_id=?)",
    );
    args.push(filters.projectId);
  }
  const pageLimit = Math.max(1, Math.floor(filters.limit ?? 60));
  const pageOffset = Math.max(0, filters.offset ?? 0);
  const fts = safeFtsQuery(query);
  if (!fts)
    return db.getAllAsync<Idea>(
      `${IDEA_SELECT} WHERE ${where.join(" AND ")} ORDER BY i.is_starred DESC,i.updated_at DESC,i.id DESC LIMIT ? OFFSET ?`,
      ...args,
      pageLimit,
      pageOffset,
    );
  if (!(await supportsFts5(db))) {
    // Some browser SQLite builds omit FTS5. Keep all data and use a literal,
    // bound substring search over the same indexed text; native FTS is retained.
    const terms = query.match(/[\p{L}\p{M}\p{N}_]+/gu)?.slice(0, 8) ?? [];
    for (const term of terms) {
      where.push(
        "EXISTS (SELECT 1 FROM idea_fts f WHERE f.idea_id=i.id AND (COALESCE(f.title,'') || ' ' || COALESCE(f.summary,'') || ' ' || COALESCE(f.body,'')) LIKE ? ESCAPE '\\')",
      );
      args.push(`%${term.replace(/[\\%_]/g, "\\$&")}%`);
    }
    return db.getAllAsync<Idea>(
      `${IDEA_SELECT} WHERE ${where.join(" AND ")} ORDER BY i.is_starred DESC,i.updated_at DESC,i.id DESC LIMIT ? OFFSET ?`,
      ...args,
      pageLimit,
      pageOffset,
    );
  }
  return db.getAllAsync<Idea>(
    `SELECT i.*,c.name AS category_name,snippet(idea_fts,3,'‹','›','…',14) AS snippet FROM idea_fts JOIN ideas i ON i.id=idea_fts.idea_id LEFT JOIN categories c ON c.id=i.primary_category_id WHERE idea_fts MATCH ? AND ${where.join(" AND ")} ORDER BY bm25(idea_fts,0,8,4,1),i.updated_at DESC,i.id DESC LIMIT ? OFFSET ?`,
    fts,
    ...args,
    pageLimit,
    pageOffset,
  );
}
async function cancelReminders(id: string) {
  const rows = await (
    await getDb()
  ).getAllAsync<{ notification_id: string | null }>(
    "SELECT notification_id FROM reminders WHERE idea_id=? AND completed_at IS NULL",
    id,
  );
  await Promise.all(
    rows.map((r) =>
      r.notification_id
        ? Notifications.cancelScheduledNotificationAsync(
            r.notification_id,
          ).catch(() => {})
        : Promise.resolve(),
    ),
  );
}
export async function softDeleteIdea(id: string) {
  await cancelReminders(id);
  return writeDb(async (db) => {
    await db.runAsync(
      "UPDATE ideas SET deleted_at=?,updated_at=? WHERE id=?",
      Date.now(),
      Date.now(),
      id,
    );
    await db.runAsync(
      "UPDATE reminders SET completed_at=? WHERE idea_id=? AND completed_at IS NULL",
      Date.now(),
      id,
    );
    await logEvent(db, id, "trashed");
  });
}
export async function listTrash() {
  return (await getDb()).getAllAsync<Idea>(
    `${IDEA_SELECT} WHERE i.deleted_at IS NOT NULL ORDER BY i.deleted_at DESC`,
  );
}
export const restoreIdea = (id: string) =>
  writeDb(async (db) => {
    await db.runAsync(
      "UPDATE ideas SET deleted_at=NULL,updated_at=? WHERE id=?",
      Date.now(),
      id,
    );
    await logEvent(db, id, "restored");
  });
export async function permanentlyDeleteIdea(id: string) {
  await cancelReminders(id);
  const files = await (
    await getDb()
  ).getAllAsync<{ local_uri: string }>(
    "SELECT local_uri FROM attachments WHERE idea_id=?",
    id,
  );
  await writeDb(async (db) => {
    await db.runAsync("DELETE FROM idea_fts WHERE idea_id=?", id);
    await db.runAsync("DELETE FROM ideas WHERE id=?", id);
  });
  for (const file of files)
    if (file.local_uri.startsWith("file://"))
      await FileSystem.deleteAsync(file.local_uri, { idempotent: true }).catch(
        () => {},
      );
}
export const saveDraft = (
  id: string,
  body: string,
  mode = "text",
  uri: string | null = null,
  metadata: string | null = null,
) =>
  writeDb(async (db) => {
    await db.runAsync(
      `INSERT INTO drafts(id,body_text,mode,attachment_uri,metadata_json,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET body_text=excluded.body_text,mode=excluded.mode,attachment_uri=excluded.attachment_uri,metadata_json=excluded.metadata_json,updated_at=excluded.updated_at`,
      id,
      body,
      mode,
      uri,
      metadata,
      Date.now(),
    );
  });
export async function getDraft(id: string) {
  return (await getDb()).getFirstAsync<{
    id: string;
    body_text: string;
    mode: string;
    attachment_uri: string | null;
    metadata_json: string | null;
    updated_at: number;
  }>("SELECT * FROM drafts WHERE id=?", id);
}
export const clearDraft = (id: string) =>
  writeDb(async (db) => {
    await db.runAsync("DELETE FROM drafts WHERE id=?", id);
  });
