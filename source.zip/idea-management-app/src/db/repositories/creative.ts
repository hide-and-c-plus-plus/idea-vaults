import { recordRevision } from "./revisions";
import { getDb } from "../database";
import { writeDb } from "../write";
import { createId } from "@/utils/id";
import { cleanText, focusProgress, localDayKey } from "@/domain/logic";
import type {
  ActionItem,
  Capsule,
  Experiment,
  ExperimentVerdict,
  FocusSession,
  GraphEdge,
  Project,
  ReviewEntry,
  SavedView,
} from "@/domain/creative";
import type { Idea } from "@/domain/types";
import {
  IDEA_SELECT,
  insertCapture,
  insertTextBlock,
  logEvent,
  syncFts,
} from "./ideas";
import type { SQLiteDatabase } from "expo-sqlite";

async function requireIdea(db: SQLiteDatabase, id: string) {
  if (
    !(await db.getFirstAsync(
      "SELECT id FROM ideas WHERE id=? AND deleted_at IS NULL",
      id,
    ))
  )
    throw new Error("This idea is no longer available.");
}
export async function getSetting(key: string) {
  return (
    (
      await (
        await getDb()
      ).getFirstAsync<{ value: string }>(
        "SELECT value FROM app_settings WHERE key=?",
        key,
      )
    )?.value ?? null
  );
}
export const setSetting = (key: string, value: string) =>
  writeDb(async (db) => {
    await db.runAsync(
      "INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
      key,
      value,
    );
  });

export function createBranch(input: {
  title: string;
  body: string;
  parents: string[];
  source: string;
}) {
  const title = cleanText(input.title, "Title", 180),
    body = cleanText(input.body, "New idea");
  const parents = [...new Set(input.parents)];
  return writeDb(async (db) => {
    for (const parent of parents) {
      await requireIdea(db, parent);
      const contract = await db.getFirstAsync<{
        sanctuary: number;
        protected_phrase: string;
      }>(
        "SELECT sanctuary,protected_phrase FROM thought_contracts WHERE idea_id=?",
        parent,
      );
      if (
        contract?.sanctuary &&
        /assumption|council|red_team/.test(input.source)
      )
        throw Error(
          "This thought is in sanctuary. Change its intention before critique.",
        );
      if (
        contract?.protected_phrase &&
        !body.includes(contract.protected_phrase)
      )
        throw Error(
          "Keep this protected phrase in the branch: " +
            contract.protected_phrase,
        );
    }
    const id = await insertCapture(db, {
      title,
      text: body,
      sourceType: input.source,
    });
    for (const parent of parents) {
      await db.runAsync(
        "INSERT INTO idea_links(id,source_idea_id,target_idea_id,link_type,note,created_at) VALUES(?,?,?,?,?,?)",
        createId("link"),
        id,
        parent,
        parents.length > 1 ? "combines_with" : "inspired_by",
        `Created in ${input.source.replaceAll("_", " ")}`,
        Date.now(),
      );
      await logEvent(db, parent, "inspired_branch", { childId: id });
    }
    await logEvent(db, id, "creative_branch", { parents, tool: input.source });
    return id;
  });
}
export async function listProjects() {
  return (await getDb()).getAllAsync<Project>(
    `SELECT p.*,COUNT(i.id) AS idea_count FROM projects p LEFT JOIN project_ideas pi ON pi.project_id=p.id LEFT JOIN ideas i ON i.id=pi.idea_id AND i.deleted_at IS NULL GROUP BY p.id ORDER BY p.created_at DESC`,
  );
}
export function saveProject(input: {
  id?: string;
  name: string;
  intention: string;
  color: string;
}) {
  const name = cleanText(input.name, "Project name", 100),
    id = input.id ?? createId("project");
  return writeDb(async (db) => {
    await db.runAsync(
      `INSERT INTO projects(id,name,intention,color,created_at) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,intention=excluded.intention,color=excluded.color`,
      id,
      name,
      input.intention.trim(),
      input.color,
      Date.now(),
    );
    return id;
  });
}
export const deleteProject = (id: string) =>
  writeDb(async (db) => {
    await db.runAsync("DELETE FROM projects WHERE id=?", id);
  });
export async function projectMembership(ideaId: string) {
  return (await getDb()).getAllAsync<{ project_id: string }>(
    "SELECT project_id FROM project_ideas WHERE idea_id=?",
    ideaId,
  );
}
export const toggleProjectIdea = (projectId: string, ideaId: string) =>
  writeDb(async (db) => {
    await requireIdea(db, ideaId);
    const exists = await db.getFirstAsync(
      "SELECT 1 FROM project_ideas WHERE project_id=? AND idea_id=?",
      projectId,
      ideaId,
    );
    await db.runAsync(
      exists
        ? "DELETE FROM project_ideas WHERE project_id=? AND idea_id=?"
        : "INSERT INTO project_ideas(project_id,idea_id) VALUES(?,?)",
      projectId,
      ideaId,
    );
  });
export async function listActions(ideaId: string) {
  return (await getDb()).getAllAsync<ActionItem>(
    "SELECT * FROM action_items WHERE idea_id=? ORDER BY done_at IS NOT NULL,created_at",
    ideaId,
  );
}
export const addAction = (ideaId: string, body: string) =>
  writeDb(async (db) => {
    await requireIdea(db, ideaId);
    const id = createId("task");
    await db.runAsync(
      "INSERT INTO action_items(id,idea_id,body,created_at) VALUES(?,?,?,?)",
      id,
      ideaId,
      cleanText(body, "Next move", 500),
      Date.now(),
    );
    await syncNextAction(db, ideaId);
    await syncFts(db, ideaId);
    await logEvent(db, ideaId, "action_added");
    return id;
  });
export const toggleAction = (id: string) =>
  writeDb(async (db) => {
    const item = await db.getFirstAsync<ActionItem>(
      "SELECT * FROM action_items WHERE id=?",
      id,
    );
    if (!item) return;
    await db.runAsync(
      "UPDATE action_items SET done_at=? WHERE id=?",
      item.done_at ? null : Date.now(),
      id,
    );
    await syncNextAction(db, item.idea_id);
    await syncFts(db, item.idea_id);
    await logEvent(
      db,
      item.idea_id,
      item.done_at ? "action_reopened" : "action_completed",
    );
  });
export const removeAction = (id: string) =>
  writeDb(async (db) => {
    const item = await db.getFirstAsync<ActionItem>(
      "SELECT * FROM action_items WHERE id=?",
      id,
    );
    await db.runAsync("DELETE FROM action_items WHERE id=?", id);
    if (item) {
      await syncNextAction(db, item.idea_id);
      await syncFts(db, item.idea_id);
    }
  });
export async function listExperiments(ideaId?: string) {
  return (await getDb()).getAllAsync<Experiment & { idea_title: string }>(
    `SELECT e.*,i.title AS idea_title FROM experiments e JOIN ideas i ON i.id=e.idea_id WHERE i.deleted_at IS NULL ${ideaId ? "AND e.idea_id=?" : ""} ORDER BY e.updated_at DESC`,
    ...(ideaId ? [ideaId] : []),
  );
}
export function createExperiment(input: {
  ideaId: string;
  hypothesis: string;
  method: string;
  signal: string;
}) {
  const hypothesis = cleanText(input.hypothesis, "Hypothesis", 3000),
    method = cleanText(input.method, "Test", 3000),
    signal = cleanText(input.signal, "Success signal", 3000);
  return writeDb(async (db) => {
    await requireIdea(db, input.ideaId);
    const id = createId("experiment"),
      now = Date.now();
    await db.runAsync(
      "INSERT INTO experiments(id,idea_id,hypothesis,method,success_signal,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
      id,
      input.ideaId,
      hypothesis,
      method,
      signal,
      now,
      now,
    );
    await db.runAsync(
      "INSERT INTO experiment_protocols(id,experiment_id,hypothesis,method,success_signal,created_at) VALUES(?,?,?,?,?,?)",
      createId("protocol"),
      id,
      hypothesis,
      method,
      signal,
      now,
    );
    await syncFts(db, input.ideaId);
    await logEvent(db, input.ideaId, "experiment_created", { id });
    return id;
  });
}
const verdicts: ExperimentVerdict[] = [
  "untested",
  "running",
  "supported",
  "challenged",
  "inconclusive",
];
export function updateExperiment(
  id: string,
  result: string,
  verdict: ExperimentVerdict,
) {
  if (!verdicts.includes(verdict))
    throw new Error("Unknown experiment outcome.");
  if (
    ["supported", "challenged", "inconclusive"].includes(verdict) &&
    !result.trim()
  )
    throw new Error("Record what you observed before choosing an outcome.");
  return writeDb(async (db) => {
    const e = await db.getFirstAsync<Experiment>(
      "SELECT * FROM experiments WHERE id=?",
      id,
    );
    if (!e) throw new Error("Experiment not found.");
    await db.runAsync(
      "UPDATE experiments SET result=?,verdict=?,updated_at=? WHERE id=?",
      result.trim(),
      verdict,
      Date.now(),
      id,
    );
    await syncFts(db, e.idea_id);
    await logEvent(db, e.idea_id, "experiment_updated", { id, verdict });
  });
}
export async function listCapsules() {
  // Conceal future letters from list rendering; they are still plain local data.
  return (await getDb()).getAllAsync<Capsule>(
    `SELECT id,idea_id,title,CASE WHEN unlock_at<=? THEN body ELSE '' END AS body,unlock_at,opened_at,created_at FROM time_capsules ORDER BY opened_at IS NOT NULL,unlock_at`,
    Date.now(),
  );
}
export function createCapsule(input: {
  ideaId?: string;
  title: string;
  body: string;
  unlockAt: number;
}) {
  const title = cleanText(input.title, "Capsule title", 180),
    body = cleanText(input.body, "Letter");
  if (!Number.isFinite(input.unlockAt) || input.unlockAt <= Date.now())
    throw new Error("Choose a date in the future.");
  return writeDb(async (db) => {
    if (input.ideaId) await requireIdea(db, input.ideaId);
    const id = createId("capsule");
    await db.runAsync(
      "INSERT INTO time_capsules(id,idea_id,title,body,unlock_at,created_at) VALUES(?,?,?,?,?,?)",
      id,
      input.ideaId ?? null,
      title,
      body,
      input.unlockAt,
      Date.now(),
    );
    if (input.ideaId)
      await logEvent(db, input.ideaId, "capsule_sealed", { id });
    return id;
  });
}
export const openCapsule = (id: string) =>
  writeDb(async (db) => {
    const row = await db.getFirstAsync<Capsule>(
      "SELECT * FROM time_capsules WHERE id=? AND unlock_at<=?",
      id,
      Date.now(),
    );
    if (!row) throw new Error("This capsule is still incubating.");
    await db.runAsync(
      "UPDATE time_capsules SET opened_at=COALESCE(opened_at,?) WHERE id=?",
      Date.now(),
      id,
    );
    return row;
  });
export const deleteCapsule = (id: string) =>
  writeDb(async (db) => {
    await db.runAsync("DELETE FROM time_capsules WHERE id=?", id);
  });
export async function currentFocus() {
  return (await getDb()).getFirstAsync<FocusSession>(
    "SELECT * FROM focus_sessions WHERE status='running' LIMIT 1",
  );
}
export async function focusHistory() {
  return (await getDb()).getAllAsync<FocusSession>(
    "SELECT * FROM focus_sessions WHERE status<>'running' ORDER BY started_at DESC LIMIT 20",
  );
}
export function startFocus(input: {
  ideaId?: string;
  intention: string;
  seconds: number;
}) {
  const intention = cleanText(input.intention, "Intention", 500);
  if (
    !Number.isInteger(input.seconds) ||
    input.seconds < 60 ||
    input.seconds > 7200
  )
    throw new Error("Choose a session between 1 and 120 minutes.");
  return writeDb(async (db) => {
    if (
      await db.getFirstAsync(
        "SELECT id FROM focus_sessions WHERE status='running'",
      )
    )
      throw new Error("Finish your current focus session first.");
    if (input.ideaId) await requireIdea(db, input.ideaId);
    const id = createId("focus"),
      now = Date.now();
    await db.runAsync(
      "INSERT INTO focus_sessions(id,idea_id,intention,planned_seconds,started_at,ends_at) VALUES(?,?,?,?,?,?)",
      id,
      input.ideaId ?? null,
      intention,
      input.seconds,
      now,
      now + input.seconds * 1000,
    );
    return id;
  });
}
export const saveFocusNotes = (id: string, notes: string) =>
  writeDb(async (db) => {
    await db.runAsync(
      "UPDATE focus_sessions SET notes=? WHERE id=? AND status='running'",
      notes,
      id,
    );
  });
export const finishFocus = (
  id: string,
  notes: string,
  checkpoint?: { changed: string; question: string; restart: string },
) =>
  writeDb(async (db) => {
    const session = await db.getFirstAsync<FocusSession>(
      "SELECT * FROM focus_sessions WHERE id=? AND status='running'",
      id,
    );
    if (!session) return;
    const now = Date.now(),
      { elapsed, remaining } = focusProgress(session, now);
    await db.runAsync(
      "UPDATE focus_sessions SET notes=?,elapsed_seconds=?,completed_at=?,status=? WHERE id=?",
      notes.trim(),
      elapsed,
      now,
      remaining === 0 ? "completed" : "ended",
      id,
    );
    if (session.idea_id) {
      if (checkpoint?.restart.trim()) {
        await recordRevision(db, session.idea_id, "Focus exit");
        await db.runAsync(
          "INSERT INTO session_checkpoints(id,idea_id,changed,open_question,restart,created_at) VALUES(?,?,?,?,?,?)",
          createId("checkpoint"),
          session.idea_id,
          checkpoint.changed.trim(),
          checkpoint.question.trim(),
          checkpoint.restart.trim(),
          now,
        );
        await syncFts(db, session.idea_id);
      }
      if (notes.trim())
        await insertTextBlock(
          db,
          session.idea_id,
          `Focus session: ${session.intention}\n\n${notes.trim()}`,
        );
      await logEvent(db, session.idea_id, "focus_finished", {
        seconds: elapsed,
      });
    }
  });
export async function listGraph() {
  const db = await getDb();
  const ideas = await db.getAllAsync<Idea>(
    `${IDEA_SELECT} WHERE i.deleted_at IS NULL AND i.stage<>'archived' ORDER BY i.is_starred DESC,i.updated_at DESC`,
  );
  const edges = await db.getAllAsync<GraphEdge>(
    `SELECT l.* FROM idea_links l JOIN ideas s ON s.id=l.source_idea_id JOIN ideas t ON t.id=l.target_idea_id WHERE s.deleted_at IS NULL AND t.deleted_at IS NULL AND s.stage<>'archived' AND t.stage<>'archived'`,
  );
  const protectedIdeas = await db.getAllAsync<{ idea_id: string }>(
    "SELECT idea_id FROM thought_contracts WHERE intent='private' OR sanctuary=1",
  );
  const rejected = await db.getAllAsync<{
    source_id: string;
    target_id: string;
  }>(
    "SELECT source_id,target_id FROM bridge_proposals WHERE status='rejected'",
  );
  return {
    ideas,
    edges,
    protectedIds: protectedIdeas.map((x) => x.idea_id),
    rejected,
  };
}
export async function ideaEvents(id: string) {
  return (await getDb()).getAllAsync<{
    id: string;
    event_type: string;
    payload_json: string | null;
    created_at: number;
  }>(
    "SELECT * FROM idea_events WHERE idea_id=? ORDER BY created_at DESC LIMIT 40",
    id,
  );
}
export async function savedViews() {
  return (await getDb()).getAllAsync<SavedView>(
    "SELECT * FROM saved_views ORDER BY created_at DESC",
  );
}
export function saveView(name: string, query: string, filters: unknown) {
  return writeDb(async (db) => {
    await db.runAsync(
      "INSERT INTO saved_views(id,name,query,filters_json,created_at) VALUES(?,?,?,?,?)",
      createId("view"),
      cleanText(name, "View name", 60),
      query,
      JSON.stringify(filters),
      Date.now(),
    );
  });
}
export const removeView = (id: string) =>
  writeDb(async (db) => {
    await db.runAsync("DELETE FROM saved_views WHERE id=?", id);
  });
export function saveReview(learned: string, release: string, next: string) {
  if (!learned.trim() && !release.trim() && !next.trim())
    throw new Error("Write at least one reflection before saving.");
  return writeDb(async (db) => {
    await db.runAsync(
      "INSERT INTO review_entries(id,learned,release_note,next_week,created_at) VALUES(?,?,?,?,?)",
      createId("review"),
      learned.trim(),
      release.trim(),
      next.trim(),
      Date.now(),
    );
  });
}
export async function reviewHistory() {
  return (await getDb()).getAllAsync<ReviewEntry>(
    "SELECT * FROM review_entries ORDER BY created_at DESC LIMIT 12",
  );
}
export async function getInsights() {
  const db = await getDb();
  const stats = await db.getFirstAsync<{
    total: number;
    inbox: number;
    active: number;
    done: number;
    stars: number;
  }>(
    `SELECT COUNT(*) AS total,COALESCE(SUM(inbox_state='unprocessed'),0) AS inbox,COALESCE(SUM(stage='active'),0) AS active,COALESCE(SUM(stage='done'),0) AS done,COALESCE(SUM(is_starred),0) AS stars FROM ideas WHERE deleted_at IS NULL AND stage<>'archived'`,
  );
  const rows = await db.getAllAsync<{ created_at: number }>(
    `SELECT e.created_at FROM idea_events e JOIN ideas i ON i.id=e.idea_id WHERE i.deleted_at IS NULL AND e.created_at>=? UNION ALL SELECT created_at FROM review_entries WHERE created_at>=?`,
    Date.now() - 366 * 86400000,
    Date.now() - 366 * 86400000,
  );
  const activity: Record<string, number> = {};
  for (const row of rows) {
    const day = localDayKey(new Date(row.created_at));
    activity[day] = (activity[day] ?? 0) + 1;
  }
  const completed = await db.getFirstAsync<{ count: number }>(
    `SELECT COUNT(*) AS count FROM action_items a JOIN ideas i ON i.id=a.idea_id WHERE a.done_at IS NOT NULL AND i.deleted_at IS NULL`,
  );
  const sessions = await db.getFirstAsync<{ seconds: number; count: number }>(
    "SELECT COALESCE(SUM(elapsed_seconds),0) AS seconds,COUNT(*) AS count FROM focus_sessions WHERE status<>'running'",
  );
  const experiments = await db.getFirstAsync<{ count: number }>(
    `SELECT COUNT(*) AS count FROM experiments e JOIN ideas i ON i.id=e.idea_id WHERE e.verdict IN ('supported','challenged','inconclusive') AND i.deleted_at IS NULL`,
  );
  const links = await db.getFirstAsync<{ count: number }>(
    `SELECT COUNT(*) AS count FROM idea_links l JOIN ideas s ON s.id=l.source_idea_id JOIN ideas t ON t.id=l.target_idea_id WHERE s.deleted_at IS NULL AND t.deleted_at IS NULL`,
  );
  const capsules = await db.getFirstAsync<{ count: number }>(
    "SELECT COUNT(*) AS count FROM time_capsules WHERE unlock_at<=? AND opened_at IS NULL",
    Date.now(),
  );
  return {
    stats: stats ?? { total: 0, inbox: 0, active: 0, done: 0, stars: 0 },
    activity,
    actions: completed?.count ?? 0,
    focusSeconds: sessions?.seconds ?? 0,
    focusCount: sessions?.count ?? 0,
    experiments: experiments?.count ?? 0,
    links: links?.count ?? 0,
    readyCapsules: capsules?.count ?? 0,
  };
}
export function seedPlayground() {
  return writeDb(async (db) => {
    if (
      await db.getFirstAsync(
        "SELECT key FROM app_settings WHERE key='playground_added'",
      )
    )
      return false;
    const samples = [
      [
        "A tiny library of unfinished questions",
        "What if our classroom had a living collection of questions nobody is embarrassed to ask? Each question could gain examples, sketches, and better questions.",
        "cat_learning",
      ],
      [
        "The quiet study companion",
        "An offline study tool that begins with one intention and ends with one thing learned. No endless feed, no comparison, just a small visible trail.",
        "cat_technology",
      ],
      [
        "A garden for borrowed skills",
        "A hostel skill-swap where one person teaches a small skill and learns another. Each exchange leaves a reusable learning card.",
        "cat_personal",
      ],
      [
        "Pocket museum of ordinary things",
        "Photograph an ordinary object and tell the hidden story behind its design. Make a tiny museum people can walk through on their way home.",
        "cat_creative",
      ],
      [
        "A repair cafe for code",
        "A friendly weekly table where students bring one broken program and leave with an explanation, not just a fix.",
        "cat_technology",
      ],
      [
        "One-minute field notes",
        "Capture the real workaround before inventing the solution. Collect a week of small frustrations and look for repeated patterns.",
        "cat_problem",
      ],
    ];
    const ids: string[] = [];
    for (const [title, body, category] of samples) {
      const id = await insertCapture(db, {
        title: `[Playground] ${title}`,
        text: body,
        sourceType: "playground",
      });
      ids.push(id);
      await db.runAsync(
        "UPDATE ideas SET primary_category_id=?,inbox_state='processed' WHERE id=?",
        category!,
        id,
      );
    }
    for (const [a, b, type] of [
      [0, 1, "builds_on"],
      [1, 4, "related_to"],
      [2, 4, "combines_with"],
      [3, 5, "inspired_by"],
    ] as const) {
      await db.runAsync(
        "INSERT INTO idea_links(id,source_idea_id,target_idea_id,link_type,created_at) VALUES(?,?,?,?,?)",
        createId("link"),
        ids[a]!,
        ids[b]!,
        type,
        Date.now(),
      );
    }
    await db.runAsync(
      "UPDATE ideas SET stage='active',is_starred=1 WHERE id=?",
      ids[1]!,
    );
    await db.runAsync(
      "INSERT INTO app_settings(key,value) VALUES('playground_added','true')",
    );
    return true;
  });
}

async function syncNextAction(db: SQLiteDatabase, ideaId: string) {
  const next = await db.getFirstAsync<{ id: string; body: string }>(
    "SELECT id,body FROM action_items WHERE idea_id=? AND done_at IS NULL ORDER BY created_at,id LIMIT 1",
    ideaId,
  );
  await db.runAsync(
    "UPDATE ideas SET next_action_id=?,next_action=? WHERE id=?",
    next?.id ?? null,
    next?.body ?? null,
    ideaId,
  );
}
