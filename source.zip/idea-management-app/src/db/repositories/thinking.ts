import { getDb } from "../database";
import { writeDb } from "../write";
import { createId } from "@/utils/id";
import {
  IDEA_SELECT,
  insertCapture,
  insertTextBlock,
  logEvent,
  syncFts,
} from "./ideas";
import { BRIEF_FIELDS, coreSnapshot, recordRevision } from "./revisions";
import { RECIPES } from "@/domain/recipes";
import { CARD_KINDS, EPISTEMIC } from "@/domain/thinking";
import type {
  ThoughtCard,
  CardKind,
  Checkpoint,
  Inquiry,
  Contract,
  Revision,
  WorkshopEntry,
  Bridge,
  Observation,
} from "@/domain/thinking";
import type { Idea } from "@/domain/types";
import type { SQLiteDatabase } from "expo-sqlite";
const required = (text: string, label: string, max = 20000) => {
  const value = text.trim();
  if (!value) throw Error(`${label} is empty.`);
  if (value.length > max) throw Error(`${label} is too long.`);
  return value;
};
async function live(db: SQLiteDatabase, id: string) {
  if (
    !(await db.getFirstAsync(
      "SELECT id FROM ideas WHERE id=? AND deleted_at IS NULL",
      id,
    ))
  )
    throw Error("This thought is no longer available.");
}
export async function getContract(id: string) {
  return (await getDb()).getFirstAsync<Contract>(
    "SELECT * FROM thought_contracts WHERE idea_id=?",
    id,
  );
}
export function saveContract(
  id: string,
  input: Omit<Contract, "idea_id" | "updated_at">,
) {
  if (
    !["remember", "explore", "test", "express", "share", "private"].includes(
      input.intent,
    )
  )
    throw Error("Choose a valid intention.");
  if (!["explore", "commit"].includes(input.mode))
    throw Error("Choose an exploration mode.");
  return writeDb(async (db) => {
    await live(db, id);
    await db.runAsync(
      `INSERT INTO thought_contracts(idea_id,intent,mode,sanctuary,protected_phrase,revisit_when,context,updated_at) VALUES(?,?,?,?,?,?,?,?)
      ON CONFLICT(idea_id) DO UPDATE SET intent=excluded.intent,mode=excluded.mode,sanctuary=excluded.sanctuary,protected_phrase=excluded.protected_phrase,revisit_when=excluded.revisit_when,context=excluded.context,updated_at=excluded.updated_at`,
      id,
      input.intent,
      input.mode,
      input.sanctuary ? 1 : 0,
      input.protected_phrase.trim(),
      input.revisit_when.trim(),
      input.context.trim(),
      Date.now(),
    );
    await syncFts(db, id);
    await logEvent(db, id, "contract_changed");
    return true;
  });
}
export async function checkpoints(id?: string) {
  return (await getDb()).getAllAsync<Checkpoint>(
    `SELECT c.*,i.title AS idea_title FROM session_checkpoints c JOIN ideas i ON i.id=c.idea_id WHERE i.deleted_at IS NULL ${id ? "AND c.idea_id=?" : ""} ORDER BY c.created_at DESC,c.rowid DESC LIMIT 50`,
    ...(id ? [id] : []),
  );
}
export function saveCheckpoint(
  ideaId: string,
  changed: string,
  question: string,
  restart: string,
) {
  const cue = required(restart, "Restart cue");
  return writeDb(async (db) => {
    await live(db, ideaId);
    await recordRevision(db, ideaId, "Session checkpoint");
    const id = createId("checkpoint");
    await db.runAsync(
      "INSERT INTO session_checkpoints(id,idea_id,changed,open_question,restart,created_at) VALUES(?,?,?,?,?,?)",
      id,
      ideaId,
      changed.trim(),
      question.trim(),
      cue,
      Date.now(),
    );
    await syncFts(db, ideaId);
    return id;
  });
}
export async function listInquiries() {
  return (await getDb()).getAllAsync<Inquiry>(
    `SELECT q.*,COUNT(i.id) AS member_count FROM inquiries q LEFT JOIN inquiry_members m ON m.inquiry_id=q.id LEFT JOIN ideas i ON i.id=m.idea_id AND i.deleted_at IS NULL GROUP BY q.id ORDER BY q.updated_at DESC`,
  );
}
export function saveInquiry(question: string, context: string, id?: string) {
  const key = id ?? createId("inquiry");
  return writeDb(async (db) => {
    await db.runAsync(
      `INSERT INTO inquiries(id,question,context,created_at,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET question=excluded.question,context=excluded.context,updated_at=excluded.updated_at`,
      key,
      required(question, "Question", 300),
      context.trim(),
      Date.now(),
      Date.now(),
    );
    return key;
  });
}
export async function inquiryDetail(id: string) {
  const db = await getDb();
  return {
    room: await db.getFirstAsync<Inquiry>(
      "SELECT * FROM inquiries WHERE id=?",
      id,
    ),
    members: await db.getAllAsync<Idea & { role: string }>(
      `SELECT i.*,m.role FROM inquiry_members m JOIN ideas i ON i.id=m.idea_id WHERE m.inquiry_id=? AND i.deleted_at IS NULL ORDER BY m.created_at`,
      id,
    ),
    cards: await db.getAllAsync<ThoughtCard>(
      `SELECT c.*,i.title AS idea_title FROM thought_cards c JOIN inquiry_members m ON m.idea_id=c.idea_id JOIN ideas i ON i.id=c.idea_id WHERE m.inquiry_id=? AND i.deleted_at IS NULL ORDER BY c.created_at DESC`,
      id,
    ),
  };
}
export const setInquiryStatus = (id: string, status: string) =>
  writeDb(async (db) => {
    if (!["open", "resting", "resolved"].includes(status))
      throw Error("Unknown room status.");
    await db.runAsync(
      "UPDATE inquiries SET status=?,updated_at=? WHERE id=?",
      status,
      Date.now(),
      id,
    );
    return true;
  });
export function joinInquiry(room: string, idea: string, role: string) {
  return writeDb(async (db) => {
    await live(db, idea);
    if (
      ![
        "material",
        "question",
        "answer",
        "observation",
        "counterexample",
        "experiment",
      ].includes(role)
    )
      throw Error("Unknown room role.");
    await db.runAsync(
      "INSERT INTO inquiry_members(inquiry_id,idea_id,role,created_at) VALUES(?,?,?,?) ON CONFLICT(inquiry_id,idea_id) DO UPDATE SET role=excluded.role",
      room,
      idea,
      role,
      Date.now(),
    );
    await db.runAsync(
      "UPDATE inquiries SET updated_at=? WHERE id=?",
      Date.now(),
      room,
    );
    return true;
  });
}
export const leaveInquiry = (room: string, idea: string) =>
  writeDb(async (db) => {
    await db.runAsync(
      "DELETE FROM inquiry_members WHERE inquiry_id=? AND idea_id=?",
      room,
      idea,
    );
    return true;
  });
export const deleteInquiry = (id: string) =>
  writeDb(async (db) => {
    await db.runAsync("DELETE FROM inquiries WHERE id=?", id);
    return true;
  });
export async function cards(ideaId?: string, kind?: string, query = "") {
  const args: string[] = [];
  let where = "i.deleted_at IS NULL";
  if (ideaId) {
    where += " AND c.idea_id=?";
    args.push(ideaId);
  }
  if (kind) {
    where += " AND c.kind=?";
    args.push(kind);
  }
  if (query.trim()) {
    where +=
      " AND (c.title||' '||c.body||' '||c.interpretation||' '||c.source_quote) LIKE ? ESCAPE '\\'";
    args.push("%" + query.replace(/[\\%_]/g, "\\$&") + "%");
  }
  return (await getDb()).getAllAsync<ThoughtCard>(
    `SELECT c.*,i.title AS idea_title FROM thought_cards c JOIN ideas i ON i.id=c.idea_id WHERE ${where} ORDER BY c.created_at DESC`,
    ...args,
  );
}
export function saveCard(input: {
  id?: string;
  ideaId: string;
  kind: CardKind;
  title: string;
  body?: string;
  interpretation?: string;
  sourceUrl?: string;
  sourceQuote?: string;
  epistemic?: string;
  relation?: string;
  relatedCardId?: string;
}) {
  if (!Object.hasOwn(CARD_KINDS, input.kind)) throw Error("Unknown card type.");
  if (input.sourceUrl && !/^https?:\/\//i.test(input.sourceUrl))
    throw Error("Use a full http or https source address.");
  if (input.epistemic && !EPISTEMIC.includes(input.epistemic as any))
    throw Error("Choose an evidence label.");
  return writeDb(async (db) => {
    await live(db, input.ideaId);
    const id = input.id ?? createId("card"),
      now = Date.now();
    if (
      input.id &&
      !(await db.getFirstAsync(
        "SELECT id FROM thought_cards WHERE id=? AND idea_id=?",
        id,
        input.ideaId,
      ))
    )
      throw Error("Card does not belong to this thought.");
    if (input.relatedCardId) {
      const target = await db.getFirstAsync<ThoughtCard>(
        "SELECT * FROM thought_cards WHERE id=?",
        input.relatedCardId,
      );
      if (!target || target.id === id)
        throw Error("Choose another existing card.");
      await live(db, target.idea_id);
    }
    await db.runAsync(
      `INSERT INTO thought_cards(id,idea_id,kind,title,body,interpretation,source_url,source_quote,epistemic,relation,related_card_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,body=excluded.body,interpretation=excluded.interpretation,source_url=excluded.source_url,source_quote=excluded.source_quote,epistemic=excluded.epistemic,relation=excluded.relation,related_card_id=excluded.related_card_id,updated_at=excluded.updated_at`,
      id,
      input.ideaId,
      input.kind,
      required(input.title, "Statement", 500),
      input.body?.trim() ?? "",
      input.interpretation?.trim() ?? "",
      input.sourceUrl?.trim() ?? "",
      input.sourceQuote?.trim() ?? "",
      input.epistemic ?? "unresolved",
      input.relation ?? "",
      input.relatedCardId || null,
      now,
      now,
    );
    await logEvent(db, input.ideaId, "card_saved", {
      cardId: id,
      kind: input.kind,
    });
    await syncFts(db, input.ideaId);
    return id;
  });
}
export const setCardStatus = (id: string, status: string) =>
  writeDb(async (db) => {
    if (
      !["open", "resolved", "challenged", "supported", "retired"].includes(
        status,
      )
    )
      throw Error("Unknown card status.");
    const card = await db.getFirstAsync<ThoughtCard>(
      "SELECT * FROM thought_cards WHERE id=?",
      id,
    );
    if (!card) throw Error("Card not found.");
    await live(db, card.idea_id);
    await db.runAsync(
      "UPDATE thought_cards SET status=?,updated_at=? WHERE id=?",
      status,
      Date.now(),
      id,
    );
    return true;
  });
export const removeCard = (id: string) =>
  writeDb(async (db) => {
    const c = await db.getFirstAsync<ThoughtCard>(
      "SELECT * FROM thought_cards WHERE id=?",
      id,
    );
    await db.runAsync("DELETE FROM thought_cards WHERE id=?", id);
    if (c) await syncFts(db, c.idea_id);
    return true;
  });
export async function revisions(ideaId: string) {
  return (await getDb()).getAllAsync<Revision>(
    "SELECT * FROM thought_revisions WHERE idea_id=? ORDER BY created_at DESC,rowid DESC",
    ideaId,
  );
}
export const snapshotIdea = (ideaId: string, label: string) =>
  writeDb((db) =>
    recordRevision(db, ideaId, required(label, "Version name", 100)),
  );
export function restoreBrief(revisionId: string) {
  return writeDb(async (db) => {
    const revision = await db.getFirstAsync<Revision>(
      "SELECT * FROM thought_revisions WHERE id=?",
      revisionId,
    );
    if (!revision) throw Error("Version not found.");
    const { idea } = JSON.parse(revision.snapshot_json);
    await live(db, revision.idea_id);
    await recordRevision(db, revision.idea_id, "Before restoring brief");
    await db.runAsync(
      `UPDATE ideas SET ${BRIEF_FIELDS.map((f) => f + "=?").join(",")},updated_at=? WHERE id=?`,
      ...BRIEF_FIELDS.map((f) => idea[f] ?? null),
      Date.now(),
      revision.idea_id,
    );
    await recordRevision(db, revision.idea_id, "Restored: " + revision.label);
    await syncFts(db, revision.idea_id);
    return true;
  });
}
export async function workshopHistory(ideaId?: string) {
  return (await getDb()).getAllAsync<WorkshopEntry>(
    `SELECT w.* FROM workshop_entries w JOIN ideas i ON i.id=w.idea_id WHERE i.deleted_at IS NULL ${ideaId ? "AND w.idea_id=?" : ""} ORDER BY w.created_at DESC LIMIT 100`,
    ...(ideaId ? [ideaId] : []),
  );
}
export function saveWorkshop(
  ideaId: string,
  recipeId: string,
  title: string,
  fields: Record<string, string>,
  takeaway: string,
  draftKey?: string,
) {
  if (!Object.values(fields).some((v) => v.trim()))
    throw Error("Add at least one response.");
  return writeDb(async (db) => {
    await live(db, ideaId);
    const contract = await db.getFirstAsync<Contract>(
      "SELECT * FROM thought_contracts WHERE idea_id=?",
      ideaId,
    );
    if (
      contract?.sanctuary &&
      RECIPES.find((r) => r.id === recipeId)?.challenge
    )
      throw Error(
        "This thought is in sanctuary. Choose exploration or change its intention first.",
      );
    const id = createId("workshop");
    await db.runAsync(
      "INSERT INTO workshop_entries(id,idea_id,recipe_id,title,fields_json,takeaway,created_at) VALUES(?,?,?,?,?,?,?)",
      id,
      ideaId,
      recipeId,
      title,
      JSON.stringify(fields),
      takeaway.trim(),
      Date.now(),
    );
    await logEvent(db, ideaId, "thinking_exercise", { id, recipeId });
    await syncFts(db, ideaId);
    if (draftKey) await db.runAsync("DELETE FROM drafts WHERE id=?", draftKey);
    return id;
  });
}
export function extractIngredient(
  ideaId: string,
  title: string,
  excerpt: string,
  why: string,
  retire = false,
) {
  return writeDb(async (db) => {
    await live(db, ideaId);
    await recordRevision(db, ideaId, "Before rescuing ingredient");
    const id = createId("card"),
      now = Date.now();
    await db.runAsync(
      `INSERT INTO thought_cards(id,idea_id,kind,title,body,interpretation,epistemic,created_at,updated_at) VALUES(?,?,'ingredient',?,?,?,'remembered',?,?)`,
      id,
      ideaId,
      required(title, "Ingredient"),
      required(excerpt, "Material"),
      required(why, "Reuse reason"),
      now,
      now,
    );
    if (retire)
      await db.runAsync(
        "UPDATE ideas SET stage='archived',archived_at=?,updated_at=? WHERE id=?",
        now,
        now,
        ideaId,
      );
    await logEvent(db, ideaId, "ingredient_rescued", {
      cardId: id,
      retired: retire,
    });
    await syncFts(db, ideaId);
    return id;
  });
}
// Proposal fingerprints ignore last-seen timestamps; merely reading is not a content edit.
async function fingerprint(db: SQLiteDatabase, id: string) {
  const data = JSON.parse(await coreSnapshot(db, id));
  delete data.idea.last_seen_at;
  delete data.idea.last_touched_at;
  return JSON.stringify(data);
}
export function proposeBridge(
  source: string,
  target: string,
  relation: string,
  rationale: string,
) {
  if (source === target) throw Error("Choose two different thoughts.");
  if (
    ![
      "related_to",
      "builds_on",
      "contradicts",
      "combines_with",
      "inspired_by",
    ].includes(relation)
  )
    throw Error("Choose a relationship.");
  return writeDb(async (db) => {
    const contracts = await db.getAllAsync<Contract>(
      "SELECT * FROM thought_contracts WHERE idea_id IN (?,?)",
      source,
      target,
    );
    if (
      contracts.some(
        (c) =>
          c.intent === "private" || (c.sanctuary && relation === "contradicts"),
      )
    )
      throw Error("This thought’s intention does not allow that suggestion.");
    const id = createId("bridge");
    await db.runAsync(
      "INSERT INTO bridge_proposals(id,source_id,target_id,source_snapshot,target_snapshot,relation,rationale,created_at) VALUES(?,?,?,?,?,?,?,?)",
      id,
      source,
      target,
      await fingerprint(db, source),
      await fingerprint(db, target),
      relation,
      required(rationale, "Connection reason"),
      Date.now(),
    );
    return id;
  });
}
export async function bridges() {
  return (await getDb()).getAllAsync<Bridge>(
    `SELECT b.*,s.title AS source_title,t.title AS target_title FROM bridge_proposals b JOIN ideas s ON s.id=b.source_id JOIN ideas t ON t.id=b.target_id WHERE s.deleted_at IS NULL AND t.deleted_at IS NULL ORDER BY b.created_at DESC`,
  );
}
export function reviewBridge(
  id: string,
  decision: "accepted" | "rejected" | "undo",
  feedback = "",
) {
  return writeDb(async (db) => {
    const b = await db.getFirstAsync<Bridge>(
      "SELECT * FROM bridge_proposals WHERE id=?",
      id,
    );
    if (!b) throw Error("Suggestion not found.");
    await live(db, b.source_id);
    await live(db, b.target_id);
    if (decision === "undo") {
      if (b.status !== "accepted")
        throw Error("Only accepted suggestions can be undone.");
      if (b.link_id)
        await db.runAsync("DELETE FROM idea_links WHERE id=?", b.link_id);
      await db.runAsync(
        "UPDATE bridge_proposals SET status='pending',link_id=NULL WHERE id=?",
        id,
      );
      return true;
    }
    if (b.status !== "pending")
      throw Error("This suggestion has already been reviewed.");
    if (decision === "accepted") {
      const contracts = await db.getAllAsync<Contract>(
        "SELECT * FROM thought_contracts WHERE idea_id IN (?,?)",
        b.source_id,
        b.target_id,
      );
      if (
        contracts.some(
          (c) =>
            c.intent === "private" ||
            (c.sanctuary && b.relation === "contradicts"),
        )
      )
        throw Error(
          "A thought’s intention changed. Review its permissions first.",
        );
      if (
        b.source_snapshot !== (await fingerprint(db, b.source_id)) ||
        b.target_snapshot !== (await fingerprint(db, b.target_id))
      )
        throw Error(
          "A source changed. Create a fresh suggestion before accepting.",
        );
      const link = createId("link");
      await db.runAsync(
        "INSERT INTO idea_links(id,source_idea_id,target_idea_id,link_type,note,created_at) VALUES(?,?,?,?,?,?)",
        link,
        b.source_id,
        b.target_id,
        b.relation,
        b.rationale,
        Date.now(),
      );
      await db.runAsync(
        "UPDATE bridge_proposals SET link_id=? WHERE id=?",
        link,
        id,
      );
    }
    await db.runAsync(
      "UPDATE bridge_proposals SET status=?,feedback=? WHERE id=?",
      decision,
      feedback.trim(),
      id,
    );
    return true;
  });
}
export function recordObservation(
  experimentId: string,
  observation: string,
  interpretation: string,
  alternatives: string,
  happenedAt = Date.now(),
) {
  return writeDb(async (db) => {
    const e = await db.getFirstAsync<{ idea_id: string }>(
      "SELECT idea_id FROM experiments WHERE id=?",
      experimentId,
    );
    if (!e) throw Error("Experiment not found.");
    await live(db, e.idea_id);
    if (!Number.isFinite(happenedAt) || happenedAt > Date.now())
      throw Error("Choose a valid observation time.");
    const id = createId("observation");
    await db.runAsync(
      "INSERT INTO experiment_observations(id,experiment_id,observation,interpretation,alternatives,happened_at,created_at) VALUES(?,?,?,?,?,?,?)",
      id,
      experimentId,
      required(observation, "Observation"),
      interpretation.trim(),
      alternatives.trim(),
      happenedAt,
      Date.now(),
    );
    await syncFts(db, e.idea_id);
    return id;
  });
}
export async function observations(experimentId: string) {
  return (await getDb()).getAllAsync<Observation>(
    "SELECT * FROM experiment_observations WHERE experiment_id=? ORDER BY happened_at,created_at",
    experimentId,
  );
}
export const markSeen = (ideaId: string) =>
  writeDb(async (db) => {
    await db.runAsync(
      "UPDATE ideas SET last_seen_at=? WHERE id=?",
      Date.now(),
      ideaId,
    );
  });
export async function listCaptureDrafts() {
  return (await getDb()).getAllAsync<{
    id: string;
    body_text: string;
    mode: string;
    updated_at: number;
  }>(
    "SELECT * FROM drafts WHERE (id LIKE 'capture:%' OR id='quick-capture') AND (body_text<>'' OR attachment_uri IS NOT NULL OR metadata_json LIKE '%uri%') ORDER BY updated_at DESC",
  );
}
export async function health() {
  const db = await getDb();
  return {
    ideas:
      (await db.getFirstAsync<{ n: number }>("SELECT COUNT(*) n FROM ideas"))
        ?.n ?? 0,
    revisions:
      (
        await db.getFirstAsync<{ n: number }>(
          "SELECT COUNT(*) n FROM thought_revisions",
        )
      )?.n ?? 0,
    attachments: await db.getAllAsync<{ id: string; local_uri: string }>(
      "SELECT id,local_uri FROM attachments",
    ),
    lastExport: await db.getFirstAsync<{ value: string }>(
      "SELECT value FROM app_settings WHERE key='last_export'",
    ),
    integrity: await db.getAllAsync("PRAGMA quick_check"),
    foreignKeys: await db.getAllAsync("PRAGMA foreign_key_check"),
  };
}
export const saveRecipe = (
  title: string,
  description: string,
  steps: string[],
) =>
  writeDb(async (db) => {
    if (steps.length < 2 || steps.length > 12 || steps.some((s) => !s.trim()))
      throw Error("Use between two and twelve nonempty steps.");
    const id = createId("recipe");
    await db.runAsync(
      "INSERT INTO custom_recipes(id,title,description,steps_json,created_at) VALUES(?,?,?,?,?)",
      id,
      required(title, "Recipe name", 100),
      description.trim(),
      JSON.stringify(steps),
      Date.now(),
    );
    return id;
  });
export async function customRecipes() {
  return (await getDb()).getAllAsync<{
    id: string;
    title: string;
    description: string;
    steps_json: string;
  }>("SELECT * FROM custom_recipes ORDER BY created_at DESC");
}
export async function beginDiscovery(mode = "return") {
  return writeDb(async (db) => {
    const running = await db.getFirstAsync<{ id: string }>(
      "SELECT id FROM discovery_sessions WHERE completed_at IS NULL ORDER BY created_at DESC LIMIT 1",
    );
    if (running) return running.id;
    const items = await db.getAllAsync<Idea & { reason: string }>(
      `${IDEA_SELECT} WHERE i.deleted_at IS NULL AND i.stage NOT IN ('archived','dropped','done') AND NOT EXISTS(SELECT 1 FROM thought_contracts c WHERE c.idea_id=i.id AND (c.intent='private' OR c.sanctuary=1)) AND NOT EXISTS(SELECT 1 FROM resurfacing_events r WHERE r.idea_id=i.id AND r.snoozed_until>?) ORDER BY COALESCE(i.last_seen_at,0),i.updated_at LIMIT 3`,
      Date.now(),
    );
    const id = createId("discovery");
    await db.runAsync(
      "INSERT INTO discovery_sessions(id,mode,created_at) VALUES(?,?,?)",
      id,
      mode,
      Date.now(),
    );
    for (const [position, idea] of items.entries())
      await db.runAsync(
        "INSERT INTO discovery_items(session_id,idea_id,position,reason) VALUES(?,?,?,?)",
        id,
        idea.id,
        position,
        "A thought you have not opened recently",
      );
    return id;
  });
}
export async function discovery(id: string) {
  const db = await getDb();
  return {
    session: await db.getFirstAsync<{
      id: string;
      mode: string;
      completed_at: number | null;
      takeaway: string;
    }>("SELECT * FROM discovery_sessions WHERE id=?", id),
    items: await db.getAllAsync<
      Idea & {
        position: number;
        reason: string;
        recall: string;
        revealed_at: number | null;
        action: string | null;
      }
    >(
      `SELECT i.*,d.position,d.reason,d.recall,d.revealed_at,d.action,COALESCE((SELECT body_text FROM idea_blocks WHERE idea_id=i.id AND type='text' ORDER BY position LIMIT 1),'') AS snippet FROM discovery_items d JOIN ideas i ON i.id=d.idea_id WHERE d.session_id=? AND i.deleted_at IS NULL ORDER BY d.position`,
      id,
    ),
  };
}
export const revealDiscovery = (
  session: string,
  idea: string,
  recall: string,
) =>
  writeDb(async (db) => {
    const item = await db.getFirstAsync<any>(
      "SELECT d.* FROM discovery_items d JOIN discovery_sessions s ON s.id=d.session_id WHERE d.session_id=? AND d.idea_id=? AND s.completed_at IS NULL",
      session,
      idea,
    );
    if (!item) throw Error("This discovery session has ended.");
    if (item.revealed_at) return;
    await db.runAsync(
      "UPDATE discovery_items SET recall=?,revealed_at=? WHERE session_id=? AND idea_id=?",
      recall.trim(),
      Date.now(),
      session,
      idea,
    );
    await db.runAsync(
      "UPDATE ideas SET last_seen_at=? WHERE id=?",
      Date.now(),
      idea,
    );
    await db.runAsync(
      "INSERT INTO resurfacing_events(id,idea_id,reason,shown_at,action) VALUES(?,?,?,?,?)",
      createId("return"),
      idea,
      item.reason,
      Date.now(),
      "seen",
    );
    return true;
  });
export const respondDiscovery = (
  session: string,
  idea: string,
  action: string,
) =>
  writeDb(async (db) => {
    if (!["useful", "remembered", "not_now"].includes(action))
      throw Error("Unknown return signal.");
    const item = await db.getFirstAsync<any>(
      "SELECT * FROM discovery_items WHERE session_id=? AND idea_id=? AND revealed_at IS NOT NULL",
      session,
      idea,
    );
    if (!item) throw Error("Reveal this thought first.");
    await db.runAsync(
      "UPDATE discovery_items SET action=? WHERE session_id=? AND idea_id=?",
      action,
      session,
      idea,
    );
    await db.runAsync(
      "INSERT INTO resurfacing_events(id,idea_id,reason,shown_at,action,snoozed_until) VALUES(?,?,?,?,?,?)",
      createId("return"),
      idea,
      "Your return signal",
      Date.now(),
      action,
      action === "not_now" ? Date.now() + 604800000 : null,
    );
    return true;
  });
export const finishDiscovery = (id: string, takeaway: string) =>
  writeDb(async (db) => {
    await db.runAsync(
      "UPDATE discovery_sessions SET completed_at=?,takeaway=? WHERE id=?",
      Date.now(),
      takeaway.trim(),
      id,
    );
    return true;
  });
