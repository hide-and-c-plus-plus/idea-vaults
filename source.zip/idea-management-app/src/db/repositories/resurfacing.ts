import { writeDb } from "../write";
import { getDb } from "../database";
import type { Idea } from "@/domain/types";
import { createId } from "@/utils/id";

export interface ResurfacedIdea extends Idea {
  reason: string;
  score: number;
}

export async function getResurfacedIdeas(limit = 3): Promise<ResurfacedIdea[]> {
  const db = await getDb();
  const now = Date.now();
  const day = 86_400_000;
  const rows = await db.getAllAsync<
    Idea & {
      last_shown: number | null;
      latest_snoozed: number | null;
      due_at: number | null;
    }
  >(`
    SELECT i.*, c.name AS category_name,
      (SELECT MAX(shown_at) FROM resurfacing_events r WHERE r.idea_id=i.id) AS last_shown,
      (SELECT snoozed_until FROM resurfacing_events r WHERE r.idea_id=i.id ORDER BY shown_at DESC LIMIT 1) AS latest_snoozed,
      (SELECT MIN(COALESCE(snoozed_until,scheduled_at)) FROM reminders m WHERE m.idea_id=i.id AND m.completed_at IS NULL) AS due_at,
      COALESCE((SELECT body_text FROM idea_blocks b WHERE b.idea_id=i.id AND b.type='text' ORDER BY b.position LIMIT 1),'') AS snippet
    FROM ideas i LEFT JOIN categories c ON c.id=i.primary_category_id
    WHERE i.deleted_at IS NULL AND i.stage NOT IN ('dropped','archived','done')
    AND NOT EXISTS(SELECT 1 FROM thought_contracts c WHERE c.idea_id=i.id AND (c.intent='private' OR c.sanctuary=1))
    ORDER BY i.last_touched_at ASC
  `);

  const scored = rows
    .map((idea) => {
      const ageDays = Math.max(0, (now - idea.last_touched_at) / day);
      let score = Math.min(ageDays, 45);
      let reason = `${Math.floor(ageDays)} days untouched`;
      if (idea.stage === "promising") {
        score += 45;
        reason = `Promising • ${Math.floor(ageDays)} days untouched`;
      }
      if (idea.stage === "active") {
        score += 18;
        reason = "Active idea worth reconnecting with";
      }
      if (idea.inbox_state === "unprocessed") {
        score += 8;
        reason = "Never reviewed";
      }
      if (idea.due_at && idea.due_at <= now) {
        score += 100;
        reason = "Reminder due";
      }
      if (idea.last_shown && now - idea.last_shown < 3 * day) score -= 80;
      if (idea.latest_snoozed && idea.latest_snoozed > now) score = -1000;
      return { ...idea, score, reason } as ResurfacedIdea;
    })
    .filter((x) => x.score > 5)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);

  return scored;
}

export async function snoozeResurfaced(ideaId: string, days = 7) {
  const until = Date.now() + days * 86_400_000;
  return writeDb(async (db) => {
    await db.runAsync(
      "INSERT INTO resurfacing_events(id,idea_id,reason,shown_at,action,snoozed_until) VALUES(?,?,?,?,?,?)",
      createId("resurface"),
      ideaId,
      "User requested a rest",
      Date.now(),
      "snoozed",
      until,
    );
  });
}
