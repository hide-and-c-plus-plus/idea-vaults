import type { SQLiteDatabase } from "expo-sqlite";
import { createId } from "@/utils/id";
// Internal helpers share the caller's transaction and never start nested writes.
export async function coreSnapshot(db: SQLiteDatabase, id: string) {
  const idea = await db.getFirstAsync<any>(
    "SELECT * FROM ideas WHERE id=? AND deleted_at IS NULL",
    id,
  );
  if (!idea) throw new Error("This thought is no longer available.");
  const blocks = await db.getAllAsync<any>(
    "SELECT * FROM idea_blocks WHERE idea_id=? ORDER BY position,created_at,id",
    id,
  );
  const tags = await db.getAllAsync<any>(
    "SELECT tag_id FROM idea_tags WHERE idea_id=? ORDER BY tag_id",
    id,
  );
  return JSON.stringify({ idea, blocks, tags });
}
export async function recordRevision(
  db: SQLiteDatabase,
  id: string,
  label: string,
) {
  const snapshot = await coreSnapshot(db, id);
  const parent = await db.getFirstAsync<any>(
    "SELECT id,snapshot_json FROM thought_revisions WHERE idea_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1",
    id,
  );
  if (parent?.snapshot_json === snapshot) return parent.id as string;
  const revision = createId("revision");
  await db.runAsync(
    "INSERT INTO thought_revisions(id,idea_id,parent_id,label,snapshot_json,created_at) VALUES(?,?,?,?,?,?)",
    revision,
    id,
    parent?.id ?? null,
    label,
    snapshot,
    Date.now(),
  );
  return revision;
}
export const BRIEF_FIELDS = [
  "title",
  "summary",
  "problem",
  "audience",
  "why_now",
  "next_experiment",
  "risks",
  "done_definition",
] as const;
