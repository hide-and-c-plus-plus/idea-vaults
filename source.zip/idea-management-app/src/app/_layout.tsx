import { useColors, useThemedStyles } from "@/theme/Theme";
export { ErrorBoundary } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  View,
  Pressable,
  Platform,
  AppState,
} from "react-native";
import { Stack, router } from "expo-router";
import { StatusBar } from "expo-status-bar";
import * as Notifications from "expo-notifications";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { runMigrations } from "@/db/migrations";
import { configureNotificationChannels } from "@/services/notifications";
import { DataChangeProvider } from "@/state/DataChangeContext";
import { purgeExpiredTrash } from "@/services/maintenance";
import { FeedbackProvider } from "@/state/FeedbackContext";
import { ThemeProvider, useTheme } from "@/theme/Theme";
import { colors } from "@/theme/tokens";

function useNotificationObserver(enabled: boolean) {
  useEffect(() => {
    if (!enabled || Platform.OS === "web") return;
    const redirect = (notification: Notifications.Notification) => {
      const url = notification.request.content.data?.url;
      if (typeof url === "string" && /^\/idea\/[A-Za-z0-9_-]+$/.test(url))
        router.push(url as any);
    };
    const response = Notifications.getLastNotificationResponse();
    if (response?.notification) redirect(response.notification);
    const sub = Notifications.addNotificationResponseReceivedListener((next) =>
      redirect(next.notification),
    );
    return () => sub.remove();
  }, [enabled]);
}

export default function RootLayout() {
  const styles = useThemedStyles(baseStyles);
  const colors = useColors();

  const [attempt, setAttempt] = useState(0);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  useNotificationObserver(ready);
  useEffect(() => {
    (async () => {
      try {
        await runMigrations();
        await configureNotificationChannels().catch(() => undefined);
        await purgeExpiredTrash();
        setReady(true);
      } catch (e) {
        setError(e as Error);
      }
    })();
  }, [attempt]);

  if (!ready)
    return (
      <View style={styles.loading}>
        <StatusBar style="auto" />
        {error ? (
          <>
            <Text style={styles.errorTitle}>Could not open Idea Vault</Text>
            <Text style={styles.errorBody}>{error.message}</Text>
            <Pressable
              accessibilityRole="button"
              onPress={() => {
                setError(null);
                setAttempt((v) => v + 1);
              }}
              style={{ padding: 16 }}
            >
              <Text style={{ color: colors.accent }}>Try again</Text>
            </Pressable>
          </>
        ) : (
          <ActivityIndicator color={colors.accent} />
        )}
      </View>
    );
  return (
    <ThemeProvider>
      <AppShell />
    </ThemeProvider>
  );
}
function AppShell() {
  const { colors, dark, preferences } = useTheme();
  const [covered, setCovered] = useState(false);
  useEffect(() => {
    const sub = AppState.addEventListener("change", (s) => {
      if (s !== "active" && preferences.privateScreen) setCovered(true);
    });
    return () => sub.remove();
  }, [preferences.privateScreen]);
  return (
    <SafeAreaProvider>
      <DataChangeProvider>
        <FeedbackProvider>
          <StatusBar style={dark ? "light" : "dark"} />
          <Stack
            screenOptions={{
              headerShown: false,
              contentStyle: { backgroundColor: colors.bg },
              animation: preferences.reduceMotion ? "none" : "slide_from_right",
            }}
          >
            <Stack.Screen name="(tabs)" />
            <Stack.Screen
              name="capture"
              options={{
                presentation: "modal",
                animation: preferences.reduceMotion
                  ? "none"
                  : "slide_from_bottom",
              }}
            />
            <Stack.Screen name="idea/[id]" />
            <Stack.Screen name="idea/[id]/develop" />
            <Stack.Screen name="idea/[id]/reminder" />
            <Stack.Screen name="idea/[id]/link" />
            <Stack.Screen name="settings/index" />
            <Stack.Screen name="settings/trash" />
          </Stack>
          {covered && preferences.privateScreen ? (
            <View
              accessibilityViewIsModal
              style={{
                position: "absolute",
                top: 0,
                right: 0,
                bottom: 0,
                left: 0,
                backgroundColor: colors.bg,
                justifyContent: "center",
                alignItems: "center",
                padding: 32,
                gap: 24,
              }}
            >
              <Text
                style={{
                  fontSize: 28,
                  fontWeight: "700",
                  color: colors.textPrimary,
                }}
              >
                Your thoughts are here.
              </Text>
              <Pressable
                accessibilityRole="button"
                onPress={() => setCovered(false)}
                style={{
                  padding: 20,
                  backgroundColor: colors.accent,
                  borderRadius: 16,
                }}
              >
                <Text style={{ color: colors.onAccent, fontSize: 17 }}>
                  Show my vault
                </Text>
              </Pressable>
            </View>
          ) : null}
        </FeedbackProvider>
      </DataChangeProvider>
    </SafeAreaProvider>
  );
}
const styles = StyleSheet.create({
  loading: {
    flex: 1,
    backgroundColor: colors.bg,
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    gap: 12,
  },
  errorTitle: {
    color: colors.textPrimary,
    fontSize: 18,
    fontWeight: "600",
    textAlign: "center",
  },
  errorBody: { color: colors.textSecondary, fontSize: 14, textAlign: "center" },
});

const baseStyles = styles;
