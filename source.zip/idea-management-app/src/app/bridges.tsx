import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useState } from "react";
import { View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import {
  PageHeader,
  Panel,
  Field,
  IdeaPicker,
  LoadState,
  ui,
} from "@/components/studio/StudioUI";
import { Button } from "@/components/ui/Button";
import { H2, Body, Caption, Secondary } from "@/components/ui/Typography";
import { Chip } from "@/components/ui/Chip";
import { SectionLabel, DraftStatus } from "@/components/ui/IOS";
import { useAction, useLoad, useDraftForm } from "@/hooks/useAsync";
import { listIdeas } from "@/db/repositories/ideas";
import {
  bridges,
  proposeBridge,
  reviewBridge,
} from "@/db/repositories/thinking";
export default function Bridges() {
  const ui = useThemedStyles(baseUI);
  const action = useAction(),
    [feedback, setFeedback] = useState(""),
    load = useLoad(async () => ({
      ideas: await listIdeas({ limit: 300 }),
      bridges: await bridges(),
    })),
    form = useDraftForm("bridge", {
      source: "",
      target: "",
      relation: "related_to",
      rationale: "",
    });
  return (
    <Screen>
      <PageHeader
        back
        title="Connection desk"
        subtitle="A connection becomes useful when you can explain it."
      />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {load.data ? (
        <View style={ui.stack}>
          <Panel>
            <IdeaPicker
              label="From this thought"
              ideas={load.data.ideas}
              value={form.value.source}
              onChange={(source) => form.setValue((v) => ({ ...v, source }))}
            />
            <IdeaPicker
              label="To this thought"
              ideas={load.data.ideas}
              value={form.value.target}
              exclude={form.value.source}
              onChange={(target) => form.setValue((v) => ({ ...v, target }))}
            />
            <View style={ui.wrap}>
              {[
                "related_to",
                "builds_on",
                "contradicts",
                "combines_with",
                "inspired_by",
              ].map((relation) => (
                <Chip
                  key={relation}
                  label={relation.replaceAll("_", " ")}
                  selected={form.value.relation === relation}
                  onPress={() => form.setValue((v) => ({ ...v, relation }))}
                />
              ))}
            </View>
            <Field
              label="What connects them, and why might it help?"
              multiline
              value={form.value.rationale}
              onChangeText={(rationale) =>
                form.setValue((v) => ({ ...v, rationale }))
              }
            />
            <DraftStatus status={form.status} />
            <Button
              label="Save a tentative bridge"
              disabled={
                !form.ready ||
                !form.value.source ||
                !form.value.target ||
                !form.value.rationale.trim()
              }
              loading={action.busy}
              onPress={() =>
                action.run(async () => {
                  await proposeBridge(
                    form.value.source,
                    form.value.target,
                    form.value.relation,
                    form.value.rationale,
                  );
                  await form.clear();
                  form.setValue({
                    source: "",
                    target: "",
                    relation: "related_to",
                    rationale: "",
                  });
                  form.resume();
                }, "Bridge ready to review")
              }
            />
          </Panel>
          <SectionLabel>REVIEW YOUR CONNECTIONS</SectionLabel>
          <Field
            label="Review note (optional)"
            value={feedback}
            onChangeText={setFeedback}
            placeholder="What made this useful or unhelpful?"
          />
          {load.data.bridges.map((b) => (
            <Panel key={b.id}>
              <Caption>
                {b.status} · {b.relation.replaceAll("_", " ")}
              </Caption>
              <H2>
                {b.source_title} → {b.target_title}
              </H2>
              <Body>{b.rationale}</Body>
              {b.feedback ? <Secondary>{b.feedback}</Secondary> : null}
              <View style={ui.wrap}>
                <Button
                  label="Open source"
                  variant="ghost"
                  onPress={() => router.push(`/idea/${b.source_id}` as any)}
                />
                <Button
                  label="Open target"
                  variant="ghost"
                  onPress={() => router.push(`/idea/${b.target_id}` as any)}
                />
              </View>
              {b.status === "pending" ? (
                <>
                  <Button
                    label="Accept connection"
                    loading={action.busy}
                    onPress={() =>
                      action.run(
                        () => reviewBridge(b.id, "accepted", feedback),
                        "Connection accepted",
                      )
                    }
                  />
                  <Button
                    label="Reject and remember why"
                    variant="secondary"
                    disabled={action.busy}
                    onPress={() =>
                      action.run(
                        () => reviewBridge(b.id, "rejected", feedback),
                        "Review saved",
                      )
                    }
                  />
                </>
              ) : b.status === "accepted" ? (
                <Button
                  label="Undo acceptance"
                  variant="secondary"
                  onPress={() =>
                    action.run(
                      () => reviewBridge(b.id, "undo"),
                      "Acceptance undone",
                    )
                  }
                />
              ) : null}
            </Panel>
          ))}
        </View>
      ) : null}
    </Screen>
  );
}

const baseUI = ui;
