import React from "react";
import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import {
  PageHeader,
  Panel,
  Field,
  LoadState,
} from "@/components/studio/StudioUI";
import { Button } from "@/components/ui/Button";
import { DraftStatus } from "@/components/ui/IOS";
import { useLoad, useDraftForm, useAction } from "@/hooks/useAsync";
import { getIdea, updateIdea } from "@/db/repositories/ideas";
import type { Idea } from "@/domain/types";
const prompts = [
  ["summary", "The idea in one sentence"],
  ["problem", "The problem or opportunity"],
  ["audience", "Who benefits?"],
  ["why_now", "Why might it work now?"],
  ["next_experiment", "The smallest test"],
  ["risks", "What could stop it?"],
  ["done_definition", "What does success look like?"],
  ["next_action", "The next smallest action"],
] as const;
export default function Develop() {
  const { id } = useLocalSearchParams<{ id: string }>(),
    load = useLoad(() => getIdea(id), [id]);
  return (
    <Screen>
      <PageHeader back title="Develop your thought" />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {load.data ? <Editor idea={load.data} /> : null}
    </Screen>
  );
}
function Editor({ idea }: { idea: Idea }) {
  const form = useDraftForm(
      `develop:${idea.id}`,
      Object.fromEntries(prompts.map(([k]) => [k, idea[k] ?? ""])),
    ),
    action = useAction();
  return (
    <View style={{ gap: 16 }}>
      {prompts.map(([k, label]) => (
        <Panel key={k}>
          <Field
            label={label}
            multiline
            editable={form.ready}
            value={form.value[k]}
            onChangeText={(text) => form.setValue((v) => ({ ...v, [k]: text }))}
          />
        </Panel>
      ))}
      <DraftStatus status={form.status} />
      <Button
        label="Save development"
        disabled={!form.ready}
        loading={action.busy}
        onPress={() =>
          action.run(async () => {
            await updateIdea(idea.id, form.value);
            await form.clear();
            router.back();
          }, "Brief and next action saved")
        }
      />
    </View>
  );
}
