import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useEffect, useState } from "react";
import {
  Alert,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { H1, Secondary } from "@/components/ui/Typography";
import { Chip } from "@/components/ui/Chip";
import { IdeaCard } from "@/components/idea/IdeaCard";
import { searchIdeas } from "@/db/repositories/ideas";
import { addIdeaLink } from "@/db/repositories/links";
import type { Idea, LinkType } from "@/domain/types";
import { useDataChange } from "@/state/DataChangeContext";
import { colors, radius, spacing } from "@/theme/tokens";
const types: LinkType[] = [
  "related_to",
  "builds_on",
  "contradicts",
  "duplicate_of",
  "combines_with",
  "inspired_by",
  "child_of",
  "parent_of",
];
export default function LinkIdeaScreen() {
  const styles = useThemedStyles(baseStyles);
  const colors = useColors();

  const { id } = useLocalSearchParams<{ id: string }>();
  const { bump } = useDataChange();
  const [q, setQ] = useState("");
  const [type, setType] = useState<LinkType>("related_to");
  const [items, setItems] = useState<Idea[]>([]);
  useEffect(() => {
    const t = setTimeout(
      () =>
        searchIdeas(q).then((rows) =>
          setItems(rows.filter((x) => x.id !== id).slice(0, 30)),
        ),
      120,
    );
    return () => clearTimeout(t);
  }, [q, id]);
  const link = async (target: Idea) => {
    try {
      await addIdeaLink(id, target.id, type);
      bump();
      router.back();
    } catch (e) {
      Alert.alert("Could not link ideas", String(e));
    }
  };
  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.icon}>
          <Text style={styles.glyph}>‹</Text>
        </Pressable>
        <H1>Link an idea</H1>
        <View style={styles.icon} />
      </View>
      <Secondary>Relationship</Secondary>
      <View style={styles.chips}>
        {types.map((x) => (
          <Chip
            key={x}
            label={x.replaceAll("_", " ")}
            selected={type === x}
            onPress={() => setType(x)}
          />
        ))}
      </View>
      <TextInput
        value={q}
        onChangeText={setQ}
        placeholder="Search ideas…"
        placeholderTextColor={colors.textMuted}
        style={styles.search}
      />
      <View style={{ gap: spacing.md, marginTop: spacing.md }}>
        {items.map((i) => (
          <IdeaCard key={i.id} idea={i} onPress={() => link(i)} />
        ))}
      </View>
    </Screen>
  );
}
const styles = StyleSheet.create({
  header: {
    paddingTop: spacing.sm,
    minHeight: 60,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  icon: {
    width: 48,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
  },
  glyph: { color: colors.textPrimary, fontSize: 24 },
  chips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 8 },
  search: {
    height: 52,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surfaceRaised,
    color: colors.textPrimary,
    paddingHorizontal: spacing.lg,
    fontSize: 16,
    marginTop: spacing.xl,
  },
});

const baseStyles = styles;
