import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useEffect, useState } from "react";
import { Alert, Pressable, StyleSheet, Text, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { H1, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { getIdea } from "@/db/repositories/ideas";
import { scheduleIdeaReminder } from "@/services/notifications";
import { colors, spacing } from "@/theme/tokens";
export default function ReminderScreen() {
  const styles = useThemedStyles(baseStyles);

  const { id } = useLocalSearchParams<{ id: string }>();
  const [title, setTitle] = useState("Idea");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    getIdea(id).then((i) => setTitle(i?.title || "Untitled idea"));
  }, [id]);
  const schedule = async (days: number) => {
    setBusy(true);
    try {
      const d = new Date(Date.now() + days * 86400000);
      d.setHours(9, 0, 0, 0);
      await scheduleIdeaReminder(id, title, d);
      Alert.alert("Reminder set", `You’ll be reminded ${d.toLocaleString()}.`, [
        { text: "OK", onPress: () => router.back() },
      ]);
    } catch (e) {
      Alert.alert("Could not set reminder", String(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.icon}>
          <Text style={styles.glyph}>‹</Text>
        </Pressable>
        <H1>Revisit later</H1>
        <View style={styles.icon} />
      </View>
      <Secondary>Reminders are only created when you ask for them.</Secondary>
      <View style={{ gap: spacing.md, marginTop: spacing.xl }}>
        <Button
          label="Tomorrow at 9:00"
          disabled={busy}
          onPress={() => schedule(1)}
        />
        <Button
          label="In 7 days"
          variant="secondary"
          disabled={busy}
          onPress={() => schedule(7)}
        />
        <Button
          label="In 30 days"
          variant="secondary"
          disabled={busy}
          onPress={() => schedule(30)}
        />
      </View>
    </Screen>
  );
}
const styles = StyleSheet.create({
  header: {
    paddingTop: spacing.sm,
    minHeight: 60,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  icon: {
    width: 48,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
  },
  glyph: { color: colors.textPrimary, fontSize: 24 },
});

const baseStyles = styles;
