import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useState } from "react";
import { View, Alert } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import {
  PageHeader,
  Panel,
  Field,
  IdeaPicker,
  LoadState,
  ui,
} from "@/components/studio/StudioUI";
import { Button } from "@/components/ui/Button";
import { Body, H2, Caption, Secondary } from "@/components/ui/Typography";
import { Chip } from "@/components/ui/Chip";
import { Group, Row, Segmented, SectionLabel } from "@/components/ui/IOS";
import { useAction, useLoad } from "@/hooks/useAsync";
import { listIdeas, searchIdeas } from "@/db/repositories/ideas";
import {
  inquiryDetail,
  joinInquiry,
  leaveInquiry,
  setInquiryStatus,
  deleteInquiry,
} from "@/db/repositories/thinking";
export default function Inquiry() {
  const ui = useThemedStyles(baseUI);
  const { id } = useLocalSearchParams<{ id: string }>(),
    action = useAction(),
    [idea, setIdea] = useState(""),
    [role, setRole] = useState("material");
  const load = useLoad(
    async () => ({
      ...(await inquiryDetail(id)),
      ideas: await listIdeas({ limit: 100 }),
    }),
    [id],
  );
  const room = load.data?.room;
  return (
    <Screen>
      <PageHeader back title="Question room" />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {room && load.data ? (
        <View style={ui.stack}>
          <Panel>
            <H2>{room.question}</H2>
            <Secondary>{room.context}</Secondary>
            <Segmented
              options={["open", "resting", "resolved"]}
              value={room.status}
              onChange={(v) =>
                action.run(() => setInquiryStatus(id, v), "Room updated")
              }
            />
          </Panel>
          <SectionLabel>THOUGHTS IN THIS ROOM</SectionLabel>
          <Group>
            {load.data.members.map((m, i) => (
              <Row
                key={m.id}
                title={m.title ?? "Untitled"}
                detail={m.role}
                last={i === load.data!.members.length - 1}
                onPress={() => router.push(`/idea/${m.id}` as any)}
              />
            ))}
          </Group>
          {!load.data.members.length ? (
            <Secondary>
              Add a thought, then give it a role. Different answers can coexist
              here.
            </Secondary>
          ) : null}
          <Panel>
            <IdeaPicker
              ideas={load.data.ideas}
              value={idea}
              onChange={setIdea}
            />
            <View style={ui.wrap}>
              {[
                "material",
                "question",
                "answer",
                "observation",
                "counterexample",
                "experiment",
              ].map((r) => (
                <Chip
                  key={r}
                  label={r}
                  selected={role === r}
                  onPress={() => setRole(r)}
                />
              ))}
            </View>
            <Button
              label="Add to this question"
              disabled={!idea}
              loading={action.busy}
              onPress={() =>
                action.run(() => joinInquiry(id, idea, role), "Thought added")
              }
            />
            {load.data.members.some((m) => m.id === idea) ? (
              <Button
                label="Remove selected thought from room"
                variant="ghost"
                onPress={() =>
                  action.run(() => leaveInquiry(id, idea), "Removed from room")
                }
              />
            ) : null}
          </Panel>
          <SectionLabel>EVIDENCE & OPEN QUESTIONS</SectionLabel>
          {load.data.cards.map((c) => (
            <Panel key={c.id}>
              <Caption>
                {c.kind} · {c.epistemic} · {c.status}
              </Caption>
              <Body>{c.title}</Body>
              <Secondary>{c.body}</Secondary>
              <Button
                label={`Open ${c.idea_title ?? "source thought"}`}
                variant="ghost"
                onPress={() =>
                  router.push(`/thinking?id=${c.idea_id}&tab=Evidence` as any)
                }
              />
            </Panel>
          ))}
          <Button
            label="Delete this room"
            variant="danger"
            onPress={() =>
              Alert.alert(
                "Delete room?",
                "Thoughts and evidence stay in your vault.",
                [
                  { text: "Cancel", style: "cancel" },
                  {
                    text: "Delete room",
                    style: "destructive",
                    onPress: () =>
                      action.run(async () => {
                        await deleteInquiry(id);
                        router.back();
                      }),
                  },
                ],
              )
            }
          />
        </View>
      ) : null}
    </Screen>
  );
}

const baseUI = ui;
