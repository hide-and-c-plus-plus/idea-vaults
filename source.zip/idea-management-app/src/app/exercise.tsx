import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useState } from "react";
import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import {
  PageHeader,
  Panel,
  Field,
  IdeaPicker,
  LoadState,
  ui,
} from "@/components/studio/StudioUI";
import { Button } from "@/components/ui/Button";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { DraftStatus } from "@/components/ui/IOS";
import { RECIPES, type Recipe } from "@/domain/recipes";
import { useAction, useDraftForm, useLoad } from "@/hooks/useAsync";
import { listIdeas } from "@/db/repositories/ideas";
import {
  saveWorkshop,
  customRecipes,
  getContract,
} from "@/db/repositories/thinking";
import { createBranch } from "@/db/repositories/creative";
export default function Exercise() {
  const ui = useThemedStyles(baseUI);

  const params = useLocalSearchParams<{ recipe: string; idea?: string }>(),
    action = useAction(),
    [step, setStep] = useState(0),
    [saved, setSaved] = useState(false);
  const key = `exercise:${params.recipe}:${params.idea ?? "any"}`,
    form = useDraftForm(key, {
      idea: params.idea ?? "",
      responses: {} as Record<string, string>,
      takeaway: "",
    });
  const load = useLoad(
    async () => ({
      ideas: await listIdeas({ limit: 200 }),
      custom: await customRecipes(),
      contract: form.value.idea ? await getContract(form.value.idea) : null,
    }),
    [form.value.idea],
  );
  const custom = load.data?.custom.find((x) => x.id === params.recipe);
  const recipe: Recipe | undefined =
    RECIPES.find((r) => r.id === params.recipe) ??
    (custom
      ? {
          ...custom,
          fields: JSON.parse(custom.steps_json),
          group: "Your recipes",
        }
      : undefined);
  if (!recipe)
    return (
      <Screen>
        <PageHeader back title="Exercise" />
        <LoadState
          loading={load.loading}
          error={load.error}
          onRetry={load.reload}
        />
        <Secondary>
          {load.loading
            ? "Loading your recipe…"
            : "This exercise is unavailable."}
        </Secondary>
      </Screen>
    );
  const blocked = load.data?.contract?.sanctuary && recipe.challenge;
  const finish = () =>
    action.run(async () => {
      const fields = Object.fromEntries(
        recipe.fields.map((q, i) => [q, form.value.responses[String(i)] ?? ""]),
      );
      await saveWorkshop(
        form.value.idea,
        recipe.id,
        recipe.title,
        fields,
        form.value.takeaway,
        key,
      );
      await form.clear();
      setSaved(true);
    }, "Exercise saved with your thought");
  return (
    <Screen>
      <PageHeader back title={recipe.title} subtitle={recipe.group} />
      {saved ? (
        <Panel>
          <H2>You made something worth keeping.</H2>
          <Body>
            {form.value.takeaway ||
              "Your responses are saved in this thought’s history."}
          </Body>
          <Button
            label="Return to your thought"
            onPress={() => router.replace(`/idea/${form.value.idea}` as any)}
          />
          <Button
            label="Make a new branch from these responses"
            variant="secondary"
            loading={action.busy}
            onPress={() =>
              action.run(async () => {
                const id = await createBranch({
                  title: `${recipe.title}: ${form.value.takeaway.slice(0, 70) || "another possibility"}`,
                  body: recipe.fields
                    .map(
                      (q, i) =>
                        `${q}\n${form.value.responses[String(i)] ?? ""}`,
                    )
                    .join("\n\n"),
                  parents: [form.value.idea],
                  source: "thinking_exercise",
                });
                router.replace(`/idea/${id}` as any);
              })
            }
          />
        </Panel>
      ) : (
        <View style={ui.stack}>
          {load.data ? (
            <IdeaPicker
              ideas={load.data.ideas}
              value={form.value.idea}
              onChange={(idea) => form.setValue((v) => ({ ...v, idea }))}
              label="Think with this idea"
            />
          ) : null}
          {blocked ? (
            <Panel>
              <H2>This thought is in sanctuary</H2>
              <Secondary>
                Choose an exploratory exercise, or change its intention before
                inviting critique.
              </Secondary>
              <Button
                label="Explore gently"
                onPress={() =>
                  router.replace(`/workshop?idea=${form.value.idea}` as any)
                }
              />
            </Panel>
          ) : (
            <Panel>
              <Caption>
                STEP {step + 1} OF {recipe.fields.length}
              </Caption>
              <H2>{recipe.fields[step]}</H2>
              <Field
                label="Your response"
                multiline
                editable={form.ready}
                value={form.value.responses[String(step)] ?? ""}
                onChangeText={(text) =>
                  form.setValue((v) => ({
                    ...v,
                    responses: { ...v.responses, [String(step)]: text },
                  }))
                }
                placeholder="Unfinished is welcome."
              />
              <DraftStatus status={form.status} />
              {form.status.includes("not saved") ? (
                <Button
                  label="Retry draft save"
                  onPress={() => action.run(form.flush)}
                />
              ) : null}
              <View style={ui.row}>
                <Button
                  label="Previous"
                  variant="secondary"
                  disabled={step === 0}
                  style={{ flex: 1 }}
                  onPress={() => setStep((s) => s - 1)}
                />
                <Button
                  label={
                    step === recipe.fields.length - 1
                      ? "Review below"
                      : "Next question"
                  }
                  disabled={step === recipe.fields.length - 1}
                  style={{ flex: 1 }}
                  onPress={() => setStep((s) => s + 1)}
                />
              </View>
            </Panel>
          )}
          {step === recipe.fields.length - 1 && !blocked ? (
            <Panel>
              <Field
                label="What changed in your thinking?"
                multiline
                value={form.value.takeaway}
                onChangeText={(takeaway) =>
                  form.setValue((v) => ({ ...v, takeaway }))
                }
              />
              <Button
                label="Save this thinking session"
                disabled={
                  !form.ready ||
                  !form.value.idea ||
                  !Object.values(form.value.responses).some((s) => s.trim())
                }
                loading={action.busy}
                onPress={finish}
              />
              <Caption>
                Sources remain unchanged. You can read every response in the
                thought’s notebook.
              </Caption>
            </Panel>
          ) : null}
        </View>
      )}
    </Screen>
  );
}

const baseUI = ui;
