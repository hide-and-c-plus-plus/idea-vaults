import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useState } from "react";
import { View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import {
  EmptyState,
  Field,
  IdeaPicker,
  LoadState,
  PageHeader,
  Panel,
  ui,
} from "@/components/studio/StudioUI";
import { listIdeas } from "@/db/repositories/ideas";
import {
  createExperiment,
  listExperiments,
  updateExperiment,
} from "@/db/repositories/creative";
import type { Experiment, ExperimentVerdict } from "@/domain/creative";
import { useAction, useDraftForm, useLoad } from "@/hooks/useAsync";
import { observations, recordObservation } from "@/db/repositories/thinking";
import { colors } from "@/theme/tokens";
function ExperimentCard({
  item,
}: {
  item: Experiment & { idea_title: string };
}) {
  const ui = useThemedStyles(baseUI);
  const colors = useColors();

  const [editing, setEditing] = useState(false);
  const resultForm = useDraftForm(`experiment-result:${item.id}`, {
    result: item.result,
    verdict: item.verdict,
  });
  const result = resultForm.value.result,
    verdict = resultForm.value.verdict;
  const setResult = (result: string) =>
    resultForm.setValue((v) => ({ ...v, result }));
  const setVerdict = (verdict: ExperimentVerdict) =>
    resultForm.setValue((v) => ({ ...v, verdict }));
  const stream = useLoad(() => observations(item.id), [item.id]);
  const observationForm = useDraftForm(`observation:${item.id}`, {
    observation: "",
    interpretation: "",
    alternatives: "",
  });
  const action = useAction();
  return (
    <Panel
      accent={item.verdict === "supported" ? colors.success + "60" : undefined}
    >
      <Caption>
        {item.idea_title} · {item.verdict.toUpperCase()}
      </Caption>
      <H2>{item.hypothesis}</H2>
      <Caption>THE TEST</Caption>
      <Body>{item.method}</Body>
      <Caption>AGREED SUCCESS SIGNAL</Caption>
      <Body>{item.success_signal}</Body>
      {editing ? (
        <>
          <Field
            label="What actually happened?"
            multiline
            value={result}
            onChangeText={setResult}
            placeholder="Record observations before interpreting them."
          />
          <View style={ui.wrap}>
            {(
              [
                "untested",
                "running",
                "supported",
                "challenged",
                "inconclusive",
              ] as const
            ).map((v) => (
              <Chip
                key={v}
                label={v}
                selected={v === verdict}
                onPress={() => setVerdict(v)}
              />
            ))}
          </View>
          <Button
            label="Keep this evidence"
            loading={action.busy}
            onPress={() =>
              action.run(async () => {
                await updateExperiment(item.id, result, verdict);
                await resultForm.clear();
                resultForm.resume();
                setEditing(false);
              }, "Evidence saved")
            }
          />
          <Button
            label="Cancel"
            variant="ghost"
            onPress={() => setEditing(false)}
          />
        </>
      ) : (
        <>
          {item.result ? (
            <>
              <Caption>OBSERVATIONS</Caption>
              <Body>{item.result}</Body>
            </>
          ) : null}
          <Button
            label={
              item.result ? "Update observations" : "Record an observation"
            }
            variant="secondary"
            onPress={() => {
              resultForm.resume();
              setEditing(true);
            }}
          />
        </>
      )}
      <Caption>OBSERVATION STREAM</Caption>
      {stream.data?.map((o) => (
        <View key={o.id} style={{ gap: 6 }}>
          <Caption>{new Date(o.happened_at).toLocaleString()}</Caption>
          <Body>{o.observation}</Body>
          <Secondary>
            Interpretation: {o.interpretation || "Not yet recorded"}
          </Secondary>
          {o.alternatives ? (
            <Secondary>Other explanations: {o.alternatives}</Secondary>
          ) : null}
        </View>
      ))}
      <Field
        label="Add a new observation"
        multiline
        value={observationForm.value.observation}
        onChangeText={(observation) =>
          observationForm.setValue((v) => ({ ...v, observation }))
        }
      />
      <Field
        label="Your interpretation"
        multiline
        value={observationForm.value.interpretation}
        onChangeText={(interpretation) =>
          observationForm.setValue((v) => ({ ...v, interpretation }))
        }
      />
      <Field
        label="Alternative explanations"
        multiline
        value={observationForm.value.alternatives}
        onChangeText={(alternatives) =>
          observationForm.setValue((v) => ({ ...v, alternatives }))
        }
      />
      <Caption>{observationForm.status}</Caption>
      <Button
        label="Append observation"
        variant="secondary"
        disabled={
          !observationForm.ready || !observationForm.value.observation.trim()
        }
        loading={action.busy}
        onPress={() =>
          action.run(async () => {
            await recordObservation(
              item.id,
              observationForm.value.observation,
              observationForm.value.interpretation,
              observationForm.value.alternatives,
            );
            await observationForm.clear();
            observationForm.setValue({
              observation: "",
              interpretation: "",
              alternatives: "",
            });
            observationForm.resume();
          }, "Observation added")
        }
      />
    </Panel>
  );
}
export default function ExperimentsScreen() {
  const ui = useThemedStyles(baseUI);

  const params = useLocalSearchParams<{ idea?: string }>(),
    action = useAction();
  const [creating, setCreating] = useState(!!params.idea);
  const form = useDraftForm(`experiment:${params.idea ?? "any"}`, {
    idea: params.idea ?? "",
    hypothesis: "",
    method: "",
    signal: "",
  });
  const load = useLoad(async () => {
    const [ideas, experiments] = await Promise.all([
      listIdeas({ limit: 500 }),
      listExperiments(params.idea),
    ]);
    return { ideas, experiments };
  }, [params.idea]);
  return (
    <Screen>
      <PageHeader
        back
        eyebrow="TURN CERTAINTY INTO CURIOSITY"
        title="Experiment bench"
        subtitle="A useful result can challenge an idea as much as support it."
      />
      <Button
        label={creating ? "Close the new experiment" : "+ Design a tiny test"}
        variant="secondary"
        onPress={() => {
          form.resume();
          setCreating(!creating);
        }}
      />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {creating && form.ready ? (
        <View style={ui.section}>
          <Panel>
            <IdeaPicker
              ideas={load.data?.ideas ?? []}
              value={form.value.idea}
              onChange={(idea) => form.setValue((v) => ({ ...v, idea }))}
            />
            <Field
              label="I believe that…"
              multiline
              value={form.value.hypothesis}
              onChangeText={(hypothesis) =>
                form.setValue((v) => ({ ...v, hypothesis }))
              }
              placeholder="Make a specific prediction."
            />
            <Field
              label="The smallest way to test it"
              multiline
              value={form.value.method}
              onChangeText={(method) =>
                form.setValue((v) => ({ ...v, method }))
              }
              placeholder="A paper prototype? A conversation? A single working screen?"
            />
            <Field
              label="Before testing, success would look like…"
              multiline
              value={form.value.signal}
              onChangeText={(signal) =>
                form.setValue((v) => ({ ...v, signal }))
              }
              placeholder="What observable result would support your prediction?"
            />
            <Button
              label="Put this on the bench"
              loading={action.busy}
              disabled={!form.value.idea}
              onPress={() =>
                action.run(async () => {
                  await createExperiment({
                    ideaId: form.value.idea,
                    hypothesis: form.value.hypothesis,
                    method: form.value.method,
                    signal: form.value.signal,
                  });
                  await form.clear();
                  form.setValue((v) => ({
                    ...v,
                    hypothesis: "",
                    method: "",
                    signal: "",
                  }));
                  setCreating(false);
                }, "Experiment saved")
              }
            />
            <Secondary>
              Outcome labels are your assessment of the recorded evidence. One
              small experiment does not prove a universal claim.
            </Secondary>
          </Panel>
        </View>
      ) : null}
      <View style={ui.section}>
        {load.data?.experiments.length === 0 ? (
          <EmptyState
            glyph="⚗"
            title="An empty bench is an invitation"
            body="Pick the assumption you are least sure about. Design a small, reversible way to learn."
          />
        ) : null}
        {load.data?.experiments.map((e) => (
          <ExperimentCard key={e.id} item={e} />
        ))}
      </View>
    </Screen>
  );
}

const baseUI = ui;
