import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useState } from "react";
import { View, Alert, Linking } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import {
  PageHeader,
  Panel,
  Field,
  LoadState,
  ui,
} from "@/components/studio/StudioUI";
import { Button } from "@/components/ui/Button";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Chip } from "@/components/ui/Chip";
import {
  Segmented,
  ToggleRow,
  DraftStatus,
  Group,
  Row,
  SectionLabel,
} from "@/components/ui/IOS";
import { useAction, useDraftForm, useLoad } from "@/hooks/useAsync";
import { getIdea } from "@/db/repositories/ideas";
import {
  cards,
  checkpoints,
  getContract,
  revisions,
  workshopHistory,
  saveCheckpoint,
  saveContract,
  snapshotIdea,
  restoreBrief,
  setCardStatus,
  removeCard,
} from "@/db/repositories/thinking";
import { CARD_KINDS, type Contract, type Revision } from "@/domain/thinking";
import { BRIEF_FIELDS } from "@/db/repositories/revisions";
import { formatDateTime } from "@/utils/date";
export default function Thinking() {
  const ui = useThemedStyles(baseUI);

  const { id, tab } = useLocalSearchParams<{ id: string; tab?: string }>(),
    [section, setSection] = useState(tab ?? "Resume"),
    action = useAction(),
    [versionName, setVersionName] = useState(""),
    [selected, setSelected] = useState<Revision | null>(null);
  const form = useDraftForm(`checkpoint:${id}`, {
    changed: "",
    question: "",
    restart: "",
  });
  const load = useLoad(
    async () => ({
      idea: await getIdea(id),
      cards: await cards(id),
      checkpoints: await checkpoints(id),
      contract: await getContract(id),
      revisions: await revisions(id),
      entries: await workshopHistory(id),
    }),
    [id],
  );
  const idea = load.data?.idea;
  return (
    <Screen>
      <PageHeader
        back
        title="Thinking space"
        subtitle={idea?.title ?? "A place to develop your thought"}
      />
      <Segmented
        options={["Resume", "Evidence", "History", "Intention"]}
        value={section}
        onChange={setSection}
      />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {idea && load.data ? (
        <View style={[ui.stack, { marginTop: 20 }]}>
          {section === "Resume" ? (
            <>
              <Panel>
                <H2>Leave yourself a thread.</H2>
                <Field
                  label="What changed?"
                  multiline
                  value={form.value.changed}
                  onChangeText={(changed) =>
                    form.setValue((v) => ({ ...v, changed }))
                  }
                />
                <Field
                  label="What is still open?"
                  value={form.value.question}
                  onChangeText={(question) =>
                    form.setValue((v) => ({ ...v, question }))
                  }
                />
                <Field
                  label="Start here next time"
                  multiline
                  value={form.value.restart}
                  onChangeText={(restart) =>
                    form.setValue((v) => ({ ...v, restart }))
                  }
                />
                <DraftStatus status={form.status} />
                <Button
                  label="Save a checkpoint"
                  disabled={!form.ready || !form.value.restart.trim()}
                  loading={action.busy}
                  onPress={() =>
                    action.run(async () => {
                      await saveCheckpoint(
                        id,
                        form.value.changed,
                        form.value.question,
                        form.value.restart,
                      );
                      await form.clear();
                      form.setValue({ changed: "", question: "", restart: "" });
                      form.resume();
                    }, "A thread saved for next time")
                  }
                />
              </Panel>
              {load.data.checkpoints.map((c) => (
                <Panel key={c.id}>
                  <Caption>{formatDateTime(c.created_at)}</Caption>
                  <H2>{c.restart}</H2>
                  {c.changed ? <Body>{c.changed}</Body> : null}
                  {c.open_question ? (
                    <Secondary>Still open: {c.open_question}</Secondary>
                  ) : null}
                </Panel>
              ))}
            </>
          ) : null}
          {section === "Evidence" ? (
            <>
              <Panel>
                <H2>Anatomy of a thought</H2>
                <Secondary>
                  Keep what you saw, what you inferred, and what you still need
                  to know distinct.
                </Secondary>
                <Button
                  label="Add a card"
                  onPress={() => router.push(`/card?idea=${id}` as any)}
                />
                <Button
                  label="Open a thinking exercise"
                  variant="secondary"
                  onPress={() => router.push(`/workshop?idea=${id}` as any)}
                />
              </Panel>
              {load.data.cards.map((c) => (
                <Panel key={c.id}>
                  <Caption>
                    {CARD_KINDS[c.kind]} · {c.epistemic} · {c.status}
                  </Caption>
                  <H2>{c.title}</H2>
                  {c.body ? <Body>{c.body}</Body> : null}
                  {c.interpretation ? (
                    <Secondary>
                      Interpretation / limits: {c.interpretation}
                    </Secondary>
                  ) : null}
                  {c.source_quote ? <Body>“{c.source_quote}”</Body> : null}
                  {c.related_card_id ? (
                    <Secondary>
                      {c.relation || "Linked to"}:{" "}
                      {load.data!.cards.find((x) => x.id === c.related_card_id)
                        ?.title ?? "a card in the vault"}
                    </Secondary>
                  ) : null}
                  {c.source_url ? (
                    <Button
                      label="Open source"
                      variant="ghost"
                      onPress={() =>
                        action.run(async () => {
                          if (!/^https?:\/\//i.test(c.source_url))
                            throw Error("Unsupported source address");
                          await Linking.openURL(c.source_url);
                        })
                      }
                    />
                  ) : null}
                  <View style={ui.wrap}>
                    <Chip
                      label="Edit"
                      onPress={() =>
                        router.push(`/card?idea=${id}&id=${c.id}` as any)
                      }
                    />
                    <Chip
                      label={c.status === "resolved" ? "Reopen" : "Resolve"}
                      onPress={() =>
                        action.run(
                          () =>
                            setCardStatus(
                              c.id,
                              c.status === "resolved" ? "open" : "resolved",
                            ),
                          "Card updated",
                        )
                      }
                    />
                    <Chip
                      label="Remove"
                      onPress={() =>
                        Alert.alert(
                          "Remove card?",
                          "This removes the card and its evidence link. The source thought stays.",
                          [
                            { text: "Cancel", style: "cancel" },
                            {
                              text: "Remove",
                              style: "destructive",
                              onPress: () =>
                                action.run(
                                  () => removeCard(c.id),
                                  "Card removed",
                                ),
                            },
                          ],
                        )
                      }
                    />
                  </View>
                </Panel>
              ))}
            </>
          ) : null}
          {section === "History" ? (
            <>
              <Panel>
                <Field
                  label="Name this version"
                  value={versionName}
                  onChangeText={setVersionName}
                  placeholder="Before simplifying the idea"
                />
                <Button
                  label="Keep a snapshot"
                  disabled={!versionName.trim()}
                  loading={action.busy}
                  onPress={() =>
                    action.run(async () => {
                      await snapshotIdea(id, versionName);
                      setVersionName("");
                    }, "Version saved")
                  }
                />
                <Caption>
                  Snapshots preserve the core brief, blocks, and tag IDs.
                  Restore changes the brief fields only; later captures stay
                  intact.
                </Caption>
              </Panel>
              <Group>
                {load.data.revisions.map((r, i) => (
                  <Row
                    key={r.id}
                    title={r.label}
                    detail={formatDateTime(r.created_at)}
                    last={i === load.data!.revisions.length - 1}
                    onPress={() => setSelected(r)}
                  />
                ))}
              </Group>
              {selected ? (
                <Panel>
                  <H2>Compare: {selected.label}</H2>
                  {BRIEF_FIELDS.filter(
                    (f) =>
                      JSON.parse(selected.snapshot_json).idea[f] !== idea[f],
                  ).map((f) => (
                    <View key={f} style={{ gap: 6 }}>
                      <Caption>{f.replaceAll("_", " ")}</Caption>
                      <Secondary>
                        Then:{" "}
                        {JSON.parse(selected.snapshot_json).idea[f] || "Empty"}
                      </Secondary>
                      <Body>Now: {idea[f] || "Empty"}</Body>
                    </View>
                  ))}
                  <Caption>Original text at this snapshot</Caption>
                  {JSON.parse(selected.snapshot_json)
                    .blocks.filter((b: any) => b.body_text)
                    .map((b: any) => (
                      <Body key={b.id}>{b.body_text}</Body>
                    ))}
                  <Button
                    label="Restore these brief fields"
                    variant="secondary"
                    onPress={() =>
                      action.run(
                        () => restoreBrief(selected.id),
                        "Brief restored; current captures retained",
                      )
                    }
                  />
                  <Button
                    label="Close comparison"
                    variant="ghost"
                    onPress={() => setSelected(null)}
                  />
                </Panel>
              ) : null}
              <SectionLabel>THINKING NOTEBOOK</SectionLabel>
              {load.data.entries.map((e) => (
                <Panel key={e.id}>
                  <H2>{e.title}</H2>
                  <Caption>{formatDateTime(e.created_at)}</Caption>
                  {Object.entries(
                    JSON.parse(e.fields_json) as Record<string, string>,
                  )
                    .filter(([, v]) => v.trim())
                    .map(([k, v]) => (
                      <View key={k} style={{ gap: 6 }}>
                        <Secondary>{k}</Secondary>
                        <Body>{v}</Body>
                      </View>
                    ))}
                  {e.takeaway ? (
                    <Body style={{ fontWeight: "600" }}>
                      What changed: {e.takeaway}
                    </Body>
                  ) : null}
                </Panel>
              ))}
            </>
          ) : null}
          {section === "Intention" ? (
            <ContractEditor id={id} contract={load.data.contract} />
          ) : null}
        </View>
      ) : !load.loading ? (
        <Secondary>This thought is unavailable.</Secondary>
      ) : null}
    </Screen>
  );
}
function ContractEditor({
  id,
  contract,
}: {
  id: string;
  contract: Contract | null;
}) {
  const ui = useThemedStyles(baseUI);

  const action = useAction(),
    form = useDraftForm(`contract:${id}`, {
      intent: contract?.intent ?? "explore",
      mode: contract?.mode ?? "explore",
      sanctuary: contract?.sanctuary ?? 0,
      protected_phrase: contract?.protected_phrase ?? "",
      revisit_when: contract?.revisit_when ?? "",
      context: contract?.context ?? "",
    });
  return (
    <View style={ui.stack}>
      <Panel>
        <H2>What kind of help does this want?</H2>
        <View style={ui.wrap}>
          {["remember", "explore", "test", "express", "share", "private"].map(
            (intent) => (
              <Chip
                key={intent}
                label={intent}
                selected={form.value.intent === intent}
                onPress={() => form.setValue((v) => ({ ...v, intent }))}
              />
            ),
          )}
        </View>
        <Secondary>
          Private thoughts stay out of discovery and connection suggestions.
          This is a preference, not encryption.
        </Secondary>
        <Segmented
          options={["explore", "commit"]}
          value={form.value.mode}
          onChange={(mode) => form.setValue((v) => ({ ...v, mode }))}
        />
        <ToggleRow
          title="Fragile thought sanctuary"
          detail="Pause critique and discovery while this idea finds its shape."
          value={!!form.value.sanctuary}
          onChange={(v) =>
            form.setValue((x) => ({ ...x, sanctuary: v ? 1 : 0 }))
          }
        />
        <Field
          label="A phrase to protect"
          value={form.value.protected_phrase}
          onChangeText={(protected_phrase) =>
            form.setValue((v) => ({ ...v, protected_phrase }))
          }
        />
        <Field
          label="Remember this when…"
          multiline
          value={form.value.revisit_when}
          onChangeText={(revisit_when) =>
            form.setValue((v) => ({ ...v, revisit_when }))
          }
        />
        <Field
          label="Where did this thought come from?"
          multiline
          value={form.value.context}
          onChangeText={(context) => form.setValue((v) => ({ ...v, context }))}
        />
        <DraftStatus status={form.status} />
        <Button
          label="Save intention"
          disabled={!form.ready}
          loading={action.busy}
          onPress={() =>
            action.run(async () => {
              await saveContract(id, form.value);
              await form.clear();
              form.resume();
            }, "Intention saved")
          }
        />
      </Panel>
    </View>
  );
}

const baseUI = ui;
