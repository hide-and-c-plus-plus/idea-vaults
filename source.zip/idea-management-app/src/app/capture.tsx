import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useEffect, useRef, useState } from "react";
import {
  Alert,
  AppState,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  AudioModule,
  RecordingPresets,
  setAudioModeAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from "expo-audio";
import * as Haptics from "expo-haptics";
import { useIncomingShare } from "expo-sharing";
import {
  createIdeaFromCapture,
  getDraft,
  saveDraft,
} from "@/db/repositories/ideas";
import {
  captureImageAttachment,
  importFileAttachment,
  importImageAttachment,
  persistSharedAttachment,
} from "@/services/attachments";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/IOS";
import { Caption, H1, Secondary } from "@/components/ui/Typography";
import { useDataChange } from "@/state/DataChangeContext";
import { TEMPLATES } from "@/domain/prompts";
import { createId } from "@/utils/id";
import { colors, radius, spacing } from "@/theme/tokens";

type AttachmentKind = "image" | "file" | null;

const useSharePayloads =
  Platform.OS === "web"
    ? () => ({
        sharedPayloads: [],
        resolvedSharedPayloads: [],
        isResolving: false,
        clearSharedPayloads: () => {},
      })
    : useIncomingShare;

export default function CaptureScreen() {
  const styles = useThemedStyles(baseStyles);
  const colors = useColors();

  const params = useLocalSearchParams<{
    draft?: string;
    mode?: string;
    shared?: string;
    seed?: string;
    template?: string;
  }>();
  const DRAFT_ID = useRef(
    params.draft || createId("capture").replace("capture_", "capture:"),
  ).current;
  const { bump } = useDataChange();
  const {
    sharedPayloads,
    resolvedSharedPayloads,
    isResolving,
    clearSharedPayloads,
  } = useSharePayloads();
  const sharedProcessed = useRef(false);
  const savingRef = useRef(false);
  const savedExit = useRef(false);
  const draftTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [draftError, setDraftError] = useState(false);
  const [text, setText] = useState("");
  const [audioUri, setAudioUri] = useState<string | null>(null);
  const [attachment, setAttachment] = useState<{
    uri: string;
    mimeType: string | null;
    kind: AttachmentKind;
    name?: string;
  } | null>(null);
  const [extraAttachments, setExtraAttachments] = useState<
    {
      uri: string;
      mimeType: string | null;
      kind: "image" | "file";
      name?: string;
    }[]
  >([]);
  const [context, setContext] = useState("");
  const [marks, setMarks] = useState<{ offsetMs: number; label: string }[]>([]);
  const [saving, setSaving] = useState(false);
  const [restored, setRestored] = useState(false);
  const inputRef = useRef<TextInput>(null);
  const recorder = useAudioRecorder({
    ...RecordingPresets.HIGH_QUALITY,
    directory: "document",
  });
  const recorderState = useAudioRecorderState(recorder, 250);
  const draftSnapshot = useRef({
    text,
    audioUri,
    attachment,
    restored,
    extraAttachments,
    context,
    marks,
  });
  draftSnapshot.current = {
    text,
    audioUri: audioUri ?? (recorderState.isRecording ? recorder.uri : null),
    attachment,
    restored,
    extraAttachments,
    context,
    marks,
  };
  useEffect(() => {
    const sub = AppState.addEventListener("change", (state) => {
      if (state === "active" || savedExit.current || savingRef.current) return;
      const c = draftSnapshot.current;
      if (!c.restored) return;
      void saveDraft(
        DRAFT_ID,
        c.text,
        c.audioUri ? "audio" : (c.attachment?.kind ?? "text"),
        c.audioUri ?? c.attachment?.uri ?? null,
        JSON.stringify({
          audioUri: c.audioUri,
          attachment: c.attachment,
          extraAttachments: c.extraAttachments,
          context: c.context,
          marks: c.marks,
        }),
      ).catch(() => setDraftError(true));
    });
    return () => sub.remove();
  }, [DRAFT_ID]);
  useEffect(
    () => () => {
      const current = draftSnapshot.current;
      if (!savedExit.current && current.restored && !savingRef.current) {
        if (draftTimer.current) clearTimeout(draftTimer.current);
        void saveDraft(
          DRAFT_ID,
          current.text,
          current.audioUri ? "audio" : (current.attachment?.kind ?? "text"),
          current.audioUri ?? current.attachment?.uri ?? null,
          JSON.stringify({
            audioUri: current.audioUri,
            attachment: current.attachment,
            extraAttachments: current.extraAttachments,
            context: current.context,
            marks: current.marks,
          }),
        ).catch(() => {});
      }
    },
    [],
  );

  useEffect(() => {
    (async () => {
      let readFailed = false;
      const draft = await getDraft(DRAFT_ID).catch(() => {
        readFailed = true;
        setDraftError(true);
        return null;
      });
      if (readFailed) return;
      if (draft) {
        setText(draft.body_text);
        let metadata: any = null;
        try {
          metadata = draft.metadata_json
            ? JSON.parse(draft.metadata_json)
            : null;
        } catch {}
        if (metadata) {
          setAudioUri(metadata.audioUri ?? null);
          setAttachment(metadata.attachment ?? null);
          setExtraAttachments(metadata.extraAttachments ?? []);
          setContext(metadata.context ?? "");
          setMarks(metadata.marks ?? []);
        } else if (draft.attachment_uri) {
          if (draft.mode === "audio") setAudioUri(draft.attachment_uri);
          else
            setAttachment({
              uri: draft.attachment_uri,
              mimeType: null,
              kind: draft.mode === "image" ? "image" : "file",
            });
        }
      }
      const seed =
        params.seed ?? TEMPLATES.find((t) => t.id === params.template)?.body;
      if (seed)
        setText((current) =>
          current.trim()
            ? `${current}\n\n--- New starting point ---\n${seed}`
            : seed,
        );
      setRestored(true);
      setTimeout(() => inputRef.current?.focus(), 120);
      if (params.mode === "audio") setTimeout(() => startRecording(), 250);
    })();
  }, []);

  useEffect(() => {
    if (
      !restored ||
      params.shared !== "1" ||
      isResolving ||
      sharedProcessed.current ||
      (!sharedPayloads.length && !resolvedSharedPayloads.length)
    )
      return;
    sharedProcessed.current = true;
    (async () => {
      try {
        const sharedText = sharedPayloads
          .filter((p) => p.shareType === "text" || p.shareType === "url")
          .map((p) => p.value || "")
          .filter(Boolean)
          .join("\n");
        if (sharedText)
          setText((current) =>
            current.trim() ? `${current}\n\n${sharedText}` : sharedText,
          );
        const media = resolvedSharedPayloads.find(
          (p) =>
            p.contentUri &&
            (p.contentType === "image" ||
              p.contentType === "file" ||
              p.contentType === "audio"),
        );
        if (media?.contentUri) {
          const saved = await persistSharedAttachment(
            media.contentUri,
            media.originalName,
            media.contentType === "image"
              ? "jpg"
              : media.contentType === "audio"
                ? "m4a"
                : "bin",
          );
          if (media.contentType === "audio") setAudioUri(saved);
          else
            setAttachment({
              uri: saved,
              mimeType: media.contentMimeType ?? null,
              kind: media.contentType === "image" ? "image" : "file",
              name: media.originalName ?? undefined,
            });
        }
        clearSharedPayloads();
      } catch (e) {
        Alert.alert("Could not import shared content", String(e));
      }
    })();
  }, [
    restored,
    params.shared,
    isResolving,
    sharedPayloads,
    resolvedSharedPayloads,
    clearSharedPayloads,
  ]);

  useEffect(() => {
    if (!restored || savingRef.current) return;
    const id = setTimeout(() => {
      if (!savingRef.current)
        saveDraft(
          DRAFT_ID,
          text,
          audioUri ? "audio" : (attachment?.kind ?? "text"),
          audioUri ?? attachment?.uri ?? null,
          JSON.stringify({
            audioUri,
            attachment,
            extraAttachments,
            context,
            marks,
          }),
        )
          .then(() => setDraftError(false))
          .catch(() => setDraftError(true));
    }, 350);
    draftTimer.current = id;
    return () => clearTimeout(id);
  }, [text, audioUri, attachment, restored, extraAttachments, context, marks]);

  const startRecording = async () => {
    try {
      const permission = await AudioModule.requestRecordingPermissionsAsync();
      if (!permission.granted) {
        Alert.alert(
          "Microphone permission",
          "Voice capture needs microphone permission. Text capture remains available.",
        );
        return;
      }
      await setAudioModeAsync({
        playsInSilentMode: true,
        allowsRecording: true,
        allowsBackgroundRecording: true,
      });
      if (audioUri) throw Error("Save this recording before starting another.");
      setMarks([]);
      await recorder.prepareToRecordAsync({
        ...RecordingPresets.HIGH_QUALITY,
        directory: "document",
      });
      recorder.record();
    } catch (e) {
      Alert.alert("Could not start recording", String(e));
    }
  };
  const stopRecording = async () => {
    try {
      await recorder.stop();
      const uri = recorder.uri;
      if (uri) {
        setAudioUri(uri);
        await saveDraft(
          DRAFT_ID,
          text,
          "audio",
          uri,
          JSON.stringify({
            audioUri: uri,
            attachment,
            extraAttachments,
            context,
            marks,
          }),
        );
      }
    } catch (e) {
      Alert.alert("Could not stop recording", String(e));
    }
  };

  const chooseImage = async () => {
    try {
      const result = await importImageAttachment();
      if (result) {
        if (attachment?.kind)
          setExtraAttachments((v) => [
            ...v,
            { ...attachment, kind: attachment.kind! },
          ]);
        setAttachment({ ...result, kind: "image" });
      }
    } catch (e) {
      Alert.alert("Could not attach image", String(e));
    }
  };
  const takePhoto = async () => {
    try {
      const result = await captureImageAttachment();
      if (result) {
        if (attachment?.kind)
          setExtraAttachments((v) => [
            ...v,
            { ...attachment, kind: attachment.kind! },
          ]);
        setAttachment({ ...result, kind: "image" });
      }
    } catch (e) {
      Alert.alert("Could not use camera", String(e));
    }
  };
  const chooseFile = async () => {
    try {
      const result = await importFileAttachment();
      if (result) {
        if (attachment?.kind)
          setExtraAttachments((v) => [
            ...v,
            { ...attachment, kind: attachment.kind! },
          ]);
        setAttachment({ ...result, kind: "file" });
      }
    } catch (e) {
      Alert.alert("Could not attach file", String(e));
    }
  };

  const save = async (again = false) => {
    if (savingRef.current) return;
    if (
      !text.trim() &&
      !audioUri &&
      !attachment &&
      !extraAttachments.length &&
      !recorderState.isRecording
    ) {
      Alert.alert(
        "Nothing to save",
        "Type a thought, record audio, or attach something first.",
      );
      return;
    }
    savingRef.current = true;
    if (draftTimer.current) clearTimeout(draftTimer.current);
    setSaving(true);
    try {
      let finalAudioUri = audioUri;
      if (recorderState.isRecording) {
        await recorder.stop();
        finalAudioUri = recorder.uri ?? null;
        if (finalAudioUri) setAudioUri(finalAudioUri);
      }
      const ideaId = await createIdeaFromCapture({
        draftId: DRAFT_ID,
        text,
        context,
        marks,
        attachments: extraAttachments.map((a) => ({
          type: a.kind,
          uri: a.uri,
          mimeType: a.mimeType,
        })),
        audioUri: finalAudioUri ?? undefined,
        audioDurationMs: recorderState.durationMillis,
        attachment: attachment?.kind
          ? {
              type: attachment.kind,
              uri: attachment.uri,
              mimeType: attachment.mimeType,
            }
          : undefined,
        sourceType:
          params.shared === "1"
            ? "share_sheet"
            : finalAudioUri
              ? "voice"
              : params.template
                ? "template"
                : "quick_capture",
      });
      savedExit.current = true;
      await Haptics.notificationAsync(
        Haptics.NotificationFeedbackType.Success,
      ).catch(() => {});
      bump();
      if (again) {
        savedExit.current = false;
        setText("");
        setAudioUri(null);
        setAttachment(null);
        setExtraAttachments([]);
        setContext("");
        setMarks([]);
        inputRef.current?.focus();
      } else router.canGoBack() ? router.back() : router.replace("/" as any);
    } catch (e) {
      Alert.alert("Could not save idea", String(e));
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };

  const close = async () => {
    if (savingRef.current) return;
    try {
      if (draftTimer.current) clearTimeout(draftTimer.current);
      let uri = audioUri;
      if (recorderState.isRecording) {
        await recorder.stop();
        uri = recorder.uri ?? null;
      }
      await saveDraft(
        DRAFT_ID,
        text,
        uri ? "audio" : (attachment?.kind ?? "text"),
        uri ?? attachment?.uri ?? null,
        JSON.stringify({
          audioUri: uri,
          attachment,
          extraAttachments,
          context,
          marks,
        }),
      );
      router.back();
    } catch (e) {
      Alert.alert("Could not keep the draft", String(e));
    }
  };
  const seconds = Math.floor((recorderState.durationMillis || 0) / 1000);
  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.header}>
          <Pressable
            accessibilityLabel="Close capture"
            onPress={close}
            disabled={saving || !restored}
            style={styles.icon}
          >
            <Text style={styles.iconText}>×</Text>
          </Pressable>
          <H1>Quick capture</H1>
          <View style={styles.icon} />
        </View>
        <Caption
          style={{
            paddingHorizontal: 24,
            color: draftError ? colors.danger : colors.textMuted,
          }}
        >
          {draftError
            ? "Draft could not autosave. Keep this screen open and try Save."
            : "Your draft stays here, including when you close this screen."}
        </Caption>
        <TextInput
          editable={restored && !saving}
          ref={inputRef}
          accessibilityLabel="Idea text"
          value={text}
          onChangeText={setText}
          multiline
          placeholder="What are you thinking?"
          placeholderTextColor={colors.textMuted}
          style={styles.editor}
          textAlignVertical="top"
        />
        <TextInput
          accessibilityLabel="Context postcard"
          editable={restored && !saving}
          placeholder="Where did this thought come from? (optional)"
          placeholderTextColor={colors.textMuted}
          value={context}
          onChangeText={setContext}
          style={{
            color: colors.textSecondary,
            minHeight: 48,
            paddingHorizontal: 24,
            fontSize: 15,
          }}
        />
        {extraAttachments.length ? (
          <ScrollView
            style={{ maxHeight: 96 }}
            contentContainerStyle={{ paddingHorizontal: 24, gap: 8 }}
          >
            {extraAttachments.map((a, i) => (
              <View
                key={a.uri}
                style={{ flexDirection: "row", alignItems: "center", gap: 8 }}
              >
                <Caption style={{ flex: 1 }}>
                  Attachment {i + 1} · {a.kind}
                </Caption>
                <Pressable
                  accessibilityRole="button"
                  disabled={saving}
                  accessibilityLabel={`Remove attachment ${i + 1}`}
                  style={{ minHeight: 44, justifyContent: "center" }}
                  onPress={() =>
                    setExtraAttachments((v) => v.filter((_, n) => n !== i))
                  }
                >
                  <Caption>Remove</Caption>
                </Pressable>
              </View>
            ))}
          </ScrollView>
        ) : null}
        {recorderState.isRecording ? (
          <Button
            label={`Mark this moment · ${marks.length} saved`}
            disabled={saving}
            variant="ghost"
            onPress={() =>
              setMarks((v) => [
                ...v,
                {
                  offsetMs: recorderState.durationMillis,
                  label: `Moment ${v.length + 1}`,
                },
              ])
            }
          />
        ) : null}
        {recorderState.isRecording ? (
          <View style={styles.recording}>
            <View style={styles.dot} />
            <Secondary>Recording • {seconds}s</Secondary>
          </View>
        ) : audioUri ? (
          <View style={styles.attachment}>
            <Secondary>● Voice recording attached</Secondary>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Remove recording"
              disabled={saving}
              style={{ minHeight: 44, justifyContent: "center" }}
              onPress={() => setAudioUri(null)}
            >
              <Caption>Remove</Caption>
            </Pressable>
          </View>
        ) : null}
        {attachment ? (
          <View style={styles.attachment}>
            <Secondary>
              {attachment.kind === "image" ? "▧ Image" : "▤ File"} attached
              {attachment.name ? ` • ${attachment.name}` : ""}
            </Secondary>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Remove attachment"
              disabled={saving}
              style={{ minHeight: 44, justifyContent: "center" }}
              onPress={() => setAttachment(null)}
            >
              <Caption>Remove</Caption>
            </Pressable>
          </View>
        ) : null}
        <View style={styles.tools}>
          <Pressable
            accessibilityRole="button"
            disabled={saving || !restored}
            accessibilityLabel={
              recorderState.isRecording ? "Stop recording" : "Record voice"
            }
            onPress={recorderState.isRecording ? stopRecording : startRecording}
            style={[
              styles.tool,
              recorderState.isRecording && styles.toolActive,
            ]}
          >
            <Icon
              name={recorderState.isRecording ? "stop-circle" : "mic-outline"}
            />
            <Caption>{recorderState.isRecording ? "Stop" : "Voice"}</Caption>
          </Pressable>
          <Pressable
            accessibilityLabel="Attach image"
            accessibilityRole="button"
            disabled={saving || !restored}
            onPress={chooseImage}
            style={styles.tool}
          >
            <Icon name="image-outline" />
            <Caption>Image</Caption>
          </Pressable>
          <Pressable
            accessibilityLabel="Take photo"
            accessibilityRole="button"
            disabled={saving || !restored}
            onPress={takePhoto}
            style={styles.tool}
          >
            <Icon name="camera-outline" />
            <Caption>Camera</Caption>
          </Pressable>
          <Pressable
            accessibilityLabel="Attach file"
            accessibilityRole="button"
            disabled={saving || !restored}
            onPress={chooseFile}
            style={styles.tool}
          >
            <Icon name="attach-outline" />
            <Caption>File</Caption>
          </Pressable>
        </View>
        <View style={styles.bottom}>
          <Button
            label="Save + New"
            variant="secondary"
            disabled={saving || !restored}
            onPress={() => save(true)}
            style={{ flex: 1 }}
          />
          <Button
            label="Save"
            disabled={!restored}
            loading={saving}
            onPress={() => save(false)}
            style={{ flex: 1 }}
          />
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  flex: { flex: 1 },
  header: {
    height: 64,
    paddingHorizontal: spacing.lg,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  icon: {
    width: 48,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
  },
  iconText: { color: colors.textPrimary, fontSize: 30 },
  editor: {
    flex: 1,
    color: colors.textPrimary,
    fontSize: 20,
    lineHeight: 30,
    padding: spacing.xl,
    minHeight: 240,
  },
  recording: {
    marginHorizontal: spacing.lg,
    borderRadius: radius.md,
    padding: spacing.md,
    backgroundColor: colors.surfaceRaised,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.danger,
  },
  attachment: {
    marginHorizontal: spacing.lg,
    marginTop: 8,
    minHeight: 48,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    backgroundColor: colors.surfaceRaised,
    borderWidth: 1,
    borderColor: colors.border,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  tools: {
    flexDirection: "row",
    gap: 8,
    padding: spacing.lg,
    flexWrap: "wrap",
  },
  tool: {
    width: 72,
    minHeight: 64,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: "center",
    justifyContent: "center",
    gap: 2,
  },
  toolActive: { borderColor: colors.danger },
  toolGlyph: { color: colors.textPrimary, fontSize: 19 },
  bottom: {
    flexDirection: "row",
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.md,
  },
});

const baseStyles = styles;
