import React from "react";
import { Alert } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { PageHeader, Panel, LoadState } from "@/components/studio/StudioUI";
import { H2, Caption, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { useAction, useLoad } from "@/hooks/useAsync";
import { listCaptureDrafts } from "@/db/repositories/thinking";
import { clearDraft } from "@/db/repositories/ideas";
import { formatDateTime } from "@/utils/date";
export default function Drafts() {
  const load = useLoad(listCaptureDrafts),
    action = useAction();
  return (
    <Screen>
      <PageHeader
        back
        title="Capture buffer"
        subtitle="Each unfinished thought has its own place."
      />
      <Button
        label="Start a separate capture"
        onPress={() => router.push("/capture" as any)}
      />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {load.data?.map((d) => (
        <Panel key={d.id} style={{ marginTop: 16 }}>
          <H2>{d.body_text.slice(0, 100) || "A media capture"}</H2>
          <Caption>
            {formatDateTime(d.updated_at)} · {d.mode}
          </Caption>
          <Button
            label="Resume this draft"
            variant="secondary"
            onPress={() => router.push(`/capture?draft=${d.id}` as any)}
          />
          <Button
            label="Discard draft"
            variant="ghost"
            onPress={() =>
              Alert.alert(
                "Discard draft?",
                "This cannot be undone. Saved ideas stay in the vault.",
                [
                  { text: "Keep", style: "cancel" },
                  {
                    text: "Discard",
                    style: "destructive",
                    onPress: () =>
                      action.run(() => clearDraft(d.id), "Draft discarded"),
                  },
                ],
              )
            }
          />
        </Panel>
      ))}
      {load.data?.length === 0 ? (
        <Secondary style={{ marginTop: 24 }}>
          No unfinished captures. A new thought can arrive whenever it likes.
        </Secondary>
      ) : null}
    </Screen>
  );
}
