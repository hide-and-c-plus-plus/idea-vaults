import React from "react";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { PageHeader, ToolTile } from "@/components/studio/StudioUI";
import { TEMPLATES } from "@/domain/prompts";
export default function TemplatesScreen() {
  return (
    <Screen>
      <PageHeader
        back
        eyebrow="START WITH A BETTER QUESTION"
        title="Capture starters"
        subtitle="A little structure when the blank page feels too blank."
      />
      {TEMPLATES.map((t) => (
        <ToolTile
          key={t.id}
          glyph={t.glyph}
          title={t.title}
          description={
            t.body.split("\n")[0] ||
            "No structure. Just write what is on your mind."
          }
          onPress={() =>
            router.push({
              pathname: "/capture",
              params: { template: t.id },
            } as any)
          }
        />
      ))}
    </Screen>
  );
}
