import React from "react";
import { View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { PageHeader, Panel, Field, ui } from "@/components/studio/StudioUI";
import { Button } from "@/components/ui/Button";
import { Group, Row, SectionLabel, DraftStatus } from "@/components/ui/IOS";
import { Secondary } from "@/components/ui/Typography";
import { useAction, useLoad, useDraftForm } from "@/hooks/useAsync";
import { customRecipes, saveRecipe } from "@/db/repositories/thinking";
export default function Rituals() {
  const load = useLoad(customRecipes),
    action = useAction(),
    draft = useDraftForm("new-recipe", {
      title: "",
      description: "",
      steps: "",
    });
  return (
    <Screen>
      <PageHeader
        back
        title="Your thinking recipes"
        subtitle="A few good questions, in an order that helps."
      />
      <Panel>
        <Field
          label="Recipe name"
          value={draft.value.title}
          onChangeText={(title) => draft.setValue((v) => ({ ...v, title }))}
        />
        <Field
          label="When is it useful?"
          value={draft.value.description}
          onChangeText={(description) =>
            draft.setValue((v) => ({ ...v, description }))
          }
        />
        <Field
          label="One step or question per line"
          multiline
          value={draft.value.steps}
          onChangeText={(steps) => draft.setValue((v) => ({ ...v, steps }))}
          placeholder={
            "What do I know?\nWhat am I assuming?\nWhat could I try?"
          }
        />
        <DraftStatus status={draft.status} />
        <Button
          label="Save recipe"
          disabled={!draft.ready || !draft.value.title.trim()}
          loading={action.busy}
          onPress={() =>
            action.run(async () => {
              await saveRecipe(
                draft.value.title,
                draft.value.description,
                draft.value.steps.split("\n").filter((s) => s.trim()),
              );
              await draft.clear();
              draft.setValue({ title: "", description: "", steps: "" });
              draft.resume();
            }, "Recipe saved")
          }
        />
      </Panel>
      <SectionLabel>YOUR RECIPES</SectionLabel>
      <Group>
        {load.data?.map((r, i) => (
          <Row
            key={r.id}
            title={r.title}
            detail={r.description}
            last={i === load.data!.length - 1}
            onPress={() => router.push(`/exercise?recipe=${r.id}` as any)}
          />
        ))}
      </Group>
      <Secondary style={{ marginTop: 20 }}>
        Recipes guide your writing. They do not run code, transmit notes, or
        alter source material.
      </Secondary>
    </Screen>
  );
}
