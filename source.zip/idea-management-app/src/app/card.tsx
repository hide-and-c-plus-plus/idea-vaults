import { useColors, useThemedStyles } from "@/theme/Theme";
import React from "react";
import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import {
  PageHeader,
  Panel,
  Field,
  LoadState,
  IdeaPicker,
  ui,
} from "@/components/studio/StudioUI";
import { Button } from "@/components/ui/Button";
import { Caption, Secondary } from "@/components/ui/Typography";
import { Chip } from "@/components/ui/Chip";
import { DraftStatus } from "@/components/ui/IOS";
import { useAction, useDraftForm, useLoad } from "@/hooks/useAsync";
import { cards, saveCard } from "@/db/repositories/thinking";
import {
  CARD_KINDS,
  EPISTEMIC,
  type ThoughtCard,
  type CardKind,
} from "@/domain/thinking";
export default function CardScreen() {
  const p = useLocalSearchParams<{
      idea: string;
      id?: string;
      kind?: string;
    }>(),
    load = useLoad(() => cards(), [p.id]);
  return (
    <Screen>
      <PageHeader back title={p.id ? "Edit card" : "Add a thinking card"} />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {load.data ? (
        <Editor
          idea={p.idea}
          existing={load.data.find((c) => c.id === p.id)}
          all={load.data}
          initialKind={p.kind}
        />
      ) : null}
    </Screen>
  );
}
function Editor({
  idea,
  existing,
  all,
  initialKind,
}: {
  idea: string;
  existing?: ThoughtCard;
  all: ThoughtCard[];
  initialKind?: string;
}) {
  const ui = useThemedStyles(baseUI);
  const action = useAction(),
    key = `card:${existing?.id ?? idea}`,
    form = useDraftForm(key, {
      kind:
        existing?.kind ??
        (initialKind && initialKind in CARD_KINDS
          ? (initialKind as CardKind)
          : "assumption"),
      title: existing?.title ?? "",
      body: existing?.body ?? "",
      interpretation: existing?.interpretation ?? "",
      sourceUrl: existing?.source_url ?? "",
      sourceQuote: existing?.source_quote ?? "",
      epistemic: existing?.epistemic ?? "unresolved",
      relation: existing?.relation ?? "supports",
      relatedCardId: existing?.related_card_id ?? "",
    });
  const patch = (p: Partial<typeof form.value>) =>
    form.setValue((v) => ({ ...v, ...p }));
  return (
    <View style={ui.stack}>
      <Panel>
        <Caption>WHAT KIND OF MATERIAL?</Caption>
        <View style={ui.wrap}>
          {Object.entries(CARD_KINDS).map(([kind, label]) => (
            <Chip
              key={kind}
              label={label}
              selected={form.value.kind === kind}
              onPress={() => patch({ kind: kind as CardKind })}
            />
          ))}
        </View>
        <Field
          label="Statement or title"
          multiline
          value={form.value.title}
          onChangeText={(title) => patch({ title })}
        />
        <Field
          label="Details / what happened"
          multiline
          value={form.value.body}
          onChangeText={(body) => patch({ body })}
        />
        <Field
          label="Interpretation, limits, or reopening condition"
          multiline
          value={form.value.interpretation}
          onChangeText={(interpretation) => patch({ interpretation })}
        />
        <Caption>HOW DO YOU KNOW?</Caption>
        <View style={ui.wrap}>
          {EPISTEMIC.map((epistemic) => (
            <Chip
              key={epistemic}
              label={epistemic}
              selected={form.value.epistemic === epistemic}
              onPress={() => patch({ epistemic })}
            />
          ))}
        </View>
        <Field
          label="Source URL (optional)"
          autoCapitalize="none"
          value={form.value.sourceUrl}
          onChangeText={(sourceUrl) => patch({ sourceUrl })}
        />
        <Field
          label="Exact source excerpt (optional)"
          multiline
          value={form.value.sourceQuote}
          onChangeText={(sourceQuote) => patch({ sourceQuote })}
        />
      </Panel>
      <Panel>
        <Caption>CONNECT THIS TO A CLAIM OR QUESTION</Caption>
        <View style={ui.wrap}>
          {[
            "supports",
            "challenges",
            "qualifies",
            "depends_on",
            "fulfills",
          ].map((relation) => (
            <Chip
              key={relation}
              label={relation.replaceAll("_", " ")}
              selected={form.value.relation === relation}
              onPress={() => patch({ relation })}
            />
          ))}
        </View>
        <Button
          label="No linked card"
          variant="ghost"
          onPress={() => patch({ relatedCardId: "" })}
        />
        {all
          .filter(
            (c) =>
              c.id !== existing?.id &&
              ["assumption", "question", "gap", "decision", "concept"].includes(
                c.kind,
              ),
          )
          .map((c) => (
            <Chip
              key={c.id}
              label={`${c.title} · ${c.idea_title}`}
              selected={form.value.relatedCardId === c.id}
              onPress={() => patch({ relatedCardId: c.id })}
            />
          ))}
      </Panel>
      <DraftStatus status={form.status} />
      <Button
        label="Save card"
        disabled={!form.ready || !form.value.title.trim()}
        loading={action.busy}
        onPress={() =>
          action.run(async () => {
            await saveCard({ ...form.value, id: existing?.id, ideaId: idea });
            await form.clear();
            router.back();
          }, "Card saved")
        }
      />
    </View>
  );
}

const baseUI = ui;
