import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useState } from "react";
import * as FileSystem from "expo-file-system/legacy";
import { Screen } from "@/components/ui/Screen";
import { PageHeader, Panel, LoadState, ui } from "@/components/studio/StudioUI";
import { View } from "react-native";
import { Button } from "@/components/ui/Button";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { useLoad, useAction } from "@/hooks/useAsync";
import { health } from "@/db/repositories/thinking";
import { exportAllData } from "@/services/export";
import {
  pickArchive,
  restoreArchive,
  type ArchivePreview,
} from "@/services/restore";
export default function Recovery() {
  const ui = useThemedStyles(baseUI);
  const [preview, setPreview] = useState<ArchivePreview | null>(null),
    action = useAction(),
    load = useLoad(async () => {
      const h = await health();
      const missing = [];
      for (const a of h.attachments) {
        const info = await FileSystem.getInfoAsync(a.local_uri).catch(() => ({
          exists: false,
        }));
        if (!info.exists) missing.push(a.id);
      }
      return { ...h, missing };
    });
  return (
    <Screen>
      <PageHeader
        back
        title="Recovery"
        subtitle="Know what is saved. Know what can come back."
      />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      <View style={ui.stack}>
        {load.data ? (
          <Panel>
            <H2>Your vault, checked</H2>
            <Body>
              {load.data.ideas} thoughts · {load.data.revisions} versions
            </Body>
            <Secondary>
              {load.data.missing.length
                ? `${load.data.missing.length} original media files are missing. Text and other records remain available.`
                : "Every registered attachment is present."}
            </Secondary>
            <Caption>
              {load.data.foreignKeys.length
                ? "A relationship needs repair. Export a backup before changing the vault."
                : "Relationship checks passed."}
            </Caption>
            <Caption>
              {load.data.lastExport
                ? `Last archive prepared: ${new Date(JSON.parse(load.data.lastExport.value).at).toLocaleString()}`
                : "No archive has been prepared on this device yet."}
            </Caption>
          </Panel>
        ) : null}
        <Panel>
          <H2>Keep a recoverable copy</H2>
          <Secondary>
            Includes thoughts, media, evidence, question rooms, versions, and
            thinking sessions. Save the shared ZIP somewhere you control.
          </Secondary>
          <Button
            label="Export a vault archive"
            loading={action.busy}
            onPress={() =>
              action.run(
                () => exportAllData(),
                "Archive prepared — choose where to save it",
              )
            }
          />
          <Caption>
            Archives contain plain text and original media. Preparing one does
            not prove it was saved outside this app. This release supports
            archives up to 32 MB.
          </Caption>
        </Panel>
        <Panel>
          <H2>Bring a vault back</H2>
          <Secondary>
            Import adds to this vault. Conflicting IDs become copies, preserving
            their connections. Your current work is retained.
          </Secondary>
          <Button
            label="Choose an archive to inspect"
            variant="secondary"
            disabled={action.busy}
            onPress={() =>
              action.run(async () => {
                const next = await pickArchive();
                if (next) setPreview(next);
              })
            }
          />
        </Panel>
        {preview ? (
          <Panel>
            <H2>Review before restoring</H2>
            <Body>
              {preview.ideaCount} thoughts · {preview.mediaCount} available
              media files
            </Body>
            <Secondary>Exported: {preview.exportedAt}</Secondary>
            {preview.warnings.map((w) => (
              <Caption key={w}>{w}</Caption>
            ))}
            <Button
              label="Restore as additional thoughts"
              loading={action.busy}
              onPress={() =>
                action.run(async () => {
                  await restoreArchive(preview);
                  setPreview(null);
                }, "Archive restored; existing thoughts retained")
              }
            />
            <Button
              label="Cancel"
              variant="ghost"
              onPress={() => setPreview(null)}
            />
          </Panel>
        ) : null}
      </View>
    </Screen>
  );
}

const baseUI = ui;
