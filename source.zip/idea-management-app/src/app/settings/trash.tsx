import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useEffect, useState } from "react";
import { Alert, Pressable, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { H1, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { IdeaCard } from "@/components/idea/IdeaCard";
import {
  listTrash,
  permanentlyDeleteIdea,
  restoreIdea,
} from "@/db/repositories/ideas";
import type { Idea } from "@/domain/types";
import { useDataChange } from "@/state/DataChangeContext";
import { colors, spacing } from "@/theme/tokens";
export default function TrashScreen() {
  const styles = useThemedStyles(baseStyles);

  const { epoch, bump } = useDataChange();
  const [items, setItems] = useState<Idea[]>([]);
  useEffect(() => {
    listTrash().then(setItems);
  }, [epoch]);
  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.icon}>
          <Text style={styles.glyph}>‹</Text>
        </Pressable>
        <H1>Trash</H1>
        <View style={styles.icon} />
      </View>
      <Secondary>
        Deleted ideas remain recoverable for 30 days unless you permanently
        delete them sooner.
      </Secondary>
      <View style={{ gap: spacing.md, marginTop: spacing.xl }}>
        {items.map((i) => (
          <View key={i.id} style={{ gap: 8 }}>
            <IdeaCard idea={i} />
            <View style={styles.row}>
              <Button
                label="Restore"
                variant="secondary"
                onPress={async () => {
                  await restoreIdea(i.id);
                  bump();
                }}
                style={{ flex: 1 }}
              />
              <Button
                label="Delete forever"
                variant="danger"
                onPress={() =>
                  Alert.alert(
                    "Delete forever?",
                    "This removes the database record. Export first if you may need it.",
                    [
                      { text: "Cancel", style: "cancel" },
                      {
                        text: "Delete forever",
                        style: "destructive",
                        onPress: async () => {
                          await permanentlyDeleteIdea(i.id);
                          bump();
                        },
                      },
                    ],
                  )
                }
                style={{ flex: 1 }}
              />
            </View>
          </View>
        ))}
      </View>
    </Screen>
  );
}
const styles = StyleSheet.create({
  header: {
    paddingTop: spacing.sm,
    minHeight: 60,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  icon: {
    width: 48,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
  },
  glyph: { color: colors.textPrimary, fontSize: 24 },
  row: { flexDirection: "row", gap: spacing.sm },
});

const baseStyles = styles;
