import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useState } from "react";
import { View, ScrollView } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import {
  PageHeader,
  Field,
  Panel,
  LoadState,
  ui,
} from "@/components/studio/StudioUI";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Chip } from "@/components/ui/Chip";
import { Button } from "@/components/ui/Button";
import { useLoad } from "@/hooks/useAsync";
import { cards } from "@/db/repositories/thinking";
import { CARD_KINDS } from "@/domain/thinking";
export default function Shelves() {
  const ui = useThemedStyles(baseUI);
  const [kind, setKind] = useState(""),
    [query, setQuery] = useState(""),
    load = useLoad(() => cards(undefined, kind, query), [kind, query]);
  return (
    <Screen>
      <PageHeader
        back
        title="Evidence & ingredients"
        subtitle="What you know, what you wonder, what you can reuse."
      />
      <Field label="Search every card" value={query} onChangeText={setQuery} />
      <ScrollView
        horizontal
        style={{ marginVertical: 16 }}
        contentContainerStyle={{ gap: 8 }}
      >
        <Chip label="All" selected={!kind} onPress={() => setKind("")} />
        {Object.entries(CARD_KINDS).map(([k, v]) => (
          <Chip
            key={k}
            label={v}
            selected={kind === k}
            onPress={() => setKind(k)}
          />
        ))}
      </ScrollView>
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      <View style={ui.stack}>
        {load.data?.map((c) => (
          <Panel key={c.id}>
            <Caption>
              {CARD_KINDS[c.kind]} · {c.epistemic} · {c.status}
            </Caption>
            <H2>{c.title}</H2>
            <Body>{c.body}</Body>
            <Secondary>{c.interpretation}</Secondary>
            <Button
              label={c.idea_title ?? "Open source thought"}
              variant="ghost"
              onPress={() =>
                router.push(`/thinking?id=${c.idea_id}&tab=Evidence` as any)
              }
            />
          </Panel>
        ))}
      </View>
      {load.data?.length === 0 ? (
        <Secondary>
          No cards here yet. Open a thought → Thinking space → Evidence to add
          one.
        </Secondary>
      ) : null}
    </Screen>
  );
}

const baseUI = ui;
