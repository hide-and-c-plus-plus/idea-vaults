import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useEffect, useState } from "react";
import { View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import {
  PageHeader,
  Panel,
  Field,
  LoadState,
  ui,
} from "@/components/studio/StudioUI";
import { Button } from "@/components/ui/Button";
import { H2, Body, Caption, Secondary } from "@/components/ui/Typography";
import {
  Group,
  Row,
  Icon,
  SectionLabel,
  DraftStatus,
} from "@/components/ui/IOS";
import { useLoad, useAction, useDraftForm } from "@/hooks/useAsync";
import {
  beginDiscovery,
  discovery,
  revealDiscovery,
  respondDiscovery,
  finishDiscovery,
} from "@/db/repositories/thinking";
export default function Discover() {
  const ui = useThemedStyles(baseUI);
  const [id, setId] = useState(""),
    [ended, setEnded] = useState(false),
    action = useAction(),
    form = useDraftForm("discovery-response", {
      recall: "" as string,
      takeaway: "",
    });
  const load = useLoad(
    () => (id ? discovery(id) : Promise.resolve(null)),
    [id],
  );
  const session = load.data;
  const current = session?.items.find((i) => !i.action);
  const start = () =>
    action.run(async () => {
      setEnded(false);
      setId(await beginDiscovery("recall"));
    });
  return (
    <Screen>
      <PageHeader
        title="Discover"
        subtitle="A useful return, with a place to stop."
      />
      {!id ? (
        <>
          <Panel>
            <Icon name="compass-outline" size={34} />
            <H2>A letter from your past self.</H2>
            <Secondary>
              Meet up to three thoughts you haven’t opened recently. Recall a
              little, reveal the original, and decide what matters now.
            </Secondary>
            <Button
              label="Begin a small discovery"
              loading={action.busy}
              onPress={start}
            />
          </Panel>
          <SectionLabel>OTHER WAYS TO RETURN</SectionLabel>
          <Group>
            <Row
              icon="git-network-outline"
              title="Follow a connection"
              onPress={() => router.push("/atlas" as any)}
            />
            <Row
              icon="journal-outline"
              title="Reflect on what changed"
              onPress={() => router.push("/review" as any)}
            />
            <Row
              last
              icon="leaf-outline"
              title="Rescue an ingredient"
              onPress={() => router.push("/compost" as any)}
            />
          </Group>
        </>
      ) : null}
      <LoadState
        loading={!!id && load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {session && !ended && !session.session?.completed_at ? (
        <View style={ui.stack}>
          {current ? (
            <Panel>
              <Caption>
                THOUGHT {current.position + 1} OF {session.items.length}
              </Caption>
              <H2>{current.title}</H2>
              <Secondary>{current.reason}</Secondary>
              {!current.revealed_at ? (
                <>
                  <Field
                    label="Before looking: what do you remember?"
                    multiline
                    value={form.value.recall}
                    onChangeText={(recall) =>
                      form.setValue((v) => ({ ...v, recall }))
                    }
                  />
                  <Button
                    label="Reveal the thought"
                    loading={action.busy}
                    onPress={() =>
                      action.run(() =>
                        revealDiscovery(id, current.id, form.value.recall),
                      )
                    }
                  />
                </>
              ) : (
                <>
                  <Body>
                    {current.snippet ||
                      current.summary ||
                      "This thought contains media. Open it to revisit the original."}
                  </Body>
                  {current.recall ? (
                    <Secondary>You remembered: {current.recall}</Secondary>
                  ) : null}
                  <Button
                    label="Open this thought"
                    variant="secondary"
                    onPress={() => router.push(`/idea/${current.id}` as any)}
                  />
                  {(
                    [
                      ["useful", "Useful now"],
                      ["remembered", "Good to remember"],
                      ["not_now", "Let it rest for a week"],
                    ] as const
                  ).map(([signal, label]) => (
                    <Button
                      key={signal}
                      label={label}
                      variant="ghost"
                      disabled={action.busy}
                      onPress={() =>
                        action.run(async () => {
                          await respondDiscovery(id, current.id, signal);
                          form.setValue((v) => ({ ...v, recall: "" }));
                        })
                      }
                    />
                  ))}
                </>
              )}
            </Panel>
          ) : (
            <Panel>
              <H2>That’s enough for now.</H2>
              <Secondary>
                {session.items.length
                  ? "You have reached the end of this small collection."
                  : "There are no available thoughts for discovery. Capture something, or let protected thoughts rest."}
              </Secondary>
            </Panel>
          )}
          <Panel>
            <Field
              label="One thing you want to take away"
              multiline
              value={form.value.takeaway}
              onChangeText={(takeaway) =>
                form.setValue((v) => ({ ...v, takeaway }))
              }
            />
            <DraftStatus status={form.status} />
            <Button
              label="Enough for now"
              variant="secondary"
              loading={action.busy}
              onPress={() =>
                action.run(async () => {
                  await finishDiscovery(id, form.value.takeaway);
                  await form.clear();
                  setEnded(true);
                }, "Takeaway saved")
              }
            />
          </Panel>
        </View>
      ) : null}
      {ended || session?.session?.completed_at ? (
        <Panel>
          <Icon name="checkmark-circle-outline" size={36} />
          <H2>A good place to pause.</H2>
          <Body>
            {session?.session?.takeaway ||
              form.value.takeaway ||
              "Your return signals are saved. Nothing else needs doing."}
          </Body>
          <Button
            label="Back to Today"
            onPress={() => router.replace("/" as any)}
          />
        </Panel>
      ) : null}
    </Screen>
  );
}

const baseUI = ui;
