import React, { useState } from "react";
import { View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import {
  PageHeader,
  Panel,
  Field,
  LoadState,
  EmptyState,
  ui,
} from "@/components/studio/StudioUI";
import { Button } from "@/components/ui/Button";
import { H2, Secondary } from "@/components/ui/Typography";
import {
  Group,
  Row,
  IconButton,
  SectionLabel,
  DraftStatus,
} from "@/components/ui/IOS";
import { useAction, useLoad, useDraftForm } from "@/hooks/useAsync";
import { listInquiries, saveInquiry } from "@/db/repositories/thinking";
export default function Rooms() {
  const [adding, setAdding] = useState(false),
    load = useLoad(listInquiries),
    action = useAction();
  const draft = useDraftForm("new-inquiry", { question: "", context: "" });
  return (
    <Screen>
      <PageHeader
        title="Question rooms"
        subtitle="Good questions deserve somewhere to live."
        right={
          <IconButton
            name="add"
            label="New question room"
            onPress={() => setAdding(!adding)}
          />
        }
      />
      {adding ? (
        <Panel>
          <H2>What are you wondering?</H2>
          <Field
            label="An open question"
            value={draft.value.question}
            onChangeText={(question) =>
              draft.setValue((v) => ({ ...v, question }))
            }
            placeholder="Why do good ideas get abandoned?"
          />
          <Field
            label="Why it matters"
            multiline
            value={draft.value.context}
            onChangeText={(context) =>
              draft.setValue((v) => ({ ...v, context }))
            }
          />
          <DraftStatus status={draft.status} />
          <Button
            label="Create a room"
            disabled={!draft.ready || !draft.value.question.trim()}
            loading={action.busy}
            onPress={() =>
              action.run(async () => {
                const id = await saveInquiry(
                  draft.value.question,
                  draft.value.context,
                );
                await draft.clear();
                draft.setValue({ question: "", context: "" });
                draft.resume();
                setAdding(false);
                router.push(`/inquiry?id=${id}` as any);
              })
            }
          />
        </Panel>
      ) : null}
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {load.data?.length ? (
        <>
          <SectionLabel>YOUR QUESTIONS</SectionLabel>
          <Group>
            {load.data.map((room, i) => (
              <Row
                key={room.id}
                icon="chatbubble-ellipses-outline"
                title={room.question}
                detail={`${room.member_count} thoughts · ${room.status}`}
                last={i === load.data!.length - 1}
                onPress={() => router.push(`/inquiry?id=${room.id}` as any)}
              />
            ))}
          </Group>
        </>
      ) : !load.loading ? (
        <EmptyState
          title="Begin with a question"
          body="Collect observations, possible answers, counterexamples, and experiments around something that matters to you."
          action={
            <Button
              label="Ask your first question"
              onPress={() => setAdding(true)}
            />
          }
        />
      ) : null}
      <SectionLabel>A DIFFERENT KIND OF ROOM</SectionLabel>
      <Secondary>
        A thought can belong to several questions. You can gather evidence here
        without committing to a project.
      </Secondary>
    </Screen>
  );
}
