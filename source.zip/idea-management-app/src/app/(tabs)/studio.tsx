import React from "react";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { PageHeader, Panel } from "@/components/studio/StudioUI";
import { H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { Group, Row, SectionLabel, Icon } from "@/components/ui/IOS";
export default function Studio() {
  const go = (p: string) => router.push(p as any);
  return (
    <Screen>
      <PageHeader
        title="Studio"
        subtitle="Ways to think, not more things to do."
      />
      <Panel>
        <Icon name="sparkles-outline" size={30} />
        <H2>Find another way in.</H2>
        <Secondary>
          Explore a possibility, challenge an assumption, or keep the part that
          almost got away.
        </Secondary>
        <Button
          label="Browse thinking exercises"
          onPress={() => go("/workshop")}
        />
      </Panel>
      <SectionLabel>MAKE SOMETHING OF IT</SectionLabel>
      <Group>
        <Row
          icon="shuffle-outline"
          title="Collision lab"
          detail="Combine two thoughts and keep their origins."
          onPress={() => go("/lab?tool=collision")}
        />
        <Row
          icon="git-branch-outline"
          title="Remix an idea"
          detail="Try a different shape, scale, or audience."
          onPress={() => go("/lab?tool=remix")}
        />
        <Row
          icon="flask-outline"
          title="Experiment bench"
          detail="Predictions, observations, and what you learned."
          onPress={() => go("/experiments")}
        />
        <Row
          last
          icon="leaf-outline"
          title="Intellectual compost"
          detail="Rescue useful ingredients from abandoned work."
          onPress={() => go("/compost")}
        />
      </Group>
      <SectionLabel>SEE WHAT YOU KNOW</SectionLabel>
      <Group>
        <Row
          icon="layers-outline"
          title="Evidence & ingredients"
          detail="Assumptions, sources, concepts, and open questions."
          onPress={() => go("/shelves")}
        />
        <Row
          icon="git-network-outline"
          title="Thought atlas"
          detail="Follow the relationships you have made."
          onPress={() => go("/atlas")}
        />
        <Row
          icon="git-compare-outline"
          title="Connection desk"
          detail="Review, accept, reject, and undo bridges."
          onPress={() => go("/bridges")}
        />
        <Row
          last
          icon="book-outline"
          title="Your thinking recipes"
          detail="Write a reusable sequence of questions."
          onPress={() => go("/rituals")}
        />
      </Group>
      <SectionLabel>MAKE ROOM TO CONTINUE</SectionLabel>
      <Group>
        <Row
          icon="moon-outline"
          title="Focus room"
          onPress={() => go("/focus")}
        />
        <Row
          icon="folder-outline"
          title="Project rooms"
          onPress={() => go("/projects")}
        />
        <Row
          icon="time-outline"
          title="Time capsules"
          onPress={() => go("/capsules")}
        />
        <Row
          icon="journal-outline"
          title="Reflection journal"
          onPress={() => go("/review")}
        />
        <Row
          last
          icon="create-outline"
          title="Capture starters"
          onPress={() => go("/templates")}
        />
      </Group>
    </Screen>
  );
}
