import React from "react";
import { View, type ColorValue } from "react-native";
import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "@/theme/Theme";
import { Icon, type IconName } from "@/components/ui/IOS";
export default function TabsLayout() {
  const insets = useSafeAreaInsets(),
    { colors } = useTheme();
  const tab = (title: string, name: IconName, active: IconName) => ({
    title,
    tabBarIcon: ({
      focused,
      color,
    }: {
      focused: boolean;
      color: ColorValue;
    }) => <Icon name={focused ? active : name} size={24} color={color} />,
  });
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarHideOnKeyboard: true,
        tabBarStyle: {
          backgroundColor: colors.chrome,
          borderTopWidth: 0.5,
          borderTopColor: colors.border,
          height: 66 + insets.bottom,
          paddingTop: 8,
          paddingBottom: Math.max(insets.bottom, 8),
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: "500" },
      }}
    >
      <Tabs.Screen
        name="index"
        options={tab("Today", "sunny-outline", "sunny")}
      />
      <Tabs.Screen
        name="library"
        options={tab("Vault", "albums-outline", "albums")}
      />
      <Tabs.Screen
        name="rooms"
        options={tab("Rooms", "chatbubbles-outline", "chatbubbles")}
      />
      <Tabs.Screen
        name="studio"
        options={tab("Studio", "sparkles-outline", "sparkles")}
      />
      <Tabs.Screen
        name="discover"
        options={tab("Discover", "compass-outline", "compass")}
      />
      <Tabs.Screen name="atlas" options={{ href: null }} />
      <Tabs.Screen name="review" options={{ href: null }} />
      <Tabs.Screen name="inbox" options={{ href: null }} />
    </Tabs>
  );
}
