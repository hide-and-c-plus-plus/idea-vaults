import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useEffect, useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import { IdeaCard } from "@/components/idea/IdeaCard";
import {
  EmptyState,
  Field,
  LoadState,
  PageHeader,
  Panel,
  ui,
} from "@/components/studio/StudioUI";
import {
  listCategories,
  searchIdeas,
  updateIdea,
  type SearchFilters,
} from "@/db/repositories/ideas";
import { removeView, savedViews, saveView } from "@/db/repositories/creative";
import { useAction, useLoad } from "@/hooks/useAsync";
import { STAGE_LABELS } from "@/domain/creative";
import type { IdeaStage } from "@/domain/types";
import { colors } from "@/theme/tokens";
const stages: IdeaStage[] = [
  "spark",
  "exploring",
  "promising",
  "active",
  "parked",
  "done",
  "dropped",
  "archived",
];
export default function LibraryScreen() {
  const ui = useThemedStyles(baseUI);
  const colors = useColors();

  const [q, setQ] = useState(""),
    [debounced, setDebounced] = useState(""),
    [filters, setFilters] = useState<SearchFilters>({}),
    [showFilters, setShowFilters] = useState(false),
    [board, setBoard] = useState(false),
    [viewName, setViewName] = useState(""),
    [savingView, setSavingView] = useState(false),
    [moveId, setMoveId] = useState("");
  const [visible, setVisible] = useState(60);
  const action = useAction();
  useEffect(() => setVisible(60), [debounced, JSON.stringify(filters)]);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(q), 180);
    return () => clearTimeout(timer);
  }, [q]);
  const load = useLoad(
    () => searchIdeas(debounced, { ...filters, limit: visible }),
    [debounced, JSON.stringify(filters), visible],
  );
  const meta = useLoad(async () => ({
    categories: await listCategories(),
    views: await savedViews(),
  }));
  const patch = (p: SearchFilters) => setFilters((v) => ({ ...v, ...p }));
  const active = Object.values(filters).filter(Boolean).length;
  return (
    <Screen>
      <PageHeader
        eyebrow="EVERY THOUGHT HAS A PLACE"
        title="Your vault"
        subtitle="Find a thread. Pick it up. See where it goes."
      />
      <Field
        label="Search your ideas"
        value={q}
        onChangeText={setQ}
        placeholder="Titles, thoughts, tags, and developed notes…"
        autoCapitalize="none"
      />
      <View style={[ui.wrap, { marginTop: 14 }]}>
        <Chip
          label="★ Shortlist"
          selected={!!filters.starred}
          onPress={() => patch({ starred: !filters.starred })}
        />
        <Chip
          label={board ? "▤ List" : "▥ Stage board"}
          selected={board}
          onPress={() => setBoard(!board)}
        />
        <Chip
          label={`Filters${active ? ` · ${active}` : ""}`}
          selected={showFilters}
          onPress={() => setShowFilters(!showFilters)}
        />
        <Chip
          label="Saved views"
          selected={savingView}
          onPress={() => setSavingView(!savingView)}
        />
      </View>
      {savingView ? (
        <View style={ui.section}>
          <Panel>
            <H2>Keep a useful view</H2>
            <Secondary>
              Save this search and its filters, then return with one tap.
            </Secondary>
            <Field
              label="Name this view"
              value={viewName}
              onChangeText={setViewName}
              placeholder="Gentle ideas for a quiet evening"
              maxLength={60}
            />
            <Button
              label="Save this view"
              disabled={!viewName.trim()}
              loading={action.busy}
              onPress={() =>
                action.run(async () => {
                  await saveView(viewName, q, filters);
                  setViewName("");
                }, "View saved")
              }
            />
            {meta.data?.views.map((v) => (
              <View key={v.id} style={ui.row}>
                <Button
                  label={v.name}
                  variant="secondary"
                  style={{ flex: 1 }}
                  onPress={() => {
                    try {
                      setFilters(JSON.parse(v.filters_json));
                      setQ(v.query);
                    } catch {
                      setFilters({});
                    }
                  }}
                />
                <Button
                  label="Remove"
                  variant="ghost"
                  onPress={() => action.run(() => removeView(v.id))}
                />
              </View>
            ))}
          </Panel>
        </View>
      ) : null}
      {showFilters ? (
        <View style={ui.section}>
          <Panel>
            <Caption>STAGE</Caption>
            <View style={ui.wrap}>
              <Chip
                label="All"
                selected={!filters.stage}
                onPress={() => patch({ stage: undefined })}
              />
              {stages.map((stage) => (
                <Chip
                  key={stage}
                  label={STAGE_LABELS[stage]!}
                  selected={filters.stage === stage}
                  onPress={() =>
                    patch({
                      stage,
                      includeArchived:
                        stage === "archived" ? true : filters.includeArchived,
                    })
                  }
                />
              ))}
            </View>
            <Caption>ENERGY AVAILABLE</Caption>
            <View style={ui.wrap}>
              {["any", "low", "steady", "deep"].map((energy) => (
                <Chip
                  key={energy}
                  label={
                    energy === "low"
                      ? "Gentle"
                      : energy === "any"
                        ? "Any"
                        : energy
                  }
                  selected={(filters.energy ?? "any") === energy}
                  onPress={() =>
                    patch({ energy: energy === "any" ? undefined : energy })
                  }
                />
              ))}
            </View>
            <Caption>HORIZON</Caption>
            <View style={ui.wrap}>
              {[
                "all",
                "now",
                "soon",
                "someday",
                "evergreen",
                "time-sensitive",
              ].map((horizon) => (
                <Chip
                  key={horizon}
                  label={horizon}
                  selected={(filters.horizon ?? "all") === horizon}
                  onPress={() =>
                    patch({ horizon: horizon === "all" ? undefined : horizon })
                  }
                />
              ))}
            </View>
            <Caption>CATEGORY</Caption>
            <View style={ui.wrap}>
              <Chip
                label="All"
                selected={!filters.categoryId}
                onPress={() => patch({ categoryId: undefined })}
              />
              {meta.data?.categories.map((c) => (
                <Chip
                  key={c.id}
                  label={c.name}
                  selected={filters.categoryId === c.id}
                  onPress={() => patch({ categoryId: c.id })}
                />
              ))}
            </View>
            <Caption>CAPTURE SOURCE</Caption>
            <View style={ui.wrap}>
              {[
                "all",
                "quick_capture",
                "voice",
                "share_sheet",
                "collision_lab",
                "template",
                "import",
              ].map((sourceType) => (
                <Chip
                  key={sourceType}
                  label={sourceType.replaceAll("_", " ")}
                  selected={(filters.sourceType ?? "all") === sourceType}
                  onPress={() =>
                    patch({
                      sourceType: sourceType === "all" ? undefined : sourceType,
                    })
                  }
                />
              ))}
            </View>
            <Caption>CREATED</Caption>
            <View style={ui.wrap}>
              <Chip
                label="Any time"
                selected={!filters.since}
                onPress={() => patch({ since: undefined })}
              />
              <Chip
                label="Last 7 days"
                selected={!!filters.since}
                onPress={() => patch({ since: Date.now() - 7 * 86400000 })}
              />
            </View>
            <Field
              label="Tag starts with"
              value={filters.tag ?? ""}
              onChangeText={(tag) => patch({ tag })}
              placeholder="learning, android, garden…"
            />
            <Chip
              label="Include archived ideas"
              selected={!!filters.includeArchived}
              onPress={() =>
                patch({ includeArchived: !filters.includeArchived })
              }
            />
            <Button
              label="Clear all filters"
              variant="ghost"
              onPress={() => setFilters({})}
            />
          </Panel>
        </View>
      ) : null}
      <View style={ui.section}>
        <View style={ui.row}>
          <Caption style={{ flex: 1 }}>
            {load.data?.length ?? 0} results
            {load.data?.length === 200 ? " · showing first 200" : ""}
          </Caption>
          <Button
            label="Projects →"
            variant="ghost"
            onPress={() => router.push("/projects" as any)}
          />
        </View>
        <LoadState
          loading={load.loading && !load.data}
          error={load.error}
          onRetry={load.reload}
        />
        {load.data?.length === 0 ? (
          <EmptyState
            glyph="⌕"
            title={
              q || active ? "No matching thoughts yet" : "An open page, waiting"
            }
            body={
              q || active
                ? "Try a broader phrase or clear your filters."
                : "Start with a question or an observation. You can organize it later."
            }
            action={
              <Button
                label={q || active ? "Reset search" : "Capture an idea"}
                onPress={() => {
                  if (q || active) {
                    setQ("");
                    setFilters({});
                  } else router.push("/capture" as any);
                }}
              />
            }
          />
        ) : board ? (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator
            contentContainerStyle={{ gap: 16, paddingBottom: 20 }}
          >
            {stages
              .filter((s) => s !== "archived" || filters.includeArchived)
              .map((stage) => (
                <View key={stage} style={{ width: 260, gap: 12 }}>
                  <View style={ui.row}>
                    <View
                      style={{
                        width: 7,
                        height: 7,
                        borderRadius: 4,
                        backgroundColor:
                          stage === "done" ? colors.success : colors.accent,
                      }}
                    />
                    <H2 style={{ fontSize: 17 }}>{STAGE_LABELS[stage]}</H2>
                    <Caption>
                      {load.data?.filter((i) => i.stage === stage).length ?? 0}
                    </Caption>
                  </View>
                  {load.data
                    ?.filter((i) => i.stage === stage)
                    .map((i) => (
                      <View key={i.id} style={{ gap: 6 }}>
                        <IdeaCard idea={i} />
                        <Button
                          label="Move to another stage"
                          variant="ghost"
                          onPress={() => setMoveId(moveId === i.id ? "" : i.id)}
                        />
                        {moveId === i.id ? (
                          <View style={ui.wrap}>
                            {stages
                              .filter((s) => s !== i.stage)
                              .map((s) => (
                                <Chip
                                  key={s}
                                  label={STAGE_LABELS[s]!}
                                  onPress={() =>
                                    action.run(async () => {
                                      await updateIdea(i.id, { stage: s });
                                      setMoveId("");
                                    }, "Idea moved")
                                  }
                                />
                              ))}
                          </View>
                        ) : null}
                      </View>
                    ))}
                </View>
              ))}
          </ScrollView>
        ) : (
          <View style={ui.stack}>
            {load.data?.map((i) => (
              <IdeaCard key={i.id} idea={i} />
            ))}
          </View>
        )}
      </View>
      {load.data && load.data.length >= visible ? (
        <Button
          label="Show more thoughts"
          variant="secondary"
          onPress={() => setVisible((v) => v + 60)}
        />
      ) : null}
    </Screen>
  );
}

const baseUI = ui;
