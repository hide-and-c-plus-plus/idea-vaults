import React from "react";
import { View, Text } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { PageHeader, Panel, LoadState, ui } from "@/components/studio/StudioUI";
import {
  Group,
  Row,
  Icon,
  IconButton,
  SectionLabel,
} from "@/components/ui/IOS";
import { useTheme } from "@/theme/Theme";
import { useLoad } from "@/hooks/useAsync";
import {
  checkpoints,
  listInquiries,
  listCaptureDrafts,
} from "@/db/repositories/thinking";
import { listRecentIdeas } from "@/db/repositories/ideas";
import { IdeaCard } from "@/components/idea/IdeaCard";
export default function Today() {
  const { colors, preferences } = useTheme();
  const load = useLoad(async () => ({
    checkpoints: await checkpoints(),
    rooms: await listInquiries(),
    recent: await listRecentIdeas(4),
    drafts: await listCaptureDrafts(),
  }));
  const go = (s: string) => router.push(s as any),
    checkpoint = load.data?.checkpoints[0];
  return (
    <Screen>
      <PageHeader
        title="Today"
        eyebrow={new Date().toLocaleDateString(undefined, {
          weekday: "long",
          month: "long",
          day: "numeric",
        })}
        right={
          <IconButton
            name="settings-outline"
            label="Settings"
            onPress={() => go("/settings")}
          />
        }
      />
      <Panel style={{ padding: 24, gap: 16 }}>
        <Icon name="leaf-outline" size={31} />
        <Text
          style={{
            fontSize: 30,
            lineHeight: 37,
            fontWeight: "600",
            letterSpacing: -0.8,
            color: colors.textPrimary,
          }}
        >
          A little space{"\n"}for a great thought.
        </Text>
        <Secondary>
          Catch it as it comes. There’s time to make sense of it later.
        </Secondary>
        <Button label="Capture a thought" onPress={() => go("/capture")} />
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Button
            label="Record voice"
            variant="ghost"
            style={{ flex: 1, paddingHorizontal: 4 }}
            onPress={() => go("/capture?mode=audio")}
          />
          <Button
            label="Tiny fragment"
            variant="ghost"
            style={{ flex: 1, paddingHorizontal: 4 }}
            onPress={() => go("/capture?seed=Three%20words%20to%20keep%3A%20")}
          />
        </View>
      </Panel>
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {checkpoint ? (
        <>
          <SectionLabel>PICK UP THE THREAD</SectionLabel>
          <Panel>
            <Caption>{checkpoint.idea_title}</Caption>
            <H2>{checkpoint.restart}</H2>
            {checkpoint.open_question ? (
              <Secondary>{checkpoint.open_question}</Secondary>
            ) : null}
            <Button
              label="Continue this thought"
              variant="secondary"
              onPress={() => go(`/idea/${checkpoint.idea_id}`)}
            />
          </Panel>
        </>
      ) : null}
      {!preferences.quiet ? (
        <>
          <SectionLabel>WHAT WOULD HELP RIGHT NOW?</SectionLabel>
          <Group>
            <Row
              icon="chatbubbles-outline"
              title="Live with a question"
              detail="Gather evidence, ideas, and possible answers."
              onPress={() => go("/rooms")}
            />
            <Row
              icon="git-compare-outline"
              title="Make a connection"
              detail="Give two thoughts a reason to meet."
              onPress={() => go("/bridges")}
            />
            <Row
              icon="compass-outline"
              title="Rediscover something"
              detail="Three thoughts. One useful takeaway."
              onPress={() => go("/discover")}
            />
            <Row
              last
              icon="moon-outline"
              title="Give one idea your attention"
              detail="A focus session with somewhere to restart."
              onPress={() => go("/focus")}
            />
          </Group>
        </>
      ) : null}
      {load.data?.drafts.length ? (
        <>
          <SectionLabel>WAITING SAFELY</SectionLabel>
          <Group>
            <Row
              last
              icon="document-text-outline"
              title="Your unfinished captures"
              detail={`${load.data.drafts.length} saved drafts`}
              onPress={() => go("/drafts")}
            />
          </Group>
        </>
      ) : null}
      {load.data?.recent.length ? (
        <>
          <SectionLabel>RECENT THOUGHTS</SectionLabel>
          <View style={{ gap: 12 }}>
            {load.data.recent.slice(0, preferences.quiet ? 1 : 4).map((i) => (
              <IdeaCard key={i.id} idea={i} />
            ))}
          </View>
        </>
      ) : (
        <>
          <SectionLabel>BEGIN WITH SOMETHING REAL</SectionLabel>
          <Secondary>
            A question, an observation, a strange phrase. Your first thought is
            enough.
          </Secondary>
        </>
      )}
      <Caption style={{ textAlign: "center", paddingTop: 32 }}>
        Yours to keep. Room to think.
      </Caption>
    </Screen>
  );
}
