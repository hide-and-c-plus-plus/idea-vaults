import { useColors, useThemedStyles } from "@/theme/Theme";
import React from "react";
import { View } from "react-native";
import { Screen } from "@/components/ui/Screen";
import { Button } from "@/components/ui/Button";
import { IdeaCard } from "@/components/idea/IdeaCard";
import {
  EmptyState,
  LoadState,
  PageHeader,
  ui,
} from "@/components/studio/StudioUI";
import {
  listInboxIdeas,
  markProcessed,
  updateIdea,
} from "@/db/repositories/ideas";
import { useAction, useLoad } from "@/hooks/useAsync";
export default function InboxScreen() {
  const ui = useThemedStyles(baseUI);

  const load = useLoad(() => listInboxIdeas()),
    action = useAction();
  return (
    <Screen>
      <PageHeader
        back
        eyebrow="CATCH FIRST, ORGANIZE LATER"
        title="The inbox"
        subtitle="Give each spark a moment of attention, then choose where it goes."
      />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      <View style={ui.stack}>
        {load.data?.length === 0 ? (
          <EmptyState
            title="A little room to breathe"
            body="New captures will land here. You have reviewed everything in this inbox."
          />
        ) : null}
        {load.data?.map((i) => (
          <View key={i.id} style={{ gap: 8 }}>
            <IdeaCard idea={i} />
            <View style={ui.row}>
              <Button
                label="Reviewed"
                variant="secondary"
                disabled={action.busy}
                onPress={() =>
                  action.run(() => markProcessed(i.id), "Idea reviewed")
                }
                style={{ flex: 1 }}
              />
              <Button
                label="Let it incubate"
                variant="ghost"
                disabled={action.busy}
                onPress={() =>
                  action.run(async () => {
                    await updateIdea(i.id, { stage: "parked" });
                    await markProcessed(i.id);
                  }, "Parked safely")
                }
                style={{ flex: 1 }}
              />
            </View>
          </View>
        ))}
      </View>
    </Screen>
  );
}

const baseUI = ui;
