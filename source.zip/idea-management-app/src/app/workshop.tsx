import React, { useState } from "react";
import { ScrollView, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { PageHeader, Field, Panel } from "@/components/studio/StudioUI";
import { Caption, Secondary } from "@/components/ui/Typography";
import { Group, Row, SectionLabel } from "@/components/ui/IOS";
import { Chip } from "@/components/ui/Chip";
import { RECIPES, RECIPE_GROUPS } from "@/domain/recipes";
import { useLoad } from "@/hooks/useAsync";
import { customRecipes, getContract } from "@/db/repositories/thinking";
export default function Workshop() {
  const params = useLocalSearchParams<{ idea?: string }>(),
    [query, setQuery] = useState(""),
    [group, setGroup] = useState("All");
  const load = useLoad(
    async () => ({
      custom: await customRecipes(),
      contract: params.idea ? await getContract(params.idea) : null,
    }),
    [params.idea],
  );
  const all = [
    ...RECIPES,
    ...(load.data?.custom ?? []).map((r) => ({
      id: r.id,
      title: r.title,
      description: r.description,
      fields: JSON.parse(r.steps_json),
      group: "Your recipes",
      challenge: false,
    })),
  ];
  const items = all.filter(
    (r) =>
      (group === "All" || r.group === group) &&
      `${r.title} ${r.fields.join(" ")}`
        .toLocaleLowerCase()
        .includes(query.toLocaleLowerCase()) &&
      !(load.data?.contract?.sanctuary && r.challenge),
  );
  return (
    <Screen>
      <PageHeader
        back
        title="Thinking exercises"
        subtitle="A quiet workshop for your own answers."
      />
      <Field
        label="Find an exercise"
        value={query}
        onChangeText={setQuery}
        placeholder="Analogy, evidence, story, decision…"
      />
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ marginTop: 16 }}
        contentContainerStyle={{ gap: 8, paddingEnd: 20 }}
      >
        {[...RECIPE_GROUPS, "Your recipes"].map((g) => (
          <Chip
            key={g}
            label={g}
            selected={g === group}
            onPress={() => setGroup(g)}
          />
        ))}
      </ScrollView>
      <SectionLabel>{items.length} WAYS IN</SectionLabel>
      {load.data?.contract?.sanctuary ? (
        <Secondary>
          Challenge exercises are hidden while this thought is in sanctuary.
        </Secondary>
      ) : null}
      <Group>
        {items.map((r, i) => (
          <Row
            key={r.id}
            title={r.title}
            detail={r.group}
            last={i === items.length - 1}
            onPress={() =>
              router.push(
                `/exercise?recipe=${r.id}${params.idea ? "&idea=" + params.idea : ""}` as any,
              )
            }
          />
        ))}
      </Group>
      {!items.length ? (
        <Secondary>
          No matching exercises. Try another word or category.
        </Secondary>
      ) : null}
      <Caption style={{ marginTop: 24 }}>
        These are guided writing methods. Your responses are saved with their
        source thought. No model writes or scores your ideas.
      </Caption>
    </Screen>
  );
}
