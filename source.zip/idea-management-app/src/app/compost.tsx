import React from "react";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import {
  PageHeader,
  Panel,
  Field,
  IdeaPicker,
} from "@/components/studio/StudioUI";
import { Button } from "@/components/ui/Button";
import { H2, Secondary } from "@/components/ui/Typography";
import { ToggleRow, DraftStatus } from "@/components/ui/IOS";
import { useLoad, useAction, useDraftForm } from "@/hooks/useAsync";
import { listIdeas } from "@/db/repositories/ideas";
import { extractIngredient } from "@/db/repositories/thinking";
export default function Compost() {
  const action = useAction(),
    load = useLoad(() => listIdeas({ limit: 300, includeArchived: true })),
    form = useDraftForm("compost", {
      idea: "",
      title: "",
      excerpt: "",
      why: "",
      retire: false,
    });
  return (
    <Screen>
      <PageHeader
        back
        title="Intellectual compost"
        subtitle="Stopping a project does not waste what you learned."
      />
      <Panel>
        {load.data ? (
          <IdeaPicker
            ideas={load.data}
            value={form.value.idea}
            onChange={(idea) => form.setValue((v) => ({ ...v, idea }))}
          />
        ) : null}
        <Field
          label="Name the ingredient"
          value={form.value.title}
          onChangeText={(title) => form.setValue((v) => ({ ...v, title }))}
        />
        <Field
          label="The material worth keeping"
          multiline
          value={form.value.excerpt}
          onChangeText={(excerpt) => form.setValue((v) => ({ ...v, excerpt }))}
        />
        <Field
          label="Reusable because…"
          multiline
          value={form.value.why}
          onChangeText={(why) => form.setValue((v) => ({ ...v, why }))}
        />
        <ToggleRow
          title="Also archive the source idea"
          detail="Keep its history and links. You can return to it later."
          value={form.value.retire}
          onChange={(retire) => form.setValue((v) => ({ ...v, retire }))}
        />
        <DraftStatus status={form.status} />
        <Button
          label="Rescue this ingredient"
          disabled={
            !form.ready ||
            !form.value.idea ||
            !form.value.title.trim() ||
            !form.value.excerpt.trim() ||
            !form.value.why.trim()
          }
          loading={action.busy}
          onPress={() =>
            action.run(async () => {
              await extractIngredient(
                form.value.idea,
                form.value.title,
                form.value.excerpt,
                form.value.why,
                form.value.retire,
              );
              await form.clear();
              router.replace("/shelves" as any);
            }, "Ingredient rescued")
          }
        />
      </Panel>
    </Screen>
  );
}
