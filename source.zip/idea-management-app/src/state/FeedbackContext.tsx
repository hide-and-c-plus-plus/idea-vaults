import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { createContext, useContext, useEffect, useState } from "react";
import { Pressable, StyleSheet, Text } from "react-native";
import { colors } from "@/theme/tokens";
const Context = createContext<(message: string, error?: boolean) => void>(
  () => {},
);
export function FeedbackProvider({ children }: { children: React.ReactNode }) {
  const styles = useThemedStyles(baseStyles);
  const colors = useColors();

  const [notice, setNotice] = useState<{
    text: string;
    error: boolean;
    stamp: number;
  } | null>(null);
  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(null), 5000);
    return () => clearTimeout(timer);
  }, [notice]);
  return (
    <Context.Provider
      value={(text, error = false) =>
        setNotice({ text, error, stamp: Date.now() })
      }
    >
      {children}
      {notice ? (
        <Pressable
          accessibilityRole="alert"
          accessibilityLiveRegion="polite"
          onPress={() => setNotice(null)}
          style={[styles.toast, notice.error && { borderColor: colors.danger }]}
        >
          <Text style={styles.text}>
            {notice.error ? "!  " : "✓  "}
            {notice.text}
          </Text>
        </Pressable>
      ) : null}
    </Context.Provider>
  );
}
export const useFeedback = () => useContext(Context);
const styles = StyleSheet.create({
  toast: {
    position: "absolute",
    bottom: 105,
    left: 20,
    right: 20,
    maxWidth: 600,
    alignSelf: "center",
    borderWidth: 1,
    borderColor: colors.success,
    backgroundColor: colors.surfaceRaised,
    borderRadius: 16,
    padding: 16,
    elevation: 8,
  },
  text: { fontSize: 14, lineHeight: 21, color: colors.textPrimary },
});

const baseStyles = styles;
