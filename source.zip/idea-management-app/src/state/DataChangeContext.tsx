import React, {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";

const DataChangeContext = createContext<{ epoch: number; bump: () => void }>({
  epoch: 0,
  bump: () => {},
});

export function DataChangeProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [epoch, setEpoch] = useState(0);
  const bump = useCallback(() => setEpoch((x) => x + 1), []);
  const value = useMemo(() => ({ epoch, bump }), [epoch, bump]);
  return (
    <DataChangeContext.Provider value={value}>
      {children}
    </DataChangeContext.Provider>
  );
}

export function useDataChange() {
  return useContext(DataChangeContext);
}
