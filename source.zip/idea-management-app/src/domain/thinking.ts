export const CARD_KINDS = {
  assumption: "Assumption",
  evidence: "Evidence",
  question: "Open question",
  gap: "Missing ingredient",
  observation: "Observation",
  mechanism: "Mechanism",
  constraint: "Constraint",
  concept: "Glossary entry",
  source: "Source receipt",
  decision: "Decision",
  ingredient: "Reusable ingredient",
  motif: "Motif",
  surprise: "Surprise",
  principle: "Creative principle",
  artifact: "Artefact",
  fictional: "Story-world rule",
} as const;
export type CardKind = keyof typeof CARD_KINDS;
export const EPISTEMIC = [
  "observed",
  "remembered",
  "inferred",
  "imagined",
  "quoted",
  "unresolved",
] as const;
export interface ThoughtCard {
  id: string;
  idea_id: string;
  idea_title?: string;
  kind: CardKind;
  title: string;
  body: string;
  interpretation: string;
  source_url: string;
  source_quote: string;
  epistemic: string;
  relation: string;
  related_card_id: string | null;
  status: string;
  created_at: number;
  updated_at: number;
}
export interface Checkpoint {
  id: string;
  idea_id: string;
  idea_title?: string;
  changed: string;
  open_question: string;
  restart: string;
  created_at: number;
}
export interface Inquiry {
  id: string;
  question: string;
  context: string;
  status: string;
  created_at: number;
  updated_at: number;
  member_count: number;
}
export interface Contract {
  idea_id: string;
  intent: string;
  mode: string;
  sanctuary: number;
  protected_phrase: string;
  revisit_when: string;
  context: string;
  updated_at: number;
}
export interface Revision {
  id: string;
  idea_id: string;
  parent_id: string | null;
  label: string;
  snapshot_json: string;
  created_at: number;
}
export interface WorkshopEntry {
  id: string;
  idea_id: string;
  recipe_id: string;
  title: string;
  fields_json: string;
  takeaway: string;
  created_at: number;
}
export interface Bridge {
  id: string;
  source_id: string;
  target_id: string;
  source_title: string;
  target_title: string;
  source_snapshot: string;
  target_snapshot: string;
  relation: string;
  rationale: string;
  status: string;
  feedback: string;
  link_id: string | null;
  created_at: number;
}
export interface Observation {
  id: string;
  experiment_id: string;
  observation: string;
  interpretation: string;
  alternatives: string;
  happened_at: number;
  created_at: number;
}
