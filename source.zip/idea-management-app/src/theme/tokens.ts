export const colors = {
  bg: "#F2F2F7",
  surface: "#FFFFFF",
  surfaceRaised: "#EAEAEE",
  surfaceHover: "#E4E4EB",
  border: "#D1D1D8",
  textPrimary: "#1C1C1E",
  textSecondary: "#626269",
  textMuted: "#696970",
  accent: "#005BC6",
  accentSoft: "#E7F0FF",
  success: "#247A42",
  warning: "#926000",
  danger: "#C32832",
  onAccent: "#FFFFFF",
  chrome: "#F9F9FB",
};
export type Palette = typeof colors;
export const darkColors: Palette = {
  bg: "#111113",
  surface: "#1C1C1F",
  surfaceRaised: "#2C2C30",
  surfaceHover: "#35353B",
  border: "#48484F",
  textPrimary: "#F5F5F7",
  textSecondary: "#B8B8C0",
  textMuted: "#A5A5AE",
  accent: "#8AB8FF",
  accentSoft: "#20314B",
  success: "#7ED89B",
  warning: "#EEC46D",
  danger: "#FF9CA3",
  onAccent: "#102038",
  chrome: "#1C1C20",
};
export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 20,
  xl: 24,
  xxl: 32,
} as const;
export const radius = { sm: 8, md: 12, lg: 20, pill: 999 } as const;
