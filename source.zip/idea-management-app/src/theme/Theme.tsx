import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { AccessibilityInfo, useColorScheme } from "react-native";
import { colors, darkColors, type Palette } from "./tokens";
import { getSetting, setSetting } from "@/db/repositories/creative";
type Appearance = "system" | "light" | "dark";
type Preferences = {
  appearance: Appearance;
  quiet: boolean;
  reduceMotion: boolean;
  privateScreen: boolean;
};
const defaults: Preferences = {
  appearance: "system",
  quiet: false,
  reduceMotion: false,
  privateScreen: false,
};
const Context = createContext({
  colors,
  dark: false,
  preferences: defaults,
  ready: false,
  update: async (p: Partial<Preferences>) => {},
});
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme();
  const [preferences, setPreferences] = useState(defaults),
    [ready, setReady] = useState(false),
    [systemMotion, setSystemMotion] = useState(false);
  useEffect(() => {
    getSetting("preferences_v3")
      .then((v) => {
        if (v)
          try {
            setPreferences({ ...defaults, ...JSON.parse(v) });
          } catch {}
      })
      .finally(() => setReady(true));
    AccessibilityInfo.isReduceMotionEnabled().then(setSystemMotion);
    const sub = AccessibilityInfo.addEventListener(
      "reduceMotionChanged",
      setSystemMotion,
    );
    return () => sub.remove();
  }, []);
  const dark =
    preferences.appearance === "dark" ||
    (preferences.appearance === "system" && system === "dark");
  const update = async (p: Partial<Preferences>) => {
    const next = { ...preferences, ...p };
    await setSetting("preferences_v3", JSON.stringify(next));
    setPreferences(next);
  };
  return (
    <Context.Provider
      value={{
        colors: dark ? darkColors : colors,
        dark,
        preferences: {
          ...preferences,
          reduceMotion: preferences.reduceMotion || systemMotion,
        },
        ready,
        update,
      }}
    >
      {children}
    </Context.Provider>
  );
}
export const useTheme = () => useContext(Context);
export const useColors = () => useTheme().colors;
// Remap static StyleSheet tokens at render time; old screens share the same semantic palette.
export function remapStyle<T>(value: T, palette: Palette): T {
  if (typeof value === "string") {
    for (const key of Object.keys(colors) as (keyof Palette)[]) {
      if (value === colors[key]) return palette[key] as T;
      if (value.startsWith(colors[key]) && value.length === 9)
        return (palette[key] + value.slice(7)) as T;
    }
    return value;
  }
  if (Array.isArray(value))
    return value.map((v) => remapStyle(v, palette)) as T;
  if (value && typeof value === "object")
    return Object.fromEntries(
      Object.entries(value).map(([k, v]) => [k, remapStyle(v, palette)]),
    ) as T;
  return value;
}
export function useThemedStyles<T>(base: T): T {
  const palette = useColors();
  return useMemo(() => remapStyle(base, palette), [base, palette]);
}
