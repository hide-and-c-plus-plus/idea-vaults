export const ARCHIVE_TABLES = [
  "categories",
  "ideas",
  "idea_blocks",
  "idea_events",
  "tags",
  "idea_tags",
  "idea_links",
  "attachments",
  "transcripts",
  "reminders",
  "resurfacing_events",
  "feedback_notes",
  "app_settings",
  "drafts",
  "projects",
  "project_ideas",
  "action_items",
  "experiments",
  "time_capsules",
  "focus_sessions",
  "review_entries",
  "saved_views",
  "thought_contracts",
  "thought_revisions",
  "session_checkpoints",
  "inquiries",
  "inquiry_members",
  "thought_cards",
  "workshop_entries",
  "custom_recipes",
  "bridge_proposals",
  "experiment_observations",
  "experiment_protocols",
  "discovery_sessions",
  "discovery_items",
  "audio_marks",
] as const;
export const MAX_ARCHIVE_BYTES = 32 * 1024 * 1024;
export const MAX_EXPANDED_BYTES = 96 * 1024 * 1024;
export function bytesToBase64(bytes: Uint8Array) {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 0x8000)
    binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return globalThis.btoa(binary);
}
export function base64ToBytes(base64: string) {
  const binary = globalThis.atob(base64);
  return Uint8Array.from(binary, (c) => c.charCodeAt(0));
}
