import * as FileSystem from "expo-file-system/legacy";
import * as DocumentPicker from "expo-document-picker";
import { unzipSync, strFromU8 } from "fflate";
import {
  ARCHIVE_TABLES,
  MAX_ARCHIVE_BYTES,
  MAX_EXPANDED_BYTES,
  base64ToBytes,
  bytesToBase64,
} from "./archive-schema";
import { getDb } from "@/db/database";
import { writeDb } from "@/db/write";
import { createId } from "@/utils/id";
import { syncFts } from "@/db/repositories/ideas";
export interface ArchivePreview {
  schema: number;
  exportedAt: string;
  data: Record<string, any[]>;
  files: Record<string, Uint8Array>;
  manifest: {
    files: Record<string, string>;
    missing: string[];
    draftFiles?: Record<string, string>;
  };
  ideaCount: number;
  mediaCount: number;
  warnings: string[];
}
export function inspectArchive(bytes: Uint8Array): ArchivePreview {
  if (bytes.length > MAX_ARCHIVE_BYTES)
    throw Error("Choose an archive smaller than 32 MB.");
  let expanded = 0,
    count = 0;
  const files = unzipSync(bytes, {
    filter: (entry) => {
      if (++count > 10000) throw Error("This archive has too many files.");
      const name = entry.name;
      if (
        name.startsWith("/") ||
        name.includes("\\") ||
        name.split("/").includes("..") ||
        name.includes("\0")
      )
        throw Error("Unsafe archive path.");
      expanded += entry.originalSize;
      if (expanded > MAX_EXPANDED_BYTES)
        throw Error("Expanded archive exceeds the 96 MB safety limit.");
      if (name === "ideas-export.json" && entry.originalSize > 12 * 1024 * 1024)
        throw Error("Vault metadata is too large.");
      return true;
    },
  });
  if (!files["ideas-export.json"] || !files["attachment-manifest.json"])
    throw Error("This is not an Idea Vault archive.");
  const payload = JSON.parse(strFromU8(files["ideas-export.json"])),
    manifest = JSON.parse(strFromU8(files["attachment-manifest.json"]));
  if (![2, 3].includes(payload.schema))
    throw Error("This archive uses an unsupported schema.");
  if (
    !payload.data ||
    typeof payload.data !== "object" ||
    !Array.isArray(payload.data.ideas)
  )
    throw Error("Invalid vault metadata.");
  for (const [table, rows] of Object.entries(payload.data)) {
    if (!(ARCHIVE_TABLES as readonly string[]).includes(table))
      throw Error("Unknown archive table: " + table);
    if (!Array.isArray(rows) || rows.length > 100000)
      throw Error("Invalid archive records.");
    for (const row of rows)
      if (
        !row ||
        typeof row !== "object" ||
        Array.isArray(row) ||
        Object.values(row).some(
          (v) => v !== null && !["string", "number"].includes(typeof v),
        )
      )
        throw Error("Invalid record values.");
  }
  if (
    !manifest.files ||
    typeof manifest.files !== "object" ||
    Array.isArray(manifest.files) ||
    !Array.isArray(manifest.missing)
  )
    throw Error("Invalid attachment manifest.");
  const warnings: string[] = [];
  for (const [id, path] of Object.entries(manifest.files))
    if (
      typeof path !== "string" ||
      !/^attachments\/[A-Za-z0-9_.-]+$/.test(path) ||
      !files[path]
    )
      throw Error("An attachment is missing or has an unsafe path: " + id);
  for (const [uri, path] of Object.entries(manifest.draftFiles ?? {}))
    if (
      typeof path !== "string" ||
      !/^draft-media\/[A-Za-z0-9_.-]+$/.test(path) ||
      !files[path]
    )
      throw Error("Invalid draft media.");
  const missing = (payload.data.attachments ?? []).filter(
    (a: any) => !manifest.files[a.id],
  ).length;
  if (missing)
    warnings.push(
      `${missing} original media files were missing when this archive was created.`,
    );
  if (payload.schema === 2)
    warnings.push(
      "Older archive: capture drafts may have device-local media references.",
    );
  warnings.push(
    "Scheduled reminders are restored as records; use each reminder screen to schedule them on this device.",
  );
  return {
    schema: payload.schema,
    exportedAt: String(payload.exportedAt ?? ""),
    data: payload.data,
    files,
    manifest,
    ideaCount: payload.data.ideas.length,
    mediaCount: Object.keys(manifest.files).length,
    warnings,
  };
}
export async function pickArchive() {
  const pick = await DocumentPicker.getDocumentAsync({
    type: ["application/zip", "application/x-zip-compressed"],
    copyToCacheDirectory: true,
  });
  if (pick.canceled || !pick.assets[0]) return null;
  const asset = pick.assets[0];
  if (asset.size && asset.size > MAX_ARCHIVE_BYTES)
    throw Error("Choose an archive smaller than 32 MB.");
  const info = await FileSystem.getInfoAsync(asset.uri);
  if (!info.exists || ("size" in info && info.size > MAX_ARCHIVE_BYTES))
    throw Error("Archive missing or too large.");
  return inspectArchive(
    base64ToBytes(
      await FileSystem.readAsStringAsync(asset.uri, {
        encoding: FileSystem.EncodingType.Base64,
      }),
    ),
  );
}
export async function restoreArchive(preview: ArchivePreview) {
  // Always additive. Colliding IDs become copies, and relationships follow the copy.
  const directory = `${FileSystem.documentDirectory}restored/${createId("archive")}/`;
  await FileSystem.makeDirectoryAsync(directory, { intermediates: true });
  const mediaMap = new Map<string, string>();
  try {
    for (const [id, path] of Object.entries(preview.manifest.files)) {
      const bytes = preview.files[path]!;
      const uri = directory + path.split("/").pop();
      await FileSystem.writeAsStringAsync(uri, bytesToBase64(bytes), {
        encoding: FileSystem.EncodingType.Base64,
      });
      const info = await FileSystem.getInfoAsync(uri);
      if (!info.exists) throw Error("Could not stage restored media.");
      mediaMap.set(id, uri);
    }
    const draftMap = new Map<string, string>();
    for (const [original, path] of Object.entries(
      preview.manifest.draftFiles ?? {},
    )) {
      const uri = directory + path.split("/").pop();
      await FileSystem.writeAsStringAsync(
        uri,
        bytesToBase64(preview.files[path]!),
        { encoding: FileSystem.EncodingType.Base64 },
      );
      draftMap.set(original, uri);
    }
    return await writeDb(async (db) => {
      await db.execAsync("PRAGMA defer_foreign_keys=ON");
      const rows: Record<string, any[]> = {},
        idMap = new Map<string, string>();
      // Discover only known schema columns. No identifier in SQL comes from archive input.
      const schemas = new Map<string, { name: string; pk: number }[]>();
      const foreign = new Map<
        string,
        { from: string; table: string; to: string }[]
      >();
      for (const table of ARCHIVE_TABLES) {
        const schema = await db.getAllAsync<{ name: string; pk: number }>(
          `PRAGMA table_info(${table})`,
        );
        schemas.set(table, schema);
        foreign.set(
          table,
          await db.getAllAsync(`PRAGMA foreign_key_list(${table})`),
        );
        rows[table] = (preview.data[table] ?? []).map((r) => ({ ...r }));
        for (const row of rows[table]!) {
          if (Object.keys(row).some((k) => !schema.some((c) => c.name === k)))
            throw Error(`Unsupported column in ${table}.`);
          if (row.id !== undefined) {
            if (typeof row.id !== "string" || row.id.length > 200)
              throw Error("Invalid record identity.");
            if (
              table !== "categories" &&
              (await db.getFirstAsync(
                `SELECT id FROM ${table} WHERE id=?`,
                row.id,
              ))
            )
              idMap.set(
                row.id,
                table === "drafts" &&
                  (row.id.startsWith("capture:") || row.id === "quick-capture")
                  ? `capture:${createId("restored")}`
                  : createId("restored"),
              );
          }
        }
      }
      const replaceRefs = (value: any): any => {
        if (typeof value === "string")
          return idMap.get(value) ?? draftMap.get(value) ?? value;
        if (Array.isArray(value)) return value.map(replaceRefs);
        if (value && typeof value === "object")
          return Object.fromEntries(
            Object.entries(value).map(([k, v]) => [k, replaceRefs(v)]),
          );
        return value;
      };
      // Disambiguate custom tag names while keeping the incoming exact relationships.
      for (const tag of rows.tags ?? []) {
        const existing = await db.getFirstAsync<any>(
          "SELECT * FROM tags WHERE normalized_name=?",
          tag.normalized_name,
        );
        if (existing) idMap.set(tag.id, existing.id);
      }
      for (const table of ARCHIVE_TABLES) {
        if (table === "app_settings") continue; // Device preferences never overwrite the current owner's choices.
        const schema = schemas.get(table)!;
        for (const raw of rows[table] ?? []) {
          const row = { ...raw };
          if (
            table === "categories" &&
            (await db.getFirstAsync(
              "SELECT id FROM categories WHERE id=?",
              row.id,
            ))
          )
            continue;
          if (
            table === "tags" &&
            (await db.getFirstAsync(
              "SELECT id FROM tags WHERE normalized_name=?",
              row.normalized_name,
            ))
          )
            continue;
          if (row.id) row.id = idMap.get(row.id) ?? row.id;
          for (const fk of foreign.get(table) ?? [])
            if (typeof row[fk.from] === "string")
              row[fk.from] = idMap.get(row[fk.from]) ?? row[fk.from];
          if (table === "ideas")
            row.original_capture_id =
              idMap.get(row.original_capture_id) ?? row.original_capture_id;
          if (table === "idea_blocks" && row.attachment_id)
            row.attachment_id =
              idMap.get(row.attachment_id) ?? row.attachment_id;
          for (const key of [
            "snapshot_json",
            "metadata_json",
            "payload_json",
            "segments_json",
          ])
            if (row[key]) {
              try {
                row[key] = JSON.stringify(replaceRefs(JSON.parse(row[key])));
              } catch {
                throw Error(`Invalid ${key} in archive.`);
              }
            }
          if (table === "workshop_entries")
            row.recipe_id = idMap.get(row.recipe_id) ?? row.recipe_id;
          if (table === "attachments")
            row.local_uri =
              mediaMap.get(raw.id) ?? directory + "missing-" + row.id;
          if (table === "drafts")
            row.attachment_uri =
              draftMap.get(row.attachment_uri) ?? row.attachment_uri;
          if (table === "reminders") row.notification_id = null;
          if (table === "focus_sessions" && row.status === "running") {
            row.status = "ended";
            row.completed_at = Date.now();
          }
          if (table === "discovery_sessions" && !row.completed_at)
            row.completed_at = Date.now();
          const columns = schema
            .filter((c) => Object.hasOwn(row, c.name))
            .map((c) => c.name);
          if (!columns.length) throw Error("An archive record is empty.");
          await db.runAsync(
            `INSERT INTO ${table}(${columns.join(",")}) VALUES(${columns.map(() => "?").join(",")})`,
            ...columns.map((k) => row[k]),
          );
        }
      }
      const errors = await db.getAllAsync("PRAGMA foreign_key_check");
      if (errors.length)
        throw Error(
          "Archive relationships are incomplete. Nothing was imported.",
        );
      for (const idea of rows.ideas ?? [])
        await syncFts(db, idMap.get(idea.id) ?? idea.id);
      await db.runAsync(
        "INSERT INTO app_settings(key,value) VALUES('last_restore',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        JSON.stringify({
          at: Date.now(),
          ideas: preview.ideaCount,
          missing: preview.manifest.missing.length,
        }),
      );
      return preview.ideaCount;
    });
  } catch (e) {
    await FileSystem.deleteAsync(directory, { idempotent: true }).catch(
      () => {},
    );
    throw e;
  }
}
