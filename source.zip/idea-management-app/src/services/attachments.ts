import * as FileSystem from "expo-file-system/legacy";
import * as ImagePicker from "expo-image-picker";
import * as DocumentPicker from "expo-document-picker";
import { createId } from "@/utils/id";

async function ensureAttachmentDir() {
  const dir = `${FileSystem.documentDirectory}attachments/`;
  const info = await FileSystem.getInfoAsync(dir);
  if (!info.exists)
    await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
  return dir;
}

function extensionFromUri(uri: string, fallback: string) {
  const clean = uri.split("?")[0] ?? uri;
  const match = clean.match(/\.([a-zA-Z0-9]{1,8})$/);
  return match?.[1] ?? fallback;
}

export async function importImageAttachment() {
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ["images"],
    quality: 0.9,
  });
  if (result.canceled || !result.assets[0]) return null;
  const asset = result.assets[0];
  const dir = await ensureAttachmentDir();
  const destination = `${dir}${createId("image")}.${extensionFromUri(asset.uri, "jpg")}`;
  await FileSystem.copyAsync({ from: asset.uri, to: destination });
  return { uri: destination, mimeType: asset.mimeType ?? "image/jpeg" };
}

export async function captureImageAttachment() {
  const permission = await ImagePicker.requestCameraPermissionsAsync();
  if (!permission.granted)
    throw new Error("Camera permission was not granted.");
  const result = await ImagePicker.launchCameraAsync({
    mediaTypes: ["images"],
    quality: 0.9,
  });
  if (result.canceled || !result.assets[0]) return null;
  const asset = result.assets[0];
  const dir = await ensureAttachmentDir();
  const destination = `${dir}${createId("camera")}.${extensionFromUri(asset.uri, "jpg")}`;
  await FileSystem.copyAsync({ from: asset.uri, to: destination });
  return { uri: destination, mimeType: asset.mimeType ?? "image/jpeg" };
}

export async function importFileAttachment() {
  const result = await DocumentPicker.getDocumentAsync({
    copyToCacheDirectory: true,
    multiple: false,
  });
  if (result.canceled || !result.assets[0]) return null;
  const asset = result.assets[0];
  const dir = await ensureAttachmentDir();
  const safeName = asset.name.replace(/[^a-zA-Z0-9._-]+/g, "_");
  const destination = `${dir}${createId("file")}_${safeName}`;
  await FileSystem.copyAsync({ from: asset.uri, to: destination });
  return {
    uri: destination,
    mimeType: asset.mimeType ?? null,
    name: asset.name,
  };
}

export async function persistSharedAttachment(
  uri: string,
  name: string | null | undefined,
  fallbackExtension = "bin",
) {
  const dir = await ensureAttachmentDir();
  const safeName = (
    name || `${createId("shared")}.${extensionFromUri(uri, fallbackExtension)}`
  ).replace(/[^a-zA-Z0-9._-]+/g, "_");
  const destination = `${dir}${createId("shared")}_${safeName}`;
  await FileSystem.copyAsync({ from: uri, to: destination });
  return destination;
}
