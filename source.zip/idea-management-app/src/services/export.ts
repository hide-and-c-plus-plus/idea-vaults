import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { ARCHIVE_TABLES, MAX_EXPANDED_BYTES } from "./archive-schema";
import { strToU8, zipSync } from "fflate";
import { writeDb } from "@/db/write";
import { getDb } from "@/db/database";
import { getIdea } from "@/db/repositories/ideas";
import { listActions, listExperiments } from "@/db/repositories/creative";
import type { Idea } from "@/domain/types";

function bytesToBase64(bytes: Uint8Array) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(
      ...bytes.subarray(i, Math.min(i + chunk, bytes.length)),
    );
  }
  return globalThis.btoa(binary);
}

function base64ToBytes(base64: string) {
  const binary = globalThis.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function safeName(value: string) {
  return (
    value
      .replace(/[\\/:*?"<>|]+/g, "-")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 80) || "Untitled idea"
  );
}

function ideaMarkdown(idea: any, blocks: any[], tags: any[]) {
  const lines = [
    `# ${idea.title || "Untitled idea"}`,
    "",
    `- Stage: ${idea.stage}`,
    `- Created: ${new Date(idea.created_at).toISOString()}`,
    `- Updated: ${new Date(idea.updated_at).toISOString()}`,
    `- Tags: ${tags.map((x) => x.name).join(", ") || "—"}`,
    "",
  ];
  if (idea.summary) lines.push("## Summary", "", idea.summary, "");
  for (const block of blocks) {
    if (block.type === "text" && block.body_text) {
      lines.push(
        block.is_original ? "## Original capture" : "## Thought",
        "",
        block.body_text,
        "",
      );
    } else if (block.attachment_id) {
      lines.push(`- ${block.type} attachment: ${block.attachment_id}`);
    }
  }
  if (
    idea.problem ||
    idea.audience ||
    idea.next_experiment ||
    idea.next_action ||
    idea.done_definition
  ) {
    lines.push("", "## Development", "");
    if (idea.problem)
      lines.push(`**Problem / opportunity:** ${idea.problem}`, "");
    if (idea.audience) lines.push(`**Who benefits:** ${idea.audience}`, "");
    if (idea.next_experiment)
      lines.push(`**Smallest test:** ${idea.next_experiment}`, "");
    if (idea.next_action)
      lines.push(`**Next action:** ${idea.next_action}`, "");
    if (idea.done_definition)
      lines.push(`**Done looks like:** ${idea.done_definition}`, "");
  }
  if (idea.why_now) lines.push("## Why now", "", idea.why_now, "");
  if (idea.risks) lines.push("## Risks", "", idea.risks, "");
  return lines.join("\n");
}

export async function exportAllData() {
  const db = await getDb();
  const tables = ARCHIVE_TABLES;
  const data: Record<string, unknown[]> = {};
  await writeDb(async (tx) => {
    for (const table of tables)
      data[table] = await tx.getAllAsync(`SELECT * FROM ${table}`);
  });
  const ideas = data.ideas as Idea[];
  const blocks = data.idea_blocks as any[];
  const tags = data.tags as any[];
  const ideaTags = data.idea_tags as any[];
  const attachments = data.attachments as any[];

  const archive: Record<string, Uint8Array> = {};
  archive["ideas-export.json"] = strToU8(
    JSON.stringify(
      { exportedAt: new Date().toISOString(), schema: 3, data },
      null,
      2,
    ),
  );

  for (const idea of ideas) {
    const ideaBlocks = blocks
      .filter((b) => b.idea_id === idea.id)
      .sort((a, b) => a.position - b.position || a.created_at - b.created_at);
    const tagIds = ideaTags
      .filter((it) => it.idea_id === idea.id)
      .map((it) => it.tag_id);
    const ideaTagRows = tags.filter((t) => tagIds.includes(t.id));
    archive[
      `markdown/${safeName(idea.title || idea.id)}-${idea.id.slice(-6)}.md`
    ] = strToU8(
      ideaMarkdown(idea, ideaBlocks, ideaTagRows) +
        workbenchMarkdown(
          idea.id,
          data.action_items as any[],
          data.experiments as any[],
        ),
    );
  }

  const missingAttachments: string[] = [];
  let totalMediaBytes = 0;
  const attachmentPaths: Record<string, string> = {};
  for (const attachment of attachments) {
    try {
      const info = await FileSystem.getInfoAsync(attachment.local_uri);
      if (!info.exists) {
        missingAttachments.push(attachment.id);
        continue;
      }
      if ("size" in info) totalMediaBytes += info.size;
      if (totalMediaBytes > MAX_EXPANDED_BYTES / 2)
        throw new Error(
          "Media is too large for an in-memory archive. Export selected thoughts instead.",
        );
      const base64 = await FileSystem.readAsStringAsync(attachment.local_uri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      const ext = (attachment.local_uri.split(".").pop() || "bin").replace(
        /[^a-zA-Z0-9]/g,
        "",
      );
      const path = `attachments/${attachment.id}.${ext || "bin"}`;
      archive[path] = base64ToBytes(base64);
      attachmentPaths[attachment.id] = path;
    } catch (e) {
      if (String(e).includes("too large")) throw e;
      missingAttachments.push(attachment.id);
    }
  }

  const draftFiles: Record<string, string> = {};
  const draftUris = new Set<string>();
  const visit = (v: unknown) => {
    if (typeof v === "string" && v.startsWith("file://")) draftUris.add(v);
    else if (v && typeof v === "object") Object.values(v).forEach(visit);
  };
  for (const draft of data.drafts as any[]) {
    visit(draft.attachment_uri);
    if (draft.metadata_json)
      try {
        visit(JSON.parse(draft.metadata_json));
      } catch {}
  }
  for (const uri of draftUris) {
    try {
      const info = await FileSystem.getInfoAsync(uri);
      if (!info.exists) continue;
      if ("size" in info) totalMediaBytes += info.size;
      if (totalMediaBytes > MAX_EXPANDED_BYTES / 2)
        throw Error("Media is too large for an in-memory archive.");
      const path = `draft-media/draft-${Object.keys(draftFiles).length}.bin`;
      archive[path] = base64ToBytes(
        await FileSystem.readAsStringAsync(uri, {
          encoding: FileSystem.EncodingType.Base64,
        }),
      );
      draftFiles[uri] = path;
    } catch (e) {
      if (String(e).includes("too large")) throw e;
    }
  }
  archive["attachment-manifest.json"] = strToU8(
    JSON.stringify(
      { files: attachmentPaths, missing: missingAttachments, draftFiles },
      null,
      2,
    ),
  );
  archive["README.txt"] = strToU8(
    "Idea Vault 3 archive. Restore through Settings > Recovery. This archive includes the canonical tables, revisions, evidence, notebooks, and media. Restore is additive; ID conflicts become copies. Existing device preferences are retained. Notification IDs are cleared and running sessions end on import. Media listed as missing cannot be reconstructed. Capsules and all other content are plain text; this archive is not encrypted. Keep it somewhere private.",
  );
  const zip = zipSync(archive, { level: 6 });
  const uri = `${FileSystem.cacheDirectory}idea-vault-export-${new Date().toISOString().slice(0, 10)}.zip`;
  await FileSystem.writeAsStringAsync(uri, bytesToBase64(zip), {
    encoding: FileSystem.EncodingType.Base64,
  });
  if (zip.length > 32 * 1024 * 1024)
    throw Error(
      "Archive exceeds the 32 MB restore limit. Use selective Markdown export for now.",
    );
  await writeDb(async (tx) => {
    await tx.runAsync(
      "INSERT INTO app_settings(key,value) VALUES('last_export',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
      JSON.stringify({
        at: Date.now(),
        missing: missingAttachments.length,
        bytes: zip.length,
      }),
    );
  });
  if (await Sharing.isAvailableAsync())
    await Sharing.shareAsync(uri, {
      mimeType: "application/zip",
      dialogTitle: "Export Idea Vault",
    });
  return uri;
}

function workbenchMarkdown(id: string, actions: any[], experiments: any[]) {
  const lines: string[] = [];
  const tasks = actions.filter((a) => a.idea_id === id),
    tests = experiments.filter((e) => e.idea_id === id);
  if (tasks.length)
    lines.push(
      "",
      "## Next moves",
      "",
      ...tasks.map((a) => `- [${a.done_at ? "x" : " "}] ${a.body}`),
      "",
    );
  for (const e of tests)
    lines.push(
      "",
      "## Experiment",
      "",
      `**Prediction:** ${e.hypothesis}`,
      "",
      `**Test:** ${e.method}`,
      "",
      `**Success signal:** ${e.success_signal}`,
      "",
      `**Outcome:** ${e.verdict}`,
      "",
      `**Observed:** ${e.result || "Not recorded"}`,
      "",
    );
  return lines.join("\n");
}
export async function singleIdeaMarkdown(id: string) {
  const idea = await getIdea(id);
  if (!idea) throw new Error("Idea not found.");
  const db = await getDb();
  const cardRows = await db.getAllAsync<any>(
    "SELECT * FROM thought_cards WHERE idea_id=? ORDER BY created_at",
    id,
  );
  const checkpointRows = await db.getAllAsync<any>(
    "SELECT * FROM session_checkpoints WHERE idea_id=? ORDER BY created_at DESC LIMIT 1",
    id,
  );
  const entries = await db.getAllAsync<any>(
    "SELECT * FROM workshop_entries WHERE idea_id=? ORDER BY created_at",
    id,
  );
  const extra = [
    ...cardRows.map(
      (c) =>
        `\n## ${c.kind}: ${c.title}\n\n${c.body}\n\nInterpretation: ${c.interpretation}\n\nStatus: ${c.epistemic} / ${c.status}\n\nSource: ${c.source_url}\n\n${c.source_quote}\n`,
    ),
    ...checkpointRows.map(
      (c) =>
        `\n## Resume here\n\n${c.restart}\n\nOpen question: ${c.open_question}\n`,
    ),
    ...entries.map(
      (e) =>
        `\n## ${e.title}\n\n${Object.entries(JSON.parse(e.fields_json))
          .map(([k, v]) => `${k}\n\n${v}`)
          .join("\n\n")}\n\nTakeaway: ${e.takeaway}\n`,
    ),
  ].join("\n");
  return (
    ideaMarkdown(idea, idea.blocks, idea.tags) +
    extra +
    workbenchMarkdown(id, await listActions(id), await listExperiments(id))
  );
}
