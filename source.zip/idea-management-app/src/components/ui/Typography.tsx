import { useColors, useThemedStyles } from "@/theme/Theme";
import React from "react";
import { Text, type TextProps, StyleSheet } from "react-native";
import { colors } from "@/theme/tokens";

export function Display(props: TextProps) {
  const styles = useThemedStyles(baseStyles);

  return <Text {...props} style={[styles.display, props.style]} />;
}
export function H1(props: TextProps) {
  const styles = useThemedStyles(baseStyles);

  return <Text {...props} style={[styles.h1, props.style]} />;
}
export function H2(props: TextProps) {
  const styles = useThemedStyles(baseStyles);

  return <Text {...props} style={[styles.h2, props.style]} />;
}
export function Body(props: TextProps) {
  const styles = useThemedStyles(baseStyles);

  return <Text {...props} style={[styles.body, props.style]} />;
}
export function Secondary(props: TextProps) {
  const styles = useThemedStyles(baseStyles);

  return <Text {...props} style={[styles.secondary, props.style]} />;
}
export function Caption(props: TextProps) {
  const styles = useThemedStyles(baseStyles);

  return <Text {...props} style={[styles.caption, props.style]} />;
}

const styles = StyleSheet.create({
  display: {
    color: colors.textPrimary,
    fontSize: 34,
    lineHeight: 41,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  h1: {
    color: colors.textPrimary,
    fontSize: 28,
    lineHeight: 34,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  h2: {
    color: colors.textPrimary,
    fontSize: 20,
    lineHeight: 26,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  body: { color: colors.textPrimary, fontSize: 17, lineHeight: 25 },
  secondary: { color: colors.textSecondary, fontSize: 15, lineHeight: 22 },
  caption: { color: colors.textMuted, fontSize: 12, lineHeight: 16 },
});

const baseStyles = styles;
