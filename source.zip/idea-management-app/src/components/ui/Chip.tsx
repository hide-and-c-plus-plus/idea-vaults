import { useColors, useThemedStyles } from "@/theme/Theme";
import React from "react";
import { Pressable, StyleSheet, Text } from "react-native";
import { colors, radius, spacing } from "@/theme/tokens";
export function Chip({
  label,
  selected = false,
  onPress,
}: {
  label: string;
  selected?: boolean;
  onPress?: () => void;
}) {
  const styles = useThemedStyles(baseStyles);

  if (!onPress)
    return (
      <Text style={[styles.chip, selected && styles.selected]}>{label}</Text>
    );
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      aria-pressed={selected}
      onPress={onPress}
      style={({ pressed }) => [
        styles.wrap,
        selected && styles.selectedWrap,
        pressed && { opacity: 0.75 },
      ]}
    >
      <Text style={[styles.text, selected && styles.selectedText]}>
        {label}
      </Text>
    </Pressable>
  );
}
const styles = StyleSheet.create({
  wrap: {
    minHeight: 48,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.surface,
  },
  selectedWrap: {
    backgroundColor: colors.accentSoft,
    borderColor: colors.accent,
  },
  text: { color: colors.textSecondary, fontSize: 13, fontWeight: "500" },
  selectedText: { color: colors.textPrimary },
  chip: {
    color: colors.textSecondary,
    fontSize: 12,
    backgroundColor: colors.surfaceRaised,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: radius.pill,
    overflow: "hidden",
  },
  selected: { color: colors.textPrimary, backgroundColor: colors.accentSoft },
});

const baseStyles = styles;
