import { useColors, useThemedStyles, useTheme } from "@/theme/Theme";
import React from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  type ViewStyle,
} from "react-native";
import { colors, radius, spacing } from "@/theme/tokens";

export function Button({
  label,
  onPress,
  variant = "primary",
  disabled,
  loading,
  style,
}: {
  label: string;
  onPress: () => void;
  variant?: "primary" | "secondary" | "danger" | "ghost";
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
}) {
  const styles = useThemedStyles(baseStyles);
  const colors = useColors();
  const { preferences } = useTheme();

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      accessibilityState={{
        disabled: !!(disabled || loading),
        busy: !!loading,
      }}
      disabled={disabled || loading}
      onPress={onPress}
      style={({ pressed }) => [
        styles.base,
        styles[variant],
        pressed &&
          (preferences.reduceMotion ? { opacity: 0.72 } : styles.pressed),
        (disabled || loading) && styles.disabled,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator
          color={variant === "primary" ? colors.onAccent : colors.textSecondary}
        />
      ) : (
        <Text
          style={[
            styles.label,
            variant === "danger" && { color: colors.danger },
            variant === "primary" && { color: colors.onAccent },
          ]}
        >
          {label}
        </Text>
      )}
    </Pressable>
  );
}
const styles = StyleSheet.create({
  base: {
    minHeight: 48,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.md,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 0,
    borderColor: "transparent",
  },
  primary: { backgroundColor: colors.accent },
  secondary: {
    backgroundColor: colors.surfaceRaised,
    borderColor: colors.border,
  },
  danger: { backgroundColor: colors.surfaceRaised, borderColor: colors.danger },
  ghost: { backgroundColor: "transparent" },
  label: { color: colors.textPrimary, fontSize: 17, fontWeight: "600" },
  pressed: { opacity: 0.72, transform: [{ scale: 0.96 }] },
  disabled: { opacity: 0.45 },
});

const baseStyles = styles;
