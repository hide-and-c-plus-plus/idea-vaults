import React from "react";
import { Pressable, Text, View, Switch, type ColorValue } from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";
import { useTheme } from "@/theme/Theme";
import { Body, Caption, Secondary } from "./Typography";
export type IconName = React.ComponentProps<typeof Ionicons>["name"];
export function Icon({
  name,
  size = 23,
  color,
}: {
  name: IconName;
  size?: number;
  color?: ColorValue;
}) {
  const { colors } = useTheme();
  return (
    <Ionicons
      name={name}
      size={size}
      color={color ?? colors.accent}
      accessible={false}
    />
  );
}
export function IconButton({
  name,
  label,
  onPress,
}: {
  name: IconName;
  label: string;
  onPress: () => void;
}) {
  const { colors, preferences } = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => ({
        minWidth: 48,
        minHeight: 48,
        borderRadius: 24,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: colors.surface,
        opacity: pressed ? 0.65 : 1,
        transform: [{ scale: pressed && !preferences.reduceMotion ? 0.96 : 1 }],
      })}
    >
      <Icon name={name} />
    </Pressable>
  );
}
export function Group({ children }: { children: React.ReactNode }) {
  const { colors } = useTheme();
  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 20,
        overflow: "hidden",
      }}
    >
      {children}
    </View>
  );
}
export function Row({
  title,
  detail,
  icon,
  onPress,
  trailing,
  last = false,
}: {
  title: string;
  detail?: string;
  icon?: IconName;
  onPress?: () => void;
  trailing?: React.ReactNode;
  last?: boolean;
}) {
  const { colors } = useTheme();
  const content = (
    <>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: 14,
          minHeight: 70,
          paddingHorizontal: 16,
          paddingVertical: 14,
        }}
      >
        {icon ? (
          <View
            style={{
              width: 38,
              height: 38,
              borderRadius: 10,
              backgroundColor: colors.accentSoft,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Icon name={icon} size={21} />
          </View>
        ) : null}
        <View style={{ flex: 1, gap: 4 }}>
          <Body style={{ fontWeight: "500" }}>{title}</Body>
          {detail ? <Secondary>{detail}</Secondary> : null}
        </View>
        {trailing ??
          (onPress ? (
            <Icon name="chevron-forward" size={18} color={colors.textMuted} />
          ) : null)}
      </View>
      {!last ? (
        <View
          style={{
            height: 0.5,
            marginStart: icon ? 68 : 16,
            backgroundColor: colors.border,
          }}
        />
      ) : null}
    </>
  );
  return onPress ? (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      onPress={onPress}
      style={({ pressed }) => ({
        backgroundColor: pressed ? colors.surfaceRaised : colors.surface,
      })}
    >
      {content}
    </Pressable>
  ) : (
    <View>{content}</View>
  );
}
export function Segmented<T extends string>({
  options,
  value,
  onChange,
}: {
  options: readonly T[];
  value: T;
  onChange: (v: T) => void;
}) {
  const { colors } = useTheme();
  return (
    <View
      accessibilityRole="tablist"
      style={{
        flexDirection: "row",
        flexWrap: "wrap",
        backgroundColor: colors.surfaceRaised,
        padding: 4,
        borderRadius: 12,
        gap: 4,
      }}
    >
      {options.map((v) => (
        <Pressable
          key={v}
          accessibilityRole="tab"
          accessibilityState={{ selected: v === value }}
          aria-selected={v === value}
          onPress={() => onChange(v)}
          style={{
            flex: 1,
            minWidth: 65,
            minHeight: 44,
            backgroundColor: v === value ? colors.surface : "transparent",
            borderRadius: 9,
            alignItems: "center",
            justifyContent: "center",
            padding: 8,
          }}
        >
          <Text
            style={{
              color: v === value ? colors.textPrimary : colors.textSecondary,
              fontSize: 14,
              fontWeight: v === value ? "600" : "400",
            }}
          >
            {v}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}
export function ToggleRow({
  title,
  detail,
  value,
  onChange,
}: {
  title: string;
  detail?: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <Row
      title={title}
      detail={detail}
      trailing={
        <Switch
          accessibilityLabel={title}
          value={value}
          onValueChange={onChange}
        />
      }
    />
  );
}
export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <Caption
      style={{
        marginTop: 28,
        marginBottom: 10,
        marginStart: 4,
        fontSize: 13,
        fontWeight: "600",
        letterSpacing: 0.6,
      }}
    >
      {children}
    </Caption>
  );
}
export function DraftStatus({ status }: { status: string }) {
  return <Caption accessibilityLiveRegion="polite">{status}</Caption>;
}
