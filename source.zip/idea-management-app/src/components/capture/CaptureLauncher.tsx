import { useColors, useThemedStyles } from "@/theme/Theme";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { colors, radius, spacing } from "@/theme/tokens";
export function CaptureLauncher() {
  const styles = useThemedStyles(baseStyles);
  const colors = useColors();

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel="Capture an idea"
      onPress={() => router.push("/capture" as any)}
      style={({ pressed }) => [
        styles.box,
        pressed && { backgroundColor: colors.surfaceHover },
      ]}
    >
      <Text style={styles.prompt}>Capture an idea…</Text>
      <View style={styles.tools}>
        <Text style={styles.icon}>+</Text>
        <Text style={styles.icon}>●</Text>
      </View>
    </Pressable>
  );
}
const styles = StyleSheet.create({
  box: {
    minHeight: 82,
    backgroundColor: colors.surfaceRaised,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  prompt: { color: colors.textSecondary, fontSize: 17 },
  tools: { flexDirection: "row", gap: spacing.md },
  icon: {
    color: colors.textPrimary,
    fontSize: 20,
    minWidth: 28,
    textAlign: "center",
  },
});

const baseStyles = styles;
