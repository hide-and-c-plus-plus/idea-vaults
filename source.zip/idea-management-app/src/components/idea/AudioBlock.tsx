import { useColors, useThemedStyles } from "@/theme/Theme";
import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { useAudioPlayer, useAudioPlayerStatus } from "expo-audio";
import { useLoad } from "@/hooks/useAsync";
import { getDb } from "@/db/database";
import { Caption, Secondary } from "@/components/ui/Typography";
import { colors, radius, spacing } from "@/theme/tokens";

export function AudioBlock({
  uri,
  durationMs,
  attachmentId,
}: {
  uri: string;
  durationMs?: number | null;
  attachmentId?: string;
}) {
  const styles = useThemedStyles(baseStyles);

  const player = useAudioPlayer(uri);
  const status = useAudioPlayerStatus(player),
    playing = status.playing;
  const marks = useLoad(
    async () =>
      attachmentId
        ? (await getDb()).getAllAsync<{
            id: string;
            offset_ms: number;
            label: string;
          }>(
            "SELECT * FROM audio_marks WHERE attachment_id=? ORDER BY offset_ms",
            attachmentId,
          )
        : [],
    [attachmentId],
  );
  const toggle = () => {
    if (playing) {
      player.pause();
    } else {
      if (status.didJustFinish) void player.seekTo(0).then(() => player.play());
      else player.play();
    }
  };
  return (
    <View style={{ gap: 8 }}>
      <View style={styles.card}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={playing ? "Pause recording" : "Play recording"}
          onPress={toggle}
          style={styles.play}
        >
          <Text style={styles.glyph}>{playing ? "Ⅱ" : "▶"}</Text>
        </Pressable>
        <View style={{ flex: 1 }}>
          <Secondary>Voice capture</Secondary>
          <Caption>
            {durationMs
              ? `${Math.round(durationMs / 1000)} seconds`
              : "Original audio retained"}
          </Caption>
        </View>
        <Pressable
          onPress={() =>
            player.seekTo(Math.max(0, (player.currentTime ?? 0) - 15))
          }
          style={styles.seek}
        >
          <Caption>−15s</Caption>
        </Pressable>
        <Pressable
          onPress={() => player.seekTo((player.currentTime ?? 0) + 15)}
          style={styles.seek}
        >
          <Caption>+15s</Caption>
        </Pressable>
      </View>
      {marks.data?.map((m) => (
        <Pressable
          key={m.id}
          accessibilityRole="button"
          accessibilityLabel={`Play from ${m.label}`}
          style={{
            minHeight: 44,
            justifyContent: "center",
            paddingHorizontal: 12,
          }}
          onPress={() =>
            void player.seekTo(m.offset_ms / 1000).then(() => player.play())
          }
        >
          <Caption>
            {m.label} · {Math.floor(m.offset_ms / 1000)} seconds
          </Caption>
        </Pressable>
      ))}
    </View>
  );
}
const styles = StyleSheet.create({
  card: {
    minHeight: 72,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceRaised,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
  },
  play: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.accentSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  glyph: { color: colors.textPrimary, fontSize: 18 },
  seek: {
    minWidth: 48,
    minHeight: 48,
    alignItems: "center",
    justifyContent: "center",
  },
});

const baseStyles = styles;
