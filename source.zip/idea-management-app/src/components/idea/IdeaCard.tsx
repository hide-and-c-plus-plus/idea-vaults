import { useColors, useThemedStyles } from "@/theme/Theme";
import React from "react";
import { Pressable, StyleSheet, View } from "react-native";
import { router } from "expo-router";
import type { Idea } from "@/domain/types";
import { Body, Caption, Secondary } from "@/components/ui/Typography";
import { Chip } from "@/components/ui/Chip";
import { colors, radius, spacing } from "@/theme/tokens";
import { STAGE_LABELS } from "@/domain/creative";
import { formatRelative } from "@/utils/date";

export function IdeaCard({
  idea,
  reason,
  actions,
  onPress,
}: {
  idea: Idea;
  reason?: string;
  actions?: React.ReactNode;
  onPress?: () => void;
}) {
  const styles = useThemedStyles(baseStyles);
  const colors = useColors();

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Open ${idea.title || "idea"}`}
      onPress={onPress ?? (() => router.push(`/idea/${idea.id}` as any))}
      style={({ pressed }) => [
        styles.card,
        pressed && { backgroundColor: colors.surfaceHover },
      ]}
    >
      <View style={styles.top}>
        <Chip
          label={`${idea.is_starred ? "★ " : ""}${STAGE_LABELS[idea.stage] || idea.stage}`}
        />
        <Caption>{formatRelative(idea.updated_at)}</Caption>
      </View>
      <Body style={styles.title} numberOfLines={2}>
        {idea.title || "Untitled idea"}
      </Body>
      {idea.snippet ? (
        <Secondary numberOfLines={2}>
          {idea.snippet.replace(/[‹›]/g, "")}
        </Secondary>
      ) : null}
      {reason ? (
        <Caption style={{ color: colors.textSecondary }}>{reason}</Caption>
      ) : null}
      <Caption>
        {[
          idea.category_name,
          idea.energy === "low"
            ? "Gentle energy"
            : idea.energy === "deep"
              ? "Deep focus"
              : null,
        ]
          .filter(Boolean)
          .join(" · ")}
      </Caption>
      {actions ? <View style={styles.actions}>{actions}</View> : null}
    </Pressable>
  );
}
const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderWidth: 0,
    borderColor: colors.border,
    borderRadius: radius.lg,
    padding: spacing.lg,
    gap: spacing.sm,
    minHeight: 120,
  },
  top: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  title: { fontWeight: "600" },
  actions: { flexDirection: "row", gap: spacing.sm, marginTop: spacing.xs },
});

const baseStyles = styles;
