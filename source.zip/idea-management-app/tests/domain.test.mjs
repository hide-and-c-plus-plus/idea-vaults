import test from "node:test";
import assert from "node:assert/strict";
import {
  activityStreak,
  commonWords,
  dailyIndex,
  dayKeys,
  focusProgress,
  formatClock,
  localDayKey,
  relatedIdeas,
  ringPoints,
  safeFtsQuery,
  shuffle,
} from "../src/domain/logic.ts";
import {
  DAILY_PROMPTS,
  LENSES,
  REMIX_CARDS,
  TEMPLATES,
} from "../src/domain/prompts.ts";
test("daily prompts stay stable within a local date", () => {
  assert.equal(
    dailyIndex(21, new Date(2026, 9, 7, 0, 1)),
    dailyIndex(21, new Date(2026, 9, 7, 23, 59)),
  );
});
test("calendar arithmetic crosses years without missing days", () => {
  assert.deepEqual(dayKeys(3, new Date(2026, 0, 1, 12)), [
    "2025-12-30",
    "2025-12-31",
    "2026-01-01",
  ]);
});
test("a streak accepts yesterday and stops at the first gap", () => {
  const now = new Date(2026, 9, 7, 12);
  assert.equal(activityStreak(["2026-10-05", "2026-10-06"], now), 2);
  assert.equal(activityStreak(["2026-10-04", "2026-10-06"], now), 1);
  assert.equal(activityStreak(["2026-10-04"], now), 0);
});
test("early focus completion records elapsed seconds only", () => {
  assert.deepEqual(
    focusProgress(
      { started_at: 100000, ends_at: 400000, planned_seconds: 300 },
      170900,
    ),
    { elapsed: 70, remaining: 230, fraction: 70 / 300 },
  );
});
test("focus progress is bounded before the start and after the deadline", () => {
  const s = { started_at: 100000, ends_at: 400000, planned_seconds: 300 };
  assert.equal(focusProgress(s, 500000).elapsed, 300);
  assert.equal(focusProgress(s, 500000).remaining, 0);
  assert.equal(focusProgress(s, 90000).elapsed, 0);
  assert.equal(focusProgress(s, 90000).remaining, 300);
});
test("clock labels never have negative time", () => {
  assert.equal(formatClock(-10), "00:00");
  assert.equal(formatClock(1500), "25:00");
  assert.equal(formatClock(61), "01:01");
});
test("FTS input cannot inject operators or break on punctuation", () => {
  assert.equal(safeFtsQuery('" + OR:() *'), '"OR"*');
  assert.equal(safeFtsQuery("!?"), "");
  assert.equal(safeFtsQuery("café हिन्दी"), '"café"* AND "हिन्दी"*');
});
test("related suggestions explain concrete word overlaps and exclude themselves", () => {
  const a = { id: "a", title: "Repair a garden sensor" },
    b = { id: "b", title: "Garden sensor log" },
    c = { id: "c", title: "A music library" };
  const results = relatedIdeas(a, [a, b, c]);
  assert.equal(results.length, 1);
  assert.equal(results[0].idea.id, "b");
  assert.deepEqual(results[0].words, ["garden", "sensor"]);
});
test("common words ignore generic filler and duplicate words", () => {
  assert.deepEqual(commonWords("the garden garden app", "garden idea app"), [
    "garden",
  ]);
});
test("shuffle keeps every item without mutating its input", () => {
  const a = [1, 2, 3, 4];
  const b = shuffle(a, () => 0);
  assert.deepEqual(a, [1, 2, 3, 4]);
  assert.deepEqual([...b].sort(), a);
  assert.notDeepEqual(b, a);
});
test("map positions stay in bounds and are distinct", () => {
  const points = ringPoints(7, 320, 380);
  assert.equal(points.length, 7);
  assert.equal(new Set(points.map((p) => `${p.x}:${p.y}`)).size, 7);
  for (const p of points) {
    assert.ok(p.x >= 52 && p.x <= 268);
    assert.ok(p.y >= 54 && p.y <= 326);
  }
  assert.deepEqual(ringPoints(0, 320, 380), []);
});
test("creative decks have unique IDs and substantive prompts", () => {
  for (const deck of [DAILY_PROMPTS, LENSES, REMIX_CARDS, TEMPLATES])
    assert.equal(new Set(deck.map((c) => c.id)).size, deck.length);
  assert.equal(REMIX_CARDS.length, 7);
  assert.equal(TEMPLATES.length, 12);
});
