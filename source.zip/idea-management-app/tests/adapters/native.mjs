export const documentDirectory = "file:///test/documents/";
export const cacheDirectory = "file:///test/cache/";
export const EncodingType = { Base64: "base64" };
export const files = new Map();
export const canceled = [];
export const shared = [];
export const Platform = { OS: "android" };
export const AndroidImportance = { DEFAULT: 3 };
export const SchedulableTriggerInputTypes = { DATE: "date" };
export async function getInfoAsync(uri) {
  return { exists: files.has(uri), size: files.get(uri)?.length ?? 0 };
}
export async function deleteAsync(uri) {
  for (const key of [...files.keys()])
    if (key === uri || key.startsWith(uri)) files.delete(key);
}
export async function readAsStringAsync(uri) {
  if (!files.has(uri)) throw new Error("Missing test file");
  return files.get(uri);
}
export async function writeAsStringAsync(uri, body) {
  files.set(uri, body);
}
export async function cancelScheduledNotificationAsync(id) {
  canceled.push(id);
}
export async function isAvailableAsync() {
  return true;
}
export async function shareAsync(uri) {
  shared.push(uri);
}
export function setNotificationHandler() {}
export async function getPermissionsAsync() {
  return { granted: true };
}
export async function requestPermissionsAsync() {
  return { granted: true };
}
export async function setNotificationChannelAsync() {}
export async function scheduleNotificationAsync() {
  return "native-notification";
}

export async function makeDirectoryAsync(uri) {
  files.set(uri, "");
}
export async function getDocumentAsync() {
  return { canceled: true };
}
