import test, { before, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { zipSync, strToU8, unzipSync, strFromU8 } from "fflate";
import { db, raw } from "./adapters/sqlite.mjs";
import { files } from "./adapters/native.mjs";
import { migrations, runMigrations } from "../src/db/migrations.ts";
import * as ideas from "../src/db/repositories/ideas.ts";
import * as creative from "../src/db/repositories/creative.ts";
import * as thinking from "../src/db/repositories/thinking.ts";
import { exportAllData, singleIdeaMarkdown } from "../src/services/export.ts";
import { inspectArchive, restoreArchive } from "../src/services/restore.ts";
import { RECIPES } from "../src/domain/recipes.ts";
before(async () => {
  raw.exec("PRAGMA foreign_keys=ON");
  raw.exec(migrations[0]);
  raw.exec(migrations[1]);
  raw.exec(
    "UPDATE schema_meta SET version=2;INSERT INTO ideas(id,title,next_action,created_at,updated_at,last_touched_at,source_type,original_capture_id) VALUES('old','Existing vault','Try one thing',1,1,1,'text','oldblock');INSERT INTO idea_blocks(id,idea_id,type,body_text,created_at,updated_at,is_original) VALUES('oldblock','old','text','Unchanged original',1,1,1)",
  );
  await runMigrations();
  const old = await ideas.getIdea("old");
  assert.equal(old.blocks[0].body_text, "Unchanged original");
  assert.equal((await creative.listActions("old"))[0].body, "Try one thing");
  assert.equal(old.next_action_id, "next_old");
  assert.equal((await thinking.revisions("old")).length, 0);
});
beforeEach(async () => {
  for (const table of [
    "ideas",
    "idea_fts",
    "inquiries",
    "custom_recipes",
    "discovery_sessions",
    "projects",
    "tags",
    "drafts",
    "app_settings",
    "review_entries",
    "saved_views",
    "focus_sessions",
    "time_capsules",
  ])
    await db.runAsync(`DELETE FROM ${table}`);
  files.clear();
});
const capture = (text = "A thread worth keeping") =>
  ideas.createIdeaFromCapture({ text });
const contract = (overrides = {}) => ({
  intent: "explore",
  mode: "explore",
  sanctuary: 0,
  protected_phrase: "",
  revisit_when: "",
  context: "",
  ...overrides,
});
test("question rooms retain one canonical thought with multiple roles across rooms", async () => {
  const idea = await capture(),
    a = await thinking.saveInquiry("Why?", ""),
    b = await thinking.saveInquiry("How?", "");
  await thinking.joinInquiry(a, idea, "observation");
  await thinking.joinInquiry(b, idea, "answer");
  assert.equal(
    (await thinking.inquiryDetail(a)).members[0].role,
    "observation",
  );
  await thinking.deleteInquiry(a);
  assert.ok(await ideas.getIdea(idea));
  assert.equal((await thinking.inquiryDetail(b)).members.length, 1);
});
test("card evidence links are real foreign keys and detach when a referenced card is deleted", async () => {
  const a = await capture(),
    claim = await thinking.saveCard({
      ideaId: a,
      kind: "assumption",
      title: "People need quiet",
    }),
    evidence = await thinking.saveCard({
      ideaId: a,
      kind: "evidence",
      title: "Interview",
      body: "Observed silence",
      epistemic: "observed",
      relatedCardId: claim,
      relation: "supports",
    });
  await thinking.removeCard(claim);
  assert.equal((await thinking.cards(a))[0].related_card_id, null);
  assert.equal((await ideas.searchIdeas("silence"))[0].id, a);
});
test("invalid source URLs and unknown card types do not create records", async () => {
  const id = await capture();
  assert.throws(() =>
    thinking.saveCard({
      ideaId: id,
      kind: "evidence",
      title: "bad",
      sourceUrl: "javascript:alert(1)",
    }),
  );
  assert.throws(() =>
    thinking.saveCard({ ideaId: id, kind: "invented", title: "bad" }),
  );
  assert.equal((await thinking.cards(id)).length, 0);
});
test("brief restoration retains later original and appended blocks", async () => {
  const id = await capture("Original phrase");
  await ideas.updateIdea(id, { summary: "First interpretation" });
  const first = (await thinking.revisions(id))[0];
  await ideas.addTextBlock(id, "A later observation");
  await ideas.updateIdea(id, { summary: "Changed" });
  await thinking.restoreBrief(first.id);
  const restored = await ideas.getIdea(id);
  assert.equal(restored.summary, "First interpretation");
  assert.equal(restored.blocks.length, 2);
  assert.ok(
    (await thinking.revisions(id)).some((r) => r.label.startsWith("Restored:")),
  );
});
test("checkpoint search includes restart and open-question cues", async () => {
  const id = await capture();
  await thinking.saveCheckpoint(
    id,
    "Understood a mechanism",
    "Why amber?",
    "Start with the helicoid sketch",
  );
  assert.equal((await ideas.searchIdeas("helicoid"))[0].id, id);
  assert.equal((await thinking.checkpoints(id))[0].open_question, "Why amber?");
});
test("one next action follows checklist completion and deletion", async () => {
  const id = await capture();
  await ideas.updateIdea(id, { next_action: "First move" });
  const first = (await creative.listActions(id))[0];
  const second = await creative.addAction(id, "Second move");
  await creative.toggleAction(first.id);
  assert.equal((await ideas.getIdea(id)).next_action, "Second move");
  await creative.removeAction(second);
  assert.equal((await ideas.getIdea(id)).next_action, null);
});
test("search reaches older pages with deterministic ordering", async () => {
  for (let i = 0; i < 230; i++) await capture(`needle ${i}`);
  const a = await ideas.searchIdeas("needle", { limit: 60, offset: 0 }),
    b = await ideas.searchIdeas("needle", { limit: 60, offset: 180 });
  assert.equal(a.length, 60);
  assert.equal(b.length, 50);
  assert.equal(new Set([...a, ...b].map((i) => i.id)).size, 110);
});
test("bridge proposals preserve rejection reason and acceptance is undoable", async () => {
  const a = await capture("A"),
    b = await capture("B");
  const bridge = await thinking.proposeBridge(
    a,
    b,
    "builds_on",
    "Same mechanism",
  );
  await thinking.markSeen(a);
  await thinking.reviewBridge(bridge, "accepted", "useful");
  assert.equal((await db.getAllAsync("SELECT * FROM idea_links")).length, 1);
  await thinking.reviewBridge(bridge, "undo");
  assert.equal((await db.getAllAsync("SELECT * FROM idea_links")).length, 0);
  await thinking.reviewBridge(bridge, "rejected", "Different audiences");
  assert.equal((await thinking.bridges())[0].feedback, "Different audiences");
});
test("stale bridge acceptance rolls back without a relationship", async () => {
  const a = await capture("A"),
    b = await capture("B");
  const bridge = await thinking.proposeBridge(a, b, "related_to", "Maybe");
  await ideas.updateIdea(a, { summary: "Changed premise" });
  await assert.rejects(
    () => thinking.reviewBridge(bridge, "accepted"),
    /source changed/,
  );
  assert.equal((await db.getAllAsync("SELECT * FROM idea_links")).length, 0);
  assert.equal((await thinking.bridges())[0].status, "pending");
});
test("private contracts and sanctuary protect relevant suggestion boundaries", async () => {
  const a = await capture("A"),
    b = await capture("B");
  await thinking.saveContract(a, contract({ intent: "private" }));
  await assert.rejects(
    () => thinking.proposeBridge(a, b, "related_to", "Maybe"),
    /does not allow/,
  );
  await thinking.saveContract(a, contract({ sanctuary: 1 }));
  await assert.rejects(
    () => thinking.proposeBridge(a, b, "contradicts", "Maybe"),
    /does not allow/,
  );
});
test("protected phrases survive creative branches or branch is rejected", async () => {
  const a = await capture();
  await thinking.saveContract(
    a,
    contract({ protected_phrase: "garden of questions" }),
  );
  await assert.rejects(
    () =>
      creative.createBranch({
        title: "Changed",
        body: "Generic rewrite",
        parents: [a],
        source: "remix",
      }),
    /protected phrase/,
  );
  const b = await creative.createBranch({
    title: "Kept",
    body: "A garden of questions",
    parents: [a],
    source: "remix",
  });
  assert.ok(await ideas.getIdea(b));
});
test("experiment observations are append-only and independently searchable", async () => {
  const id = await capture(),
    e = await creative.createExperiment({
      ideaId: id,
      hypothesis: "They will return",
      method: "Ask",
      signal: "A reply",
    });
  await thinking.recordObservation(
    e,
    "They mentioned marigolds",
    "Maybe a memory cue",
    "Could be seasonal",
  );
  await thinking.recordObservation(
    e,
    "A second account",
    "Different context",
    "",
  );
  assert.equal((await thinking.observations(e)).length, 2);
  assert.equal((await ideas.searchIdeas("marigolds"))[0].id, id);
  assert.equal(
    (await db.getAllAsync("SELECT * FROM experiment_protocols")).length,
    1,
  );
});
test("multi-asset capture and audio bookmarks commit together", async () => {
  const id = await ideas.createIdeaFromCapture({
    text: "Walk",
    context: "After class",
    audioUri: "file:///voice.m4a",
    marks: [{ offsetMs: 1200, label: "Question" }],
    attachments: [
      { type: "image", uri: "file:///one.jpg" },
      { type: "file", uri: "file:///two.txt" },
    ],
  });
  assert.equal((await ideas.getIdea(id)).attachments.length, 3);
  assert.equal(
    (await db.getAllAsync("SELECT * FROM audio_marks"))[0].label,
    "Question",
  );
  assert.equal((await ideas.searchIdeas("class"))[0].id, id);
});
test("discovery is finite, persists its queue, and logs impressions only after reveal", async () => {
  for (let i = 0; i < 5; i++) await capture(`Thought ${i}`);
  const id = await thinking.beginDiscovery();
  assert.equal(await thinking.beginDiscovery(), id);
  let session = await thinking.discovery(id);
  assert.equal(session.items.length, 3);
  assert.equal(
    (await db.getAllAsync("SELECT * FROM resurfacing_events")).length,
    0,
  );
  await thinking.revealDiscovery(id, session.items[0].id, "A recollection");
  await thinking.revealDiscovery(id, session.items[0].id, "Again");
  assert.equal(
    (await db.getAllAsync("SELECT * FROM resurfacing_events")).length,
    1,
  );
  await thinking.respondDiscovery(id, session.items[0].id, "useful");
  await thinking.finishDiscovery(id, "A new connection");
  session = await thinking.discovery(id);
  assert.ok(session.session.completed_at);
  assert.equal(session.session.takeaway, "A new connection");
});
test("private, sanctuary, and snoozed thoughts stay out of discovery", async () => {
  const a = await capture(),
    b = await capture();
  await thinking.saveContract(a, contract({ intent: "private" }));
  await thinking.saveContract(b, contract({ sanctuary: 1 }));
  const s = await thinking.discovery(await thinking.beginDiscovery());
  assert.equal(s.items.length, 0);
});
test("notebook sessions preserve all responses and clear only their own draft", async () => {
  const idea = await capture();
  await ideas.saveDraft("one", "Keep");
  await ideas.saveDraft("two", "Other");
  await thinking.saveWorkshop(
    idea,
    "042",
    "Morphology",
    { Audience: "Students", Medium: "Paper" },
    "Simpler",
    "one",
  );
  assert.equal(await ideas.getDraft("one"), null);
  assert.ok(await ideas.getDraft("two"));
  assert.equal((await thinking.workshopHistory(idea)).length, 1);
  assert.match(await singleIdeaMarkdown(idea), /Students/);
  assert.equal((await ideas.searchIdeas("Paper"))[0].id, idea);
});
test("all authored recipes have unique identities and concrete response steps", () => {
  assert.equal(new Set(RECIPES.map((r) => r.id)).size, RECIPES.length);
  assert.ok(RECIPES.length > 100);
  for (const r of RECIPES) {
    assert.ok(r.fields.length >= 3);
    assert.ok(r.fields.every((f) => f.trim()));
  }
});
async function archive() {
  const uri = await exportAllData();
  return inspectArchive(Buffer.from(files.get(uri), "base64"));
}
test("archive round trip remaps collisions, files, revisions, cards, rooms and drafts", async () => {
  const a = await capture("A portable thought");
  const media = "file:///photo.jpg";
  files.set(media, Buffer.from("image bytes").toString("base64"));
  await ideas.addAttachmentBlock(a, { type: "image", uri: media });
  const room = await thinking.saveInquiry("Portable question?", "Context");
  await thinking.joinInquiry(room, a, "answer");
  await thinking.saveCard({
    ideaId: a,
    kind: "evidence",
    title: "Portable proof",
    sourceQuote: "exact words",
  });
  await thinking.saveCheckpoint(a, "Changed", "Still open", "Resume this");
  await ideas.saveDraft(
    "capture:safe",
    "unfinished",
    "image",
    media,
    JSON.stringify({ attachment: { uri: media } }),
  );
  const preview = await archive();
  await restoreArchive(preview);
  const all = await ideas.listIdeas();
  assert.equal(all.length, 2);
  const clone = all.find((i) => i.id !== a);
  const detail = await ideas.getIdea(clone.id);
  assert.ok(
    detail.attachments[0].local_uri.startsWith(
      "file:///test/documents/restored/",
    ),
  );
  assert.ok(files.has(detail.attachments[0].local_uri));
  assert.equal((await thinking.cards(clone.id))[0].title, "Portable proof");
  assert.equal(
    (await thinking.checkpoints(clone.id))[0].restart,
    "Resume this",
  );
  assert.ok((await thinking.revisions(clone.id)).length);
  assert.equal((await thinking.listInquiries()).length, 2);
  const drafts = await thinking.listCaptureDrafts();
  assert.equal(drafts.length, 2);
  const restoredDraft = drafts.find((draft) => draft.id !== "capture:safe");
  assert.match(restoredDraft.id, /^capture:/);
  assert.ok(files.has(restoredDraft.attachment_uri));
  assert.equal(restoredDraft.body_text, "unfinished");
  assert.equal((await db.getAllAsync("PRAGMA foreign_key_check")).length, 0);
});
test("broken archive relationships roll back every database record", async () => {
  const a = await capture("Protected");
  const preview = await archive();
  preview.data.idea_blocks[0].idea_id = "missing-parent";
  await assert.rejects(() => restoreArchive(preview), /relationships/);
  assert.equal((await ideas.listIdeas()).length, 1);
  assert.ok(await ideas.getIdea(a));
  assert.equal((await db.getAllAsync("PRAGMA foreign_key_check")).length, 0);
});
test("archive paths and unsupported versions are rejected before changes", () => {
  const bad = zipSync({ "../escape": strToU8("x") });
  assert.throws(() => inspectArchive(bad), /Unsafe archive path/);
  const newer = zipSync({
    "ideas-export.json": strToU8(
      JSON.stringify({ schema: 999, data: { ideas: [] } }),
    ),
    "attachment-manifest.json": strToU8('{"files":{},"missing":[]}'),
  });
  assert.throws(() => inspectArchive(newer), /unsupported schema/);
});
test("source deletion cascades cards, revisions, notebooks and evidence derivatives", async () => {
  const id = await capture();
  await thinking.saveCard({
    ideaId: id,
    kind: "assumption",
    title: "Sensitive",
  });
  await thinking.saveWorkshop(id, "042", "Draft", { Answer: "private" }, "");
  await ideas.permanentlyDeleteIdea(id);
  for (const table of [
    "thought_cards",
    "thought_revisions",
    "workshop_entries",
  ])
    assert.equal((await db.getAllAsync(`SELECT * FROM ${table}`)).length, 0);
});
