# Vault archives and recovery

## Format

`exportAllData()` creates a ZIP containing `ideas-export.json`, `attachment-manifest.json`, readable per-idea Markdown, and available media. Schema 3 JSON is the authoritative round-trip representation of all 36 application data tables listed in `src/services/archive-schema.ts`. Search indexes and schema migration metadata are rebuilt rather than transported as user records. Draft media URIs found in metadata are included when available.

Current limits are 32 MiB compressed, 96 MiB total uncompressed and 10,000 ZIP entries. The implementation is in-memory and intended for modest vaults. Export refuses excessive input rather than promising unlimited archive support. Missing media are reported in the manifest; their absence does not imply that associated text was lost. These archives are unencrypted.

## Restore

1. Choose an archive in Settings → Recovery. Inspect schema, content counts, export time and warnings before applying.
2. Validate paths, entry limits, supported schemas 2/3, required JSON/manifest fields, table names, columns and primitive data shapes. Unknown or unsafe structures are rejected.
3. Stage included media into a unique app document directory. Verify created files exist.
4. Insert known records in one serialized database transaction using deferred foreign keys. Existing IDs become new IDs, preserving imported references; normalized tags can reuse current tag identities. Capture-draft collisions retain resumable capture identities. Current device preferences are retained.
5. Remap supported JSON references, rebuild search, and reject the whole database transaction if a foreign-key check fails. Ordinary caught failures clean up staged files.

This is an additive restore, not synchronization, replacement of the current vault, or an interactive merge. Repeatedly importing the same archive can intentionally create copies. Restored reminders are records only: open each reminder screen to schedule it on this device. Imported running focus sessions are ended and incomplete discovery sessions are marked complete to avoid resuming device-local execution accidentally.

## Limits that matter

File existence checks are not cryptographic integrity verification. There are no content hashes, authenticated encryption, cross-device conflict conversations, resumable restore jobs or automatic crash-orphan cleanup. A process killed after staging but before database commit may leave unused staged media. Recoverable capture drafts stay in the capture buffer; imported drafts for already-existing non-capture form keys may have collision-renamed IDs that do not automatically reopen that editor. Their raw data remains in the canonical archive.

Legacy schema-2 archives may contain device-local draft media references without media bytes. The preview warns about this. Preparing an export records an archive preparation time, not proof that the user saved it outside the app or that a device restore drill succeeded.

Repository round-trip tests use real SQLite and adapted filesystem I/O. Real Android DocumentPicker, filesystem limits, OS sharing and interrupted imports still need native testing.
