# Design contract — Idea Vault 3.0

A private place to catch unfinished thoughts and return with context. The visual direction is inspired by iOS while retaining Android-compatible navigation, native permissions and system typography. Capture is immediate; deeper structure becomes available as the author asks for it.

## All six attached skills applied

| Attached skill     | Applied decisions                                                                                                                                                                 |
| ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| better-ui          | Clear primary actions, consistent control states, useful empty states, saved-draft feedback and explicit asynchronous errors.                                                     |
| apple-hig-designer | Large titles, five stable primary tabs, inset grouped rows, labeled icon controls, safe areas and familiar push/back navigation.                                                  |
| apple-ui-designer  | System typography, restrained hierarchy, generous touch areas, rounded grouped surfaces and a single Ionicons family for new navigation/control icons.                            |
| better-colors      | Semantic light/dark palettes, subdued surfaces, one primary blue action color and distinct danger/success states.                                                                 |
| apple-design       | Calm composition, purposeful press feedback, reduced-motion behavior and progressive access to detail. Solid surfaces preserve legibility rather than simulated glass everywhere. |
| better-layout      | Reusable spacing, consistent field stacks, readable maximum content width, narrow-screen wrapping/chip rails and grouped related controls.                                        |

The skills guide implementation choices, not a claim of complete Apple HIG certification. Apple proprietary fonts or SF Symbols assets are not bundled. Android uses its system font; Ionicons supply compatible symbolic navigation. Retained legacy decorative glyphs are not a second imported icon package.

## Visual system

Light appearance uses grouped gray `#F2F2F7`, white surfaces, near-black text and blue `#005BC6`. Dark appearance uses `#111113`, lifted charcoal surfaces, light text and `#8AB8FF`. Colors have semantic roles in `src/theme/tokens.ts`; shared controls and retained styles resolve through the active palette. Preference choices are system, light or dark.

Primary titles use 34/41 typography; pushed-screen titles use 28/34; primary body uses 17-point system text. Content width is bounded at 860 points. Normal actions target 48 points, with compact chips maintaining a 44-point minimum. Related rows share a surface with inset separators; whitespace establishes group boundaries. Long-form fields grow vertically and the screen scrolls.

Buttons and icon buttons use a small press scale/opacity response. Reduced-motion preference and the system motion setting suppress scaling/navigation animation where wired. There is no continuous decorative animation. Quiet mode simplifies Today; it is not a claim that every advanced editor has a simplified variant.

## Screen intent

| Screen          | Primary job                                                | Hierarchy / exit                                                                    |
| --------------- | ---------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| Today           | Capture now or resume a thread                             | Prominent capture; a few intent-led rows; settings and stable tabs                  |
| Vault           | Find an existing thought                                   | Search first, optional filters/board, progressive results                           |
| Rooms           | Live with an unanswered question                           | Question/context, role memberships, evidence                                        |
| Studio          | Choose a deliberate method                                 | Grouped tool rows; 112 methods remain searchable                                    |
| Discover        | Revisit a little, then stop                                | Recall → reveal → explicit signal → optional takeaway                               |
| Thought         | Read the original and choose a next step                   | Checkpoint cue, source material, thinking/exercise actions; organizing is secondary |
| Thinking space  | Resume, inspect evidence, compare history or set intention | Four segments, progressive editors, source-preserving restore                       |
| Capture         | Preserve a fragment immediately                            | Text/context, optional media, visible save, Save + New                              |
| Exercise        | Answer one concrete question at a time                     | Source thought, step player, draft state, saved takeaway                            |
| Connection desk | Decide whether a bridge is useful                          | Explicit source/target/reason, pending review, accept/reject/undo                   |
| Focus           | Give attention and leave a restart cue                     | Recoverable deadline and explicit finish/interruption checkpoint                    |
| Recovery        | Understand what can be recovered                           | Diagnostics, export, inspect archive, explicit additive restore                     |
| Settings        | Set comfort and ownership preferences                      | Appearance, reduced motion, quiet mode, curtain and data actions                    |

## Honest interaction boundaries

Prompt recipes are authored writing methods, not simulated AI output. Keyword bridges disclose their basis; the user decides whether to connect. Empty content means unrecorded, not deficient. Sanctuary is honored by challenge/suggestion paths. The curtain is labeled as a convenience rather than an app lock. Archives and time capsules disclose that they are plain local data.

Browser screenshots in `screenshots/` document actual rendered screens. They establish visual evidence for those viewports, not native TalkBack, keyboard, process-death, permission or full large-text verification. See `VALIDATION.md`.
