# Android build and device notes

The source targets Expo SDK 57, React Native 0.86.3 and React 19.2.3. The application ID stays `com.localfirst.ideavault`; database name stays `idea-vault.db`. Release metadata is 3.0.0 / versionCode 3.

## Local build

Install dependencies with `npm ci`, then run `npm run android` with a configured JDK, Android SDK and connected device/emulator. Expo prebuild generates the native project from `app.json`; `npm run prebuild` is available when an explicit generation step is needed. Once a development build is installed, `npm start` starts Metro.

## EAS preview APK

The existing `eas.json` includes development, preview APK and production profiles. Using your own Expo account and project configuration, run:

```bash
npx eas-cli build --platform android --profile preview
```

Retain the signing key used by an existing installation to upgrade it. A new signing key cannot replace a differently signed installed app. Do not uninstall an app containing the only copy of your vault; export first. No signing credentials or generated APK are included here.

## Native validation still required

- Permission allow/deny/revoke for microphone, camera, photos, document picker and notifications.
- Record, bookmark, background, stop, replay and seek; audio completion and interruption behavior.
- Cold/running-app share-in, including text, a URL, image, audio and file; independent draft recovery. Multiple Android share attachments are not configured.
- Keyboard/insets, Android Back, rotation restrictions, system font scaling, TalkBack, reduced motion and small display sizes.
- Notification creation/tapping/cancellation and imported-reminder rescheduling.
- Full archive export to a location outside the app and restore from that location on a second installation.
- Abrupt process death while typing, recording, staging attachments or restoring an archive.
- Upgrade a populated signed v2 install without uninstalling. Verify originals, task synchronization, relationships and new schema data.

The successful Android JavaScript/Hermes bundle export is not an APK build, native installation, permission check or device certification.

## Official API references

- [Expo SQLite](https://docs.expo.dev/versions/v57.0.0/sdk/sqlite/)
- [Expo Audio](https://docs.expo.dev/versions/v57.0.0/sdk/audio/)
- [Expo Sharing](https://docs.expo.dev/versions/v57.0.0/sdk/sharing/)
- [Expo FileSystem legacy API](https://docs.expo.dev/versions/v57.0.0/sdk/filesystem-legacy/)
