# Validation — Idea Vault 3.0

Validation date: 9 October 2026. Android is the intended native target. Browser screenshots are from the running production web bundle, not generated mockups.

## Automated and build checks

| Check                                               | Observed result                          |
| --------------------------------------------------- | ---------------------------------------- |
| TypeScript (`npm run typecheck`)                    | Passed                                   |
| Domain and production-repository tests (`npm test`) | 56 passed, 0 failed                      |
| Expo Android JavaScript/Hermes export               | Passed; approximately 3.6 MB bundle      |
| Expo web production export                          | Passed; approximately 1.7 MB main bundle |
| Native APK build/install                            | Not performed                            |

Commands:

```bash
npm ci
npm run typecheck
npm test
npx expo export --platform web --platform android --output-dir dist
```

Tests use Node 24’s real SQLite engine with foreign keys and FTS5. Only device-specific I/O is adapted inside the test loader. They do not replace production repositories with mocks.

## Tested behavior

The original tests cover populated-v1 upgrades, idempotent migrations, atomic capture, draft clearing/rollback, FTS and literal fallback search, Unicode and hostile-looking query text, collisions and lineage, serialized writes and transaction recovery, tasks, projects, experiment outcomes, capsule timing, focus deadlines, reminder cancellation, trash cascades, saved views, review entries, opt-in sample content and exports.

The added test module first upgrades a populated schema-2 database and checks preserved original text and migration of the next action. Its tests cover question-room memberships, card foreign keys, source URL/type validation, source-preserving brief restore, checkpoint search, canonical task synchronization, 230-record search pagination, bridge accept/reject/undo and stale-source rollback, sanctuary/private/protected-phrase rules, searchable append-only observations, multi-attachment capture and audio marks, finite discovery and impression timing, workshop responses/drafts, unique authored recipes, complete archive round trip with ID collisions/media/drafts, invalid-relationship rollback, unsafe ZIP paths/unsupported schemas and permanent-deletion cleanup.

## Browser verification

The final walkthrough exercised 11 browser workflows with no captured JavaScript errors:

- Capture two independent thoughts with a context postcard.
- Vault search and opening a persisted capture.
- Checkpoint persists after a full reload.
- Typed assumption card saved and displayed.
- Question room created with canonical thought membership.
- Guided exercise answers and takeaway persist in thought history.
- Reviewed bridge acceptance and undo.
- Finite discovery recall, reveal and explicit return feedback.
- Dark appearance persists across navigation and reload.
- Exercise search and narrow mobile layout.
- Wide Studio layout.

Screenshots use temporary test thoughts and do not seed the delivered application. Browser persistence checks use the actual Expo SQLite web implementation and a cross-origin-isolated local server. The walkthrough found and fixed missing web selected-state exposure on segmented controls; native accessibility still needs its own pass.

Screenshots: `today-mobile.png`, `today-dark.png`, `question-room-mobile.png`, `studio-dark.png`, `exercises-small.png` and `studio-wide.png` in `docs/screenshots/`. Views cover 390 × 844, 360 × 800 and 1100 × 900 pixels.

## Remaining native validation

Camera/microphone/audio bookmarks, attachment permissions, incoming/outgoing shares, notifications, real Android archive restore, system Back/keyboard/insets, TalkBack, enlarged text, backgrounding and abrupt process death were not tested on an emulator or physical device. The native Android bundle check compiles JavaScript and assets; it does not produce an APK or verify native permissions. Follow NATIVE_ANDROID.md before a release.

There is no measured guarantee of large-vault performance, power consumption, memory/creativity improvement, crash-proof capture or encrypted storage. Archive tests adapt filesystem I/O and therefore do not establish device-level storage durability.
