# A practical tour of Idea Vault 3.0

## Catch and return

Start on Today with a real thought. Capture text, a context postcard and optional media; Save + New catches a separate thought. Unfinished capture sessions appear in the capture buffer. Open an idea and choose Thinking space → Resume to leave what changed, what is still open and where to begin next time.

## Live with a question

Create a Question room such as “How can neighbors share small useful spaces?” Add existing thoughts as possible answers, observations, counterexamples or experiments. One thought can belong to several rooms without copying its contents. Evidence cards from member thoughts appear in the room.

## Develop without losing the source

In Thinking space → Evidence, record an assumption, mechanism, source receipt, gap or observation. Keep an exact quotation in its own field and your interpretation separately. Attach supporting/challenging cards to a claim. Resolve a question when useful and reopen it when new evidence appears.

Use Thinking space → History to keep a named core snapshot and compare its brief against the current version. Restore changes supported brief fields only; later original text/media blocks remain. A snapshot is not a complete backup of the whole vault.

## Try a method

Studio → Thinking exercises offers 112 authored methods across capture, understanding, exploration, challenge, connection, expression, commitment, memory and reflection. Choose a source thought, answer one step at a time, and save a takeaway. The full response stays in the thought’s notebook; a useful outcome can become a child branch. Your recipes supports 2–12 user-authored steps.

These methods are manual writing tools. A morphology exercise does not imply a visual matrix solver, and a story-world exercise does not imply an automatic consistency engine. See the precise mapping in FEATURE_COVERAGE.md.

The existing Collision lab makes a new idea from two parents with lineage links. Remix, council, constraints, assumptions and pitch tools remain available. Sanctuary in Thinking space → Intention pauses critique paths; a protected phrase must survive local branch creation.

## Give a connection a reason

Open Studio → Connection desk. Choose two thoughts, name their relationship and explain why it could help. A proposal stays separate from the graph until accepted; rejection reasons persist and an accepted link can be undone. If either source has changed, propose again using its current version.

Atlas displays a focal thought and up to seven linked neighbors. Use its relationship list for equivalent navigation. Word-overlap candidates are suggestions to review, not inferred truths. Rejected pairs and protected thoughts are excluded from candidate suggestions.

## Test and act

Use the Experiment bench to state the hypothesis, test plan and success signal before recording an outcome. The protocol is snapshotted. Append observations and separate interpretations or alternative explanations as evidence accumulates.

The thought’s next action and checklist share a canonical task. Focus records a persisted deadline and actual elapsed time. At the end, save changed understanding, an open question and a restart cue; use interruption parking if you need to stop early. Device-clock changes affect a wall-clock timer, and it is not a background alarm.

Projects, energy filters, saved views, the stage board and time capsules remain available from Studio/Vault. Time capsules are a creative delay in the UI, not encrypted secret storage.

## Rediscover and finish

Discover offers at most three eligible thoughts. Write a little from memory, reveal the original, and choose useful, remembered or rest. Finish with an optional takeaway. A completed finite session is enough; no endless queue follows it.

Review remains available through Studio/Discover for the existing activity calendar and reflections. Compost lets an abandoned source contribute a reusable passage and reason without erasing its original.

## Keep it recoverable

Settings → Recovery checks registered media and relationships, prepares an archive and inspects a selected ZIP before additive restore. Canonical JSON includes every application table. Save exports outside the app, keep their unencrypted nature in mind, and read ARCHIVES.md for size, collision, reminder and crash-recovery limits.
