# Idea Vault 3.0 — a little space for a great thought

An offline React Native / Expo Android app with an iOS-inspired interface. This release expands the supplied app using the innovation report and all six attached design skills. It preserves the original database and Android package identity.

## What is included

- Five primary tabs: **Today, Vault, Rooms, Studio, Discover**. Large titles, grouped surfaces, a calm blue accent, system/light/dark appearance, reduced motion, and a quieter Today mode.
- Question rooms with role-based thought membership; typed evidence, assumption, gap, mechanism, decision and ingredient cards; explicit source quotations separate from interpretations.
- Resume checkpoints, parent-linked core snapshots, comparison and brief restoration; thought intentions, sanctuary protection and protected phrases.
- **112 saved guided thinking exercises**, plus custom recipes. Responses remain in the source thought’s notebook and can become a child branch. These are authored methods the user answers, not AI-generated analysis.
- Reviewed bridge proposals, rejection memory and undo; finite recall-first discovery; experiment protocol snapshots and append-only observation streams.
- Separate capture drafts, multi-image/file capture, context postcards, audio moment bookmarks, a synchronized next action, and focus-session restart notes.
- Progressive vault/picker search, searchable new content, complete JSON archives, additive archive restore and recovery diagnostics.
- Existing collision lab, perspective/remix tools, projects, checklists, time capsules, reminders, incoming shares, review and trash remain available.

Read [all 220 feature mappings](docs/FEATURE_COVERAGE.md), [implementation status](docs/IMPLEMENTATION_STATUS.md), [design decisions](docs/DESIGN_CONTRACT.md), and [validation results](docs/VALIDATION.md). Guided adaptations and partially implemented concepts are explicitly distinguished from dedicated workflows.

## Run and build

Use Node.js 24 and npm. Android is the primary native target.

```bash
cd idea-management-app
npm ci
npm run typecheck
npm test
npm run android
```

Local Android builds require Android Studio/SDK, a JDK and an emulator or connected device. `npm run android` generates the native project if necessary. After installing a development build, run `npm start` for subsequent JavaScript development. Native capture/sharing/notifications require a development or standalone build.

For a preview APK through your own Expo/EAS project:

```bash
npx eas-cli build --platform android --profile preview
```

This requires your Expo account/project configuration and signing setup. No credentials, signing key, native APK or dependency directory are included. See [Android build notes](docs/NATIVE_ANDROID.md).

For a browser development preview, run `npm run web`. For the production bundle check used here:

```bash
npx expo export --platform web --platform android --output-dir dist
```

The web SQLite build needs cross-origin isolation. The included Metro configuration supplies development headers and WASM handling. A static host must send `Cross-Origin-Opener-Policy: same-origin` and `Cross-Origin-Embedder-Policy: credentialless` (or an appropriately configured `require-corp` policy). Browser storage is separate from Android storage. The FTS5 fallback uses literal substring matching if the platform SQLite build lacks FTS5.

## Data ownership and boundaries

Existing `idea-vault.db` data migrates to schema 3. Keep application ID `com.localfirst.ideavault` and the original signing identity to upgrade an installed app; uninstalling may erase its private data. Export a copy before installing an update.

Archives contain canonical JSON for all 36 tables, readable notes and available original media. Recovery can inspect and additively restore schema-2/3 ZIPs; identity collisions become linked copies. Archives are limited to 32 MB compressed / 96 MB expanded. Media staging and database transactions protect ordinary failure paths, but process-death resume and content hashes are not implemented. See [archive format and restore behavior](docs/ARCHIVES.md).

The app has no remote model, cloud sync, analytics client, OCR engine or automatic transcription. No login is required. External source links and OS sharing happen only through explicit actions. The database, local media, time capsules and archives are not encrypted. Private intent and the optional screen curtain are interface preferences, not security locks.

Drafts save after a short debounce and flush on supported navigation/background paths. The latest unsaved keystrokes or an interrupted recording can still be lost to abrupt process death. Android hardware permissions, process death, TalkBack and native file sharing still require device testing. No store-release readiness is implied by successful JavaScript builds.

## Source map

| Location                 | Responsibility                                       |
| ------------------------ | ---------------------------------------------------- |
| `src/app`                | Screens and Expo Router navigation                   |
| `src/components/ui`      | Shared iOS-inspired controls and typography          |
| `src/theme`              | Semantic palettes and persistent display preferences |
| `src/domain/recipes.ts`  | 112 authored exercise recipes                        |
| `src/domain/thinking.ts` | Contracts, cards, revisions and workflow types       |
| `src/db/migrations.ts`   | Non-destructive schema upgrades                      |
| `src/db/repositories`    | Persistent transactional workflows                   |
| `src/hooks/useAsync.ts`  | Load/action feedback and recoverable drafts          |
| `src/services`           | Native I/O, search maintenance, archives and restore |
| `tests`                  | Domain and real-SQLite integration checks            |
| `docs`                   | Coverage, design, validation and build information   |
